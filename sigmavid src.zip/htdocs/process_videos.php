<?php
ignore_user_abort(true);
set_time_limit(0);

function processVideo($chunks, $finalFilePath) {
    // Combine chunks into one file
    $tempFile = 'temp_combined.mp4';
    $command = "cat " . implode(' ', array_map('escapeshellarg', $chunks)) . " > " . escapeshellarg($tempFile);
    exec($command);

    // Move combined file to final destination
    rename($tempFile, $finalFilePath);

    // Implement additional processing like thumbnail generation
    // Example: generateThumbnail($finalFilePath);
}

while (true) {
    if (file_exists('queue.txt')) {
        $jobs = file('queue.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($jobs as $job) {
            $data = json_decode($job, true);
            if (isset($data['chunks'], $data['finalFilePath'])) {
                processVideo($data['chunks'], $data['finalFilePath']);
            }
        }
        // Clear the queue file
        file_put_contents('queue.txt', '');
    }
    sleep(10); // Check for new jobs every 10 seconds
}
?>
