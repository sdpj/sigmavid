<?php
session_start(); // Start the session
include 'ip.php';
include 'db.php';

// Function to get time ago string
function getTimeAgoString($video)
{
    if ($video['years_ago'] > 0) {
        return $video['years_ago'] . ' years ago';
    } elseif ($video['months_ago'] > 0) {
        return $video['months_ago'] . ' months ago';
    } elseif ($video['weeks_ago'] > 0) {
        return $video['weeks_ago'] . ' weeks ago';
    } elseif ($video['days_ago'] > 0) {
        return $video['days_ago'] . ' days ago';
    } elseif ($video['hours_ago'] > 0) {
        return $video['hours_ago'] . ' hours ago';
    } elseif ($video['minutes_ago'] > 0) {
        return $video['minutes_ago'] . ' minutes ago';
    } else {
        return $video['seconds_ago'] . ' seconds ago';
    }
}

// Fetch user details if logged in
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user = null;

function getSubscriberCount($userId, $conn) {
    $userId = mysqli_real_escape_string($conn, $userId);
    $query = "SELECT COUNT(*) AS subscriber_count FROM subscriptions WHERE user_id = '$userId'";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);
    return $data['subscriber_count'];
}

// Fetch subscriber count for the logged-in user if available
$subscriberCount = 0; // Default value

if ($user_id) {
    // Fetch user details from the database
    $stmt_user = $conn->prepare("SELECT id, username, profile_picture FROM users WHERE id = ?");
    $stmt_user->bind_param("i", $user_id);
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();
    $loggedInUserId = $_SESSION['user_id'];
    $subscriberCount = getSubscriberCount($loggedInUserId, $conn);
    
    if ($result_user->num_rows > 0) {
        $user = $result_user->fetch_assoc();
    }
    $stmt_user->close();
}

// Fetch featured videos with thumbnails, usernames, and upload time ago
$stmt_featured = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    WHERE v.is_featured = 1
    ORDER BY v.id DESC
    LIMIT 4
");
$stmt_featured->execute();
$result_featured = $stmt_featured->get_result();
$featured_videos = [];
while ($row = $result_featured->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $featured_videos[] = $row;
}
$stmt_featured->close();

// Fetch up to 6 most recent videos with thumbnails, usernames, and upload time ago, sorted by upload time
$stmt_recent = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    WHERE v.is_featured = 0
    ORDER BY v.uploaded_at DESC
    LIMIT 6
");
$stmt_recent->execute();
$result_recent = $stmt_recent->get_result();
$recent_videos = [];
while ($row = $result_recent->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $recent_videos[] = $row;
}
$stmt_recent->close();

function getRandomChannels($conn, $count = 3) {
    $stmt_random = $conn->prepare("
        SELECT id, username, profile_picture
        FROM users
        ORDER BY RAND()
        LIMIT $count
    ");
    $stmt_random->execute();
    $result_random = $stmt_random->get_result();
    $random_channels = [];
    while ($row = $result_random->fetch_assoc()) {
        $random_channels[] = $row;
    }
    $stmt_random->close();
    return $random_channels;
}

// Fetch up to 8 most popular videos with thumbnails, usernames, and upload time ago, sorted by views
$stmt_popular = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    ORDER BY v.views DESC
    LIMIT 8
");
$random_channels = getRandomChannels($conn, 3);
$stmt_popular->execute();
$result_popular = $stmt_popular->get_result();
$popular_videos = [];
while ($row = $result_popular->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $popular_videos[] = $row;
}
$stmt_popular->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en" data-cast-api-enabled="true">
   <head>
      <link id="css-2838365198" class="www-core" rel="stylesheet" href="css/main.css" data-loaded="true">
      <title>SigmaVid</title>
      <link rel="search" type="application/opensearchdescription+xml" href="https://www.youtube.com/opensearch?locale=en_US" title="SigmaVid Video Search">
      <link rel="shortcut icon" href="favicon-vfldLzJxy.ico" type="image/x-icon">
      <link rel="icon" href="images/favicon_32-vflWoMFGx.png" sizes="32x32">
      <link rel="alternate" media="handheld" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
      <link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
      <meta name="description" content="Share your videos with friends, family, and the world">
      <meta name="keywords" content="video, sharing, camera phone, video phone, free, upload">
      <meta property="og:image" content="images/youtube_logo_stacked-vfl225ZTx.png">
      <meta property="fb:app_id" content="87741124305">
      <link rel="publisher" href="https://plus.google.com/115229808208707341778">
      <script>if (window.ytcsi) {window.ytcsi.tick("cl", null, '');}</script>
   </head>
   <!-- machid: palZfX2ZGYUViS0hwbGFMVlBQendwdzI3bU9YYzVsVk1ZQkNyVGpZS1VZUWEtME9uZkR2WFZn -->
   <body dir="ltr" class="  ltr        site-left-aligned  hitchhiker-enabled    guide-enabled  guide-expanded  " id="body">
      <div id="body-container">
         <form name="logoutForm" method="POST" action="/logout"><input type="hidden" name="action_logout" value="1"></form>
         <div id="yt-masthead-container" class="yt-grid-box yt-base-gutter">
            <div id="yt-masthead" class="">
               <a id="logo-container" href="/" title="SigmaVid home" class=" "><iframe width="560" height="315" src="https://www.youtube.com/embed/98fsOSnqTh8?si=ScL5-KGTjW1_mEpX&amp;autoplay=1&amp;controls=1&amp;loop=1&amp;mute=1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen="" style="display:none;"></iframe>
               <iframe width="560" height="315" src="https://www.youtube.com/embed/H2_l_Vp0Xjw?si=ScL5-KGTjW1_mEpX&amp;autoplay=1&amp;controls=1&amp;loop=1&amp;mute=1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen="" style="display:none;"></iframe><img height="30" width="70" id="logo1" src="images/sigmavid.png" alt="SigmaVid home"></a>
               <?php if ($user): ?>
    <!-- Display user profile information -->

        <div id="masthead-user-bar-container" bis_skin_checked="1">
<div id="masthead-user-bar" bis_skin_checked="1">
<div id="masthead-user" bis_skin_checked="1">
<span id="masthead-gaia-user-expander" class="masthead-user-menu-expander masthead-expander" onclick="wow()"><span id="masthead-gaia-user-wrapper" class="yt-rounded" tabindex="0">
<?php echo $user['username']; ?> </span></span>
<span id="masthead-gaia-photo-expander" class="masthead-user-menu-expander masthead-expander" onclick="wow()"><span id="masthead-gaia-photo-wrapper" class="yt-rounded"><span id="masthead-gaia-user-image"><span class="clip"><span class="clip-center"><img src="<?php echo $user['profile_picture']; ?>" alt=""><span class="vertical-center"></span></span></span></span><span class="masthead-expander-arrow"></span></span></span>
</div>
</div>
</div>
<?php else: ?>
    <!-- Display login button if user not logged in -->
               <div id="yt-masthead-signin"><button href="/login" onclick=";window.location.href=this.getAttribute('href');return false;" class=" yt-uix-button yt-uix-button-primary yt-uix-button-size-default" type="button" role="button"><span class="yt-uix-button-content">Sign in </span></button></div>
<?php endif; ?>
               <div id="yt-masthead-content">
                  <span id="masthead-upload-button-group"><a href="/upload" class="yt-uix-button   yt-uix-sessionlink yt-uix-button-default yt-uix-button-size-default" data-sessionlink="feature=mhsb&amp;ei=yyOdUvWjKJOziAKBy4HABQ"><span class="yt-uix-button-content">Upload </span></a></span>
                  <form id="masthead-search" class="search-form consolidated-form" action="/results" onsubmit="if (_gel('masthead-search-term').value == '') return false;">
                     <button onclick="if (_gel('masthead-search-term').value == '') return false; _gel('masthead-search').submit(); return false;;return true;" class="search-btn-component search-button yt-uix-button yt-uix-button-default yt-uix-button-size-default" dir="ltr" id="search-btn" tabindex="2" type="submit" role="button"><span class="yt-uix-button-content">Search </span></button>
                     <div id="masthead-search-terms" class="masthead-search-terms-border" dir="ltr">
                        <label><input id="masthead-search-term" autocomplete="off" autofocus="" class="search-term yt-uix-form-input-bidi" name="search_query" value="" type="text" tabindex="1" title="Search"></label><script>var searchBox = document.getElementById('masthead-search-term');if (searchBox) {searchBox.focus();}</script>
                     </div>
                  </form>
               </div>
            </div>
         </div>
         <div  id="masthead-expanded-container" style="height: 142px;" class="with-sandbar" bis_skin_checked="1">
<div id="masthead-expanded-menus-container" bis_skin_checked="1">
<span id="masthead-expanded-menu-shade"></span>
<div id="masthead-expanded-menu" class="" bis_skin_checked="1">
<ul id="masthead-expanded-menu-list">
<li class="masthead-expanded-menu-item">
<a href="/channel?user_id=<?php echo $_SESSION['user_id']; ?>" class="yt-uix-sessionlink" data-sessionlink="ei=UCd131nmJ5MOh9TmIyqA81&amp;feature=mhee">My channel</a>
</li>
<li class="masthead-expanded-menu-item">
<a href="/manage_videos" class="yt-uix-sessionlink" data-sessionlink="ei=UCd131nmJ5MOh9TmIyqA81&amp;feature=mhee">
Video Manager
</a>
</li>

<li class="masthead-expanded-menu-item">
<a class="end" href="/logout">
Log out
</a>
</li>
</ul>
</div>
<div id="masthead-expanded-google-menu" bis_skin_checked="1">
<div id="masthead-expanded-menu-google-container" bis_skin_checked="1">
<div id="masthead-expanded-menu-google-column2" bis_skin_checked="1">
<div id="masthead-expanded-menu-account-container" bis_skin_checked="1">
<img id="masthead-expanded-menu-gaia-photo" alt="" data-src="<?php echo $user['profile_picture']; ?>" src="<?php echo $user['profile_picture']; ?>">
<div id="masthead-expanded-menu-account-info" class="email-only" bis_skin_checked="1">
<p>
<?php echo $user['username']; ?> </p>
<p id="masthead-expanded-menu-email"><?php echo $subscriberCount; ?> subscribers</p>
</div>
</div>
<ul>
</ul>
</div>
</div>
</div></div>
</div>
<script>
function wow() {
  var masthead = document.getElementById('masthead-expanded-container');
  
  // Toggle visibility
  masthead.style.display = (masthead.style.display === 'none') ? 'block' : 'none';
}

// Initially hide the masthead element
document.addEventListener('DOMContentLoaded', function() {
  var masthead = document.getElementById('masthead-expanded-container');
  masthead.style.display = 'none';
});

</script>
         <div id="alerts">
         </div>
         <div id="page-container">
            <div id="page" class="  home     branded-page-v2-masthead-ad-header  clearfix">
               <div id="guide">
                  <div id="guide-container" class=" vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CAEQ_h4">
                     <div id="guide-main" class="    guide-module     spf-nolink   yt-uix-tdl ">
                        <div class="guide-module-toggle">
                           <span class="guide-module-toggle-icon">
                           <span class="guide-module-toggle-arrow"></span>
                           <img src="images/pixel-vfl3z5WfW.gif" alt="">
                           <img src="images/pixel-vfl3z5WfW.gif" alt="" id="collapsed-notification-icon">
                           </span>
                           <div class="guide-module-toggle-label">
                              <h3>
                                 <span>
                                 Guide
                                 </span>
                              </h3>
                           </div>
                        </div>
                        <div class="guide-module-content yt-scrollbar">
                           <ul class="guide-toplevel">
                              <li class="guide-section vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CAIQ5isoAA">
                                 <div class="guide-item-container personal-item">
                                    <ul class="guide-user-links yt-box">
                                       <li class="vve-check guide-channel" id="HCtnHdj3df7iM-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/user/popular" title="Popular on SigmaVid" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="images/UCjg7K9dXbITL7Rfq5jDly.jpg" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span>Popular on SigmaVid</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                       <li class="vve-check guide-channel" id="UC-9-kyTW8ZkZNDHQJ6FgpwQ-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/user/Music" title="Music" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="UC-9-kyTW8ZkZNDHQJ6FgpwQ" data-serialized-endpoint="0qDduQEaEhhVQy05LWt5VFc4WmtaTkRIUUo2Rmdwd1E%3D">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="images/71.jpg" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span>Music</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                       <li class="vve-check guide-channel" id="HChfZhJdhTqX8-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/user/Gaming" title="Gaming" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HChfZhJdhTqX8" data-serialized-endpoint="0qDduQEPEg1IQ2hmWmhKZGhUcVg4">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="images/UCJnrnDWpPPfyfIIQ4wLiN.jpg" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span>Gaming</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                       <li class="vve-check guide-channel" id="HChfZhJdhTqX8-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/user/News" title="News" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HChfZhJdhTqX8" data-serialized-endpoint="0qDduQEPEg1IQ2hmWmhKZGhUcVg4">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="images/UC2s7nUriqurPH0343t8oX.jpg" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span>News</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                       <li class="vve-check guide-channel" id="UCBR8-60-B28hp2BmDPdntcQ-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/user/SigmaVid" title="Spotlight" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="UCBR8-60-B28hp2BmDPdntcQ" data-serialized-endpoint="0qDduQEaEhhVQ0JSOC02MC1CMjhocDJCbURQZG50Y1E%3D">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="images/UC0wYm3ncbxqDKrA6rnFhZ.jpg" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span>Spotlight</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                    </ul>
                                 </div>
                                 <hr class="guide-section-separator">
                              </li>
                              <li class="guide-section vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CA0Q5isoAQ">
                                 <div class="guide-item-container personal-item">
                                    <h3>Channels for you</h3>
                                    <ul class="guide-user-links yt-box">
                                            <?php if (!empty($random_channels)): ?>
                                                        <?php foreach ($random_channels as $channel): ?>
                                       <li class="vve-check guide-channel" id="UCujCZYL7mpAMHeBups0yTsA-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/channel?user_id=<?php echo $channel['id']; ?>" title="SigmaVid Spotlight">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="<?php echo $channel['profile_picture']; ?>" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span><?php echo $channel['username']; ?>
                                          </span></span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                                   <?php endforeach; ?>

                                           <?php else: ?>
        <p>No random channels available.</p>
    <?php endif; ?>
                                    </ul>
                                 </div>
                                 <hr class="guide-section-separator">
                              </li>
                              <li class="guide-section vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CBMQ5isoAg">
                                 <div class="guide-item-container personal-item">
                                    <ul class="guide-user-links yt-box">
                                       <li class="vve-check guide-channel" id="guide_builder-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/channels" title="Browse channels" data-sessionlink="feature=g-manage&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="guide_builder" data-serialized-endpoint="0qPduQECCAE%3D">
                                          <span class="yt-valign-container">
                                          <img class="thumb guide-builder-icon" src="images/pixel-vfl3z5WfW.gif" alt="" title="">
                                          <span class="display-name  no-count">
                                          <span>Browse channels</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                    </ul>
                                 </div>
                              </li>
                            <?php if (!$user): ?>
                              <li class="guide-section guide-header signup-promo guided-help-box">
                                 <p>
                                    Sign in now to see your channels and recommendations!
                                 </p>
                                 <div id="guide-builder-promo-buttons" class="signed-out clearfix">
                                    <a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dsign_in_promo%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="yt-uix-button   yt-uix-sessionlink yt-uix-button-primary yt-uix-button-size-default" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ"><span class="yt-uix-button-content">Sign In </span></a>
                                 </div>
                              </li>
                              <?php endif; ?>
                           </ul>
                        </div>
                     </div>
                     <div id="watch-context-container" class="guide-module collapsed hid"></div>
                  </div>
               </div>
               <div id="player" class="  off-screen  ">
                  <div id="playlist" class="playlist">
                  </div>
                  <div id="player-unavailable" class="  hid  ">
                  </div>
                  <div id="player-api" class="player-width player-height off-screen-target watch-content player-api"></div>
                  <script>if (window.ytcsi) {window.ytcsi.tick("bf", null, '');}</script>
                  <script>var ytplayer = ytplayer || {};ytplayer.config = {"attrs": {"id": "movie_player"}, "params": {"bgcolor": "#000000", "allowfullscreen": "true", "allowscriptaccess": "always"}, "assets": {"html": "\/html5_player_template", "css": "\/\/s.ytimg.com\/yts\/cssbin\/www-player-vflzE0TL9.css", "js": "\/\/s.ytimg.com\/yts\/jsbin\/html5player-vfl66X2C5.js"}, "url_v8": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/cps.swf", "url_v9as2": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/cps.swf", "url": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/watch_as3.swf", "args": {"enablejsapi": 1, "hl": "", "fexp": "903802,936905,910207,916611,936912,936910,923305,936913,907231", "autoplay": "0", "cr": ""}, "sts": 16031, "min_version": "8.0.0", "html5": false};</script>
                  <div id="playlist-tray" class="playlist-tray">
                  </div>
                  <div class="clear"></div>
               </div>
               <div id="content" class="">
                   <h1 style="font-size:30px;">SigmaVid is Currently Under Maintenance</h1><br>
                   <p>In the meantime, here's a game of PacMan you can play.</p>
                   <iframe src="pacman/index.html" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="600px" width="500px" allowfullscreen></iframe>
               </div>
            </div>
         </div>
      </div>
      <div id="footer-container">
         <div id="footer">
            <div id="footer-main">
               <div id="footer-l0go"><a href="/" title="SigmaVid home"><img height="30px" width="72px" id="logo1" src="images/SigmaVid-logo.png" alt="SigmaVid home"></a></div>
            </div>
            <div id="footer-links">
               <ul id="footer-links-primary">
                  <li><a href="/about">About</a></li>
                  <li><a href="/blog">Press &amp; Blogs</a></li>
                  <li><a href="/copyright">Copyright</a></li>
                  <li><a href="/creators">Creators &amp; Partners</a></li>
                  <li><a href="/advertise">Advertising</a></li>
                  <li><a href="/dev">Developers</a></li>
               </ul>
               <ul id="footer-links-secondary">
                  <li><a href="/tos">Terms</a></li>
                  <li><a href="/policyandsafety">
                     Policy &amp; Safety
                     </a>
                  </li>
                  <li>  <span class="copyright" dir="ltr">© 2024 SigmaVid</span></li>
               </ul>
            </div>
         </div>
      </div>
      <div class="yt-dialog hid" id="feed-privacy-lb">
         <div class="yt-dialog-base">
            <span class="yt-dialog-align"></span>
            <div class="yt-dialog-fg">
               <div class="yt-dialog-fg-content">
                  <div class="yt-dialog-loading">
                     <div class="yt-dialog-waiting-content">
                        <div class="yt-spinner-img"></div>
                        <div class="yt-dialog-waiting-text">Loading...</div>
                     </div>
                  </div>
                  <div class="yt-dialog-content">
                     <div id="feed-privacy-dialog">
                     </div>
                  </div>
                  <div class="yt-dialog-working">
                     <div id="yt-dialog-working-overlay">
                     </div>
                     <div id="yt-dialog-working-bubble">
                        <div class="yt-dialog-waiting-content">
                           <div class="yt-spinner-img"></div>
                           <div class="yt-dialog-waiting-text">Working...</div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="shared-addto-watch-later-login" class="hid">
         <a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dplaylist%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="sign-in-link">Sign in</a> to add this to Watch Later
      </div>
      <div id="shared-addto-menu" style="display: none;" class="hid sign-in">
         <div class="addto-menu">
            <div id="addto-list-panel" class="menu-panel active-panel">
               <span class="addto-playlist-item yt-uix-button-menu-item yt-uix-tooltip sign-in" data-possible-tooltip="" data-tooltip-show-delay="750">
               <img class="playlist-status" src="images/pixel-vfl3z5WfW.gif" alt="" title=""><a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dplaylist%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="sign-in-link">Sign in</a> to add this to Watch Later
               </span>
            </div>
            <div id="addto-list-saving-panel" class="menu-panel">
               <div class="addto-loading loading-content">
                  <p class="yt-spinner">
                     <img class="yt-spinner-img" src="images/pixel-vfl3z5WfW.gif" alt="Loading icon" title="">
                     <span class="yt-spinner-message">
                     Loading playlists...
                     </span>
                  </p>
               </div>
            </div>
            <div id="addto-list-error-panel" class="menu-panel">
               <div class="panel-content">
                  <img src="images/pixel-vfl3z5WfW.gif">
                  <span class="error-details"></span>
                  <a class="show-menu-link">Back</a>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>
