<?php
include 'all.php';
session_start();
include 'check_maintenance.php';
?>



<!DOCTYPE html>
<html lang="en" data-cast-api-enabled="true">
   <head>
      <link id="css-2838365198" class="www-core" rel="stylesheet" href="css/main.css" data-loaded="true">
      <title>SigmaVid</title>
      <link rel="search" type="application/opensearchdescription+xml" href="https://www.youtube.com/opensearch?locale=en_US" title="SigmaVid Video Search">
      <link rel="shortcut icon" href="favicon-vfldLzJxy.ico" type="image/x-icon">
      <link rel="icon" href="images/favicon_32-vflWoMFGx.png" sizes="32x32">
      <link rel="alternate" media="handheld" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
      <link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
      <meta name="description" content="Share your videos with friends, family, and the world">
      <meta name="keywords" content="video, sharing, camera phone, video phone, free, upload">
      <meta property="og:image" content="images/youtube_logo_stacked-vfl225ZTx.png">
      <meta property="fb:app_id" content="87741124305">
      <link rel="publisher" href="https://plus.google.com/115229808208707341778">
      <script>if (window.ytcsi) {window.ytcsi.tick("cl", null, '');}</script>
   </head>
   <!-- machid: palZfX2ZGYUViS0hwbGFMVlBQendwdzI3bU9YYzVsVk1ZQkNyVGpZS1VZUWEtME9uZkR2WFZn -->
   <body dir="ltr" class="  ltr        site-left-aligned  hitchhiker-enabled    guide-enabled  guide-expanded  " id="body">
      <div id="body-container">
         <form name="logoutForm" method="POST" action="/logout"><input type="hidden" name="action_logout" value="1"></form>
<?php include 'header.php'; ?>

         <div id="alerts">
         </div>
         <div id="page-container">
            <div id="page" class="  home     branded-page-v2-masthead-ad-header  clearfix">
<?php include 'guide.php'; ?>

               <div id="player" class="  off-screen  ">
                  <div id="playlist" class="playlist">
                  </div>
                  <div id="player-unavailable" class="  hid  ">
                  </div>
                  <div id="player-api" class="player-width player-height off-screen-target watch-content player-api"></div>
                  <script>if (window.ytcsi) {window.ytcsi.tick("bf", null, '');}</script>
                  <script>var ytplayer = ytplayer || {};ytplayer.config = {"attrs": {"id": "movie_player"}, "params": {"bgcolor": "#000000", "allowfullscreen": "true", "allowscriptaccess": "always"}, "assets": {"html": "\/html5_player_template", "css": "\/\/s.ytimg.com\/yts\/cssbin\/www-player-vflzE0TL9.css", "js": "\/\/s.ytimg.com\/yts\/jsbin\/html5player-vfl66X2C5.js"}, "url_v8": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/cps.swf", "url_v9as2": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/cps.swf", "url": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/watch_as3.swf", "args": {"enablejsapi": 1, "hl": "", "fexp": "903802,936905,910207,916611,936912,936910,923305,936913,907231", "autoplay": "0", "cr": ""}, "sts": 16031, "min_version": "8.0.0", "html5": false};</script>
                  <div id="playlist-tray" class="playlist-tray">
                  </div>
                  <div class="clear"></div>
               </div>
               
<div id="content" class="content">
    <?php
    include 'db.php';
    session_start();

    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }

    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("SELECT id, title, description, filename, thumbnail FROM videos WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    $conn->close();
    ?>

    <h1 style="font-size:30px;">Manage Videos</h1><br>
    <ul style="padding: 0;">
        <?php while ($row = $result->fetch_assoc()): ?>
            <li style="height:110px; list-style-type: none;" class="yt-lockup clearfix yt-uix-tile result-item-padding yt-lockup-video yt-lockup-tile context-data-item">
                <div class="yt-lockup-thumbnail" bis_skin_checked="1">
                    <a href="watch.php?id=<?php echo htmlspecialchars($row['id']); ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto">
                        <span class="video-thumb yt-thumb yt-thumb-185">
                            <span class="yt-thumb-default">
                                <span class="yt-thumb-clip">
                                    <span class="yt-thumb-clip-inner">
                                        <img src="<?php echo htmlspecialchars($row['thumbnail']); ?>" alt="Thumbnail" width="185">
                                        <span class="vertical-align"></span>
                                    </span>
                                </span>
                            </span>
                        </span>
                    </a>
                </div>
                <div class="yt-lockup-content" bis_skin_checked="1">
                    <h3 class="yt-lockup-title">
                        <a class="yt-uix-sessionlink yt-uix-tile-link yt-uix-contextlink yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" title="<?php echo htmlspecialchars($row['title']); ?>" href="watch.php?id=<?php echo htmlspecialchars($row['id']); ?>">
                            <span class="yt-ui-ellipsis-wrapper"><?php echo htmlspecialchars($row['title']); ?></span>
                        </a>
                    </h3>
                    <div class="yt-lockup-meta" bis_skin_checked="1">
                        <ul class="yt-lockup-meta-info">
                            <!-- Add any additional meta information here -->
                        </ul>
                    </div>
                    <div class="yt-lockup-description yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" bis_skin_checked="1">
                        <span class="yt-ui-ellipsis-wrapper"><a href="edit_video.php?id=<?php echo $row['id']; ?>">Click to Edit</a></span>
                    </div>
                </div>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

               
               
               
               
               
               
               
               
               
            </div>
         </div>
      </div>
      <div id="footer-container">
         <div id="footer">
            <div id="footer-main">
               <div id="footer-l0go"><a href="/" title="SigmaVid home"><img height="30px" width="72px" id="logo1" src="images/SigmaVid-logo.png" alt="SigmaVid home"></a></div>
            </div>
            <div id="footer-links">
               <ul id="footer-links-primary">
                  <li><a href="/about">About</a></li>
                  <li><a href="/blog">Press &amp; Blogs</a></li>
                  <li><a href="/copyright">Copyright</a></li>
                  <li><a href="/creators">Creators &amp; Partners</a></li>
                  <li><a href="/advertise">Advertising</a></li>
                  <li><a href="/dev">Developers</a></li>
               </ul>
               <ul id="footer-links-secondary">
                  <li><a href="/tos">Terms</a></li>
                  <li><a href="/policyandsafety">
                     Policy &amp; Safety
                     </a>
                  </li>
                  <li>  <span class="copyright" dir="ltr">© 2024 SigmaVid</span></li>
               </ul>
            </div>
         </div>
      </div>
      <div class="yt-dialog hid" id="feed-privacy-lb">
         <div class="yt-dialog-base">
            <span class="yt-dialog-align"></span>
            <div class="yt-dialog-fg">
               <div class="yt-dialog-fg-content">
                  <div class="yt-dialog-loading">
                     <div class="yt-dialog-waiting-content">
                        <div class="yt-spinner-img"></div>
                        <div class="yt-dialog-waiting-text">Loading...</div>
                     </div>
                  </div>
                  <div class="yt-dialog-content">
                     <div id="feed-privacy-dialog">
                     </div>
                  </div>
                  <div class="yt-dialog-working">
                     <div id="yt-dialog-working-overlay">
                     </div>
                     <div id="yt-dialog-working-bubble">
                        <div class="yt-dialog-waiting-content">
                           <div class="yt-spinner-img"></div>
                           <div class="yt-dialog-waiting-text">Working...</div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="shared-addto-watch-later-login" class="hid">
         <a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dplaylist%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="sign-in-link">Sign in</a> to add this to Watch Later
      </div>
      <div id="shared-addto-menu" style="display: none;" class="hid sign-in">
         <div class="addto-menu">
            <div id="addto-list-panel" class="menu-panel active-panel">
               <span class="addto-playlist-item yt-uix-button-menu-item yt-uix-tooltip sign-in" data-possible-tooltip="" data-tooltip-show-delay="750">
               <img class="playlist-status" src="images/pixel-vfl3z5WfW.gif" alt="" title=""><a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dplaylist%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="sign-in-link">Sign in</a> to add this to Watch Later
               </span>
            </div>
            <div id="addto-list-saving-panel" class="menu-panel">
               <div class="addto-loading loading-content">
                  <p class="yt-spinner">
                     <img class="yt-spinner-img" src="images/pixel-vfl3z5WfW.gif" alt="Loading icon" title="">
                     <span class="yt-spinner-message">
                     Loading playlists...
                     </span>
                  </p>
               </div>
            </div>
            <div id="addto-list-error-panel" class="menu-panel">
               <div class="panel-content">
                  <img src="images/pixel-vfl3z5WfW.gif">
                  <span class="error-details"></span>
                  <a class="show-menu-link">Back</a>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>



<?php
include 'check_ban.php';
?>
