<div id="footer-container" style="margin-top:0;">
         <div id="footer">
            <div id="footer-main">
               <div id="footer-l0go"><a href="/" title="SigmaVid home"><img height="30px" width="72px" id="logo1" src="images/SigmaVid-logo.png" alt="SigmaVid home"></a></div>
            </div>
            <div id="footer-links">
               <ul id="footer-links-primary">
                  <li><a href="/about">About</a></li>
                  <li><a href="/blog">Press &amp; Blogs</a></li>
                  <li><a href="/copyright">Copyright</a></li>
                  <li><a href="/creators">Creators &amp; Partners</a></li>
                  <li><a href="/advertise">Advertising</a></li>
                  <li><a href="/dev">Developers</a></li>
               </ul>
               <ul id="footer-links-secondary">
                  <li><a href="/tos">Terms</a></li>
                  <li><a href="/policyandsafety">
                     Policy &amp; Safety
                     </a>
                  </li>
                  <li>  <span class="copyright" dir="ltr">© 2024 SigmaVid</span></li>
               </ul>
            </div>
         </div>
      </div>
      <div class="yt-dialog hid" id="feed-privacy-lb">
         <div class="yt-dialog-base">
            <span class="yt-dialog-align"></span>
            <div class="yt-dialog-fg">
               <div class="yt-dialog-fg-content">
                  <div class="yt-dialog-loading">
                     <div class="yt-dialog-waiting-content">
                        <div class="yt-spinner-img"></div>
                        <div class="yt-dialog-waiting-text">Loading...</div>
                     </div>
                  </div>
                  <div class="yt-dialog-content">
                     <div id="feed-privacy-dialog">
                     </div>
                  </div>
                  <div class="yt-dialog-working">
                     <div id="yt-dialog-working-overlay">
                     </div>
                     <div id="yt-dialog-working-bubble">
                        <div class="yt-dialog-waiting-content">
                           <div class="yt-spinner-img"></div>
                           <div class="yt-dialog-waiting-text">Working...</div>
                        </div>
                     </div>
                  </div>
               </div>