<!DOCTYPE html>
<html>
<head>
    <title>Choose Your Layout</title>
    <style>
        .layout-option {
            display: inline-block;
            margin: 20px;
            text-align: center;
        }
        .layout-option img {
            width: 200px;
            height: auto;
            cursor: pointer;
        }
    </style>
    <script>
        function chooseLayout(layout) {
            console.log("Choosing layout: " + layout); // Debug statement
            // Send the chosen layout to the server
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "home/save_layout.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    console.log("Response: " + xhr.responseText); // Debug statement
                    // Redirect to the appropriate layout page after saving the choice
                    window.location.reload();
                }
            };
            xhr.send("layout_home=" + layout);
        }
    </script>
</head>
<body>
    <h1>Choose Your Layout</h1>
    <div class="layout-option">
        <h2>Feed Layout</h2>
        <img width="100" src="home/feed_layout.png" alt="Feed Layout" onclick="chooseLayout(1)">
    </div>
    <div class="layout-option">
        <h2>Grid Layout</h2>
        <img width="100" src="home/grid_layout.png" alt="Grid Layout" onclick="chooseLayout(2)">
    </div>
</body>
</html>
