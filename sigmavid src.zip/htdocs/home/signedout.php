<div class="branded-page-v2-container  branded-page-v2-secondary-column-hidden">
                     <div class="branded-page-v2-col-container">
                        <div class="branded-page-v2-col-container-inner">
                           <div class="branded-page-v2-primary-col">
                              <div class="branded-page-v2-primary-col-header-container branded-page-v2-primary-column-content">
                                 <div id="context-source-container" data-context-source="Popular on SigmaVid" style="display:none;"></div>
                              </div>
                              <div class="branded-page-v2-body branded-page-v2-primary-column-content" id="gh-activityfeed">
                                 <div class="context-data-container">
                                    <div class="lohp-newspaper-shelf vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CBcQ0R4oAA">
                                        <?php if (!empty($featured_videos)): ?>
                                       <div class="lohp-large-shelf-container">
                                          <div class="context-data-item" data-context-item-id="10891" data-context-item-views="1,101,817 views" data-context-item-type="video" data-context-item-time="1:12" data-context-item-title="Rant: If you eat burgers without cheese you are a CREATURE" data-context-item-user="TestieTorsionGaming" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CBgQ0h4oAA">
                                             <a href="watch.php?id=<?php echo $featured_videos[0]['id']; ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink yt-fluid-thumb-link contains-addto lohp-thumb-wrap" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CBgQ0h4oAA&amp;feature=g-logo">    <span class="video-thumb  yt-thumb yt-thumb-370 yt-thumb-fluid">
                                             <span class="yt-thumb-default">
                                             <span class="yt-thumb-clip">
                                             <img alt="Thumbnail" src="<?php echo $featured_videos[0]['thumbnail']; ?>" width="370">
                                             <span class="vertical-align"></span>
                                             </span>
                                             </span>
                                             </span>
                                             <button onclick=";return false;" title="Watch Later" class="addto-button video-actions spf-nolink hide-until-delayloaded addto-watch-later-button-sign-in yt-uix-button yt-uix-button-default yt-uix-button-size-small yt-uix-tooltip" type="button" data-video-ids="10891" data-button-menu-id="shared-addto-watch-later-login" role="button"><span class="yt-uix-button-content">  <img src="images/pixel-vfl3z5WfW.gif" alt="Watch Later">
                                             </span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW.gif" alt="" title=""></button>
                                             </a>
                                             <a class="lohp-video-link max-line-2 yt-uix-sessionlink " data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CBgQ0h4oAA&amp;feature=g-logo" href="watch.php?id=<?php echo $featured_videos[0]['id']; ?>" title="Rant: If you eat burgers without cheese you are a CREATURE"><?php echo $featured_videos[0]['title']; ?></a>
                                             <div class="lohp-video-metadata">
                                                <span class="content-uploader spf-nolink">
                                                <span class="username-prepend">by</span> <a href="/channel?user_id=<?php echo $featured_videos[0]['user_id']; ?>" class="g-hovercard yt-uix-sessionlink yt-user-name " data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ" dir="ltr" data-ytid="UC5K76B8Ka8vkwFHTjegVayQ" data-name=""><?php echo $featured_videos[0]['username']; ?></a>  </span>
                                                <span class="view-count">
                                                <?php echo $featured_videos[0]['views']; ?> views
                                                </span>
                                                <span class="content-item-time-created" title="1 day ago">
                                                <?php echo $featured_videos[0]['time_ago']; ?>    </span>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="lohp-medium-shelves-container" bis_skin_checked="1">
                                        <?php for ($i = 1; $i < min(count($featured_videos), 4); $i++): ?>
                                          <div class="lohp-medium-shelf context-data-item vve-check " data-context-item-id="10886" data-context-item-views="259,272 views" data-context-item-type="video" data-context-item-time="0:32" data-context-item-title="bitview.mp4" data-context-item-user="kindle" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=10886" bis_skin_checked="1">
                                             <div class="lohp-media-object" bis_skin_checked="1">
                                                <a href="watch.php?id=<?php echo $featured_videos[$i]['id']; ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink yt-fluid-thumb-link contains-addto lohp-thumb-wrap" data-sessionlink="hdline=1143711036264341250&amp;ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=10886&amp;feature=g-logo">    <span class="video-thumb  yt-thumb yt-thumb-170 yt-thumb-fluid">
                                                <span class="yt-thumb-default">
                                                <span class="yt-thumb-clip">
                                                <img alt="Thumbnail" src="<?php echo $featured_videos[$i]['thumbnail']; ?>" width="170">
                                                <span class="vertical-align"></span>
                                                </span>
                                                </span>
                                                </span>
                                                <button onclick=";return false;" title="Watch Later" class="addto-button video-actions spf-nolink hide-until-delayloaded addto-watch-later-button-sign-in yt-uix-button yt-uix-button-default yt-uix-button-size-small yt-uix-tooltip" type="button" data-video-ids="10886" data-button-menu-id="shared-addto-watch-later-login" role="button"><span class="yt-uix-button-content">  <img src="images/pixel-vfl3z5WfW.gif" alt="Watch Later">
                                                </span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW.gif" alt="" title=""></button>
                                                </a>
                                             </div>
                                             <div class="lohp-media-object-content lohp-medium-shelf-content" bis_skin_checked="1">
                                                <a class="lohp-video-link max-line-1 yt-uix-sessionlink " data-sessionlink="hdline=1143711036264341250&amp;ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=10886&amp;feature=g-logo" href="watch.php?id=<?php echo $featured_videos[$i]['id']; ?>" title="bitview.mp4"><?php echo $featured_videos[$i]['title']; ?></a>
                                                <div class="lohp-video-metadata attached" bis_skin_checked="1">
                                                   <span class="content-uploader spf-nolink">
                                                   <span class="username-prepend">by</span> <a href="/channel?user_id=<?php echo $featured_videos[0]['user_id']; ?>" class="g-hovercard yt-uix-sessionlink yt-user-name " data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ" dir="ltr" data-ytid="UCLN8H0cLurGAUgwwufetV3Q" data-name=""><?php echo $featured_videos[$i]['username']; ?></a><span class="yt-user-name-icon-verified">
                                                   </span>  </span>
                                                </div>
                                                <p title="" class="lohp-blog-headline">
                                                </p>
                                             </div>
                                          </div>
                                        <?php endfor; ?>
                                       </div>
                                       <?php endif; ?>

                                    </div>
                                 </div>
                                                                  <div class="lohp-vbox-list vve-check lohp-left-vbox-list" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCAQ1R4oAQ">
                                    <div class="vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCEQyx4oAA">
                                       <div style="height:auto;" class="lohp-shelf-cell-container lohp-category-shelf vve-check last-shelf-in-line" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCIQzR4oAA" bis_skin_checked="1">
                                          <div class="lohp-category-shelf-item-list lohp-shelf-size-3" bis_skin_checked="1">
                                             <h2 class="branded-page-module-title">
                                                <a class="yt-uix-sessionlink branded-page-module-title-link spf-nolink" href="/user/SigmaVid/" title="Videos Being Watched Now" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCMQzh4">
                                                What Everyone's Watching
                                                </a>
                                             </h2>
                                             <?php if (!empty($last_viewed_videos)): ?>
                                            <?php foreach (array_slice($last_viewed_videos, 0, 3) as $video): ?>
                                             <div style="height:150px;"class="lohp-category-shelf-item context-data-item first-shelf-item " data-context-item-id="10938" data-context-item-views="2 views" data-context-item-type="video" data-context-item-time="1:20" data-context-item-title="1 sec vids" data-context-item-user="" bis_skin_checked="1">
                                                <a href="watch.php?id=<?php echo $video['id']; ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto lohp-thumb-wrap" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo">    <span class="video-thumb  yt-thumb yt-thumb-189">
                                                <span class="yt-thumb-default">
                                                <span class="yt-thumb-clip">
                                                <img alt="Thumbnail" src="<?php echo $video['thumbnail']; ?>" data-thumb="https://SigmaVidusercontent.0ci.lol/vi/thumb/video-6694a50f371302.40190297.jpg" width="189" data-group-key="thumb-group-0">
                                                <span class="vertical-align"></span>
                                                </span>
                                                </span>
                                                </span>
                                                <button onclick=";return false;" title="Watch Later" class="addto-button video-actions spf-nolink hide-until-delayloaded addto-watch-later-button-sign-in yt-uix-button yt-uix-button-default yt-uix-button-size-small yt-uix-tooltip" type="button" data-video-ids="10938" data-button-menu-id="shared-addto-watch-later-login" role="button"><span class="yt-uix-button-content">  <img src="images/pixel-vfl3z5WfW.gif" alt="Watch Later">
                                                </span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW.gif" alt="" title=""></button>
                                                </a>
                                                <a class="lohp-video-link max-line-2 yt-uix-sessionlink " data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo" href="watch.php?id=<?php echo $video['id']; ?>" title="1 sec vids"><?php echo htmlspecialchars($video['title']); ?></a>
                                                <div class="lohp-video-metadata" bis_skin_checked="1">
                                                   <span class="view-count">
                                                   <?php echo $video['views']; ?> views
                                                   </span>
                                                   <span class="content-item-time-created" title="18 mins ago">
                                                   <?php echo $video['time_ago']; ?>    </span>
                                                </div>
                                             </div>
                                              <?php endforeach; ?>
<?php else: ?>
    <p>No recently uploaded videos available.</p>
<?php endif; ?>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                                                  <div class="lohp-vbox-list vve-check lohp-left-vbox-list" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCAQ1R4oAQ">
                                    <div class="vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCEQyx4oAA">
                                       <div style="height:auto;" class="lohp-shelf-cell-container lohp-category-shelf vve-check last-shelf-in-line" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCIQzR4oAA" bis_skin_checked="1">
                                          <div class="lohp-category-shelf-item-list lohp-shelf-size-3" bis_skin_checked="1">
                                             <h2 class="branded-page-module-title">
                                                <a class="yt-uix-sessionlink branded-page-module-title-link spf-nolink" href="/user/SigmaVid/" title="Videos Being Watched Now" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCMQzh4">
                                                Recommended
                                                </a>
                                             </h2>
                                             <?php if (!empty($random_videos)): ?>
                                            <?php foreach (array_slice($random_videos, 0, 3) as $video): ?>
                                             <div style="height:150px;"class="lohp-category-shelf-item context-data-item first-shelf-item " data-context-item-id="10938" data-context-item-views="2 views" data-context-item-type="video" data-context-item-time="1:20" data-context-item-title="1 sec vids" data-context-item-user="" bis_skin_checked="1">
                                                <a href="watch.php?id=<?php echo $video['id']; ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto lohp-thumb-wrap" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo">    <span class="video-thumb  yt-thumb yt-thumb-189">
                                                <span class="yt-thumb-default">
                                                <span class="yt-thumb-clip">
                                                <img alt="Thumbnail" src="<?php echo $video['thumbnail']; ?>" data-thumb="https://SigmaVidusercontent.0ci.lol/vi/thumb/video-6694a50f371302.40190297.jpg" width="189" data-group-key="thumb-group-0">
                                                <span class="vertical-align"></span>
                                                </span>
                                                </span>
                                                </span>
                                                <button onclick=";return false;" title="Watch Later" class="addto-button video-actions spf-nolink hide-until-delayloaded addto-watch-later-button-sign-in yt-uix-button yt-uix-button-default yt-uix-button-size-small yt-uix-tooltip" type="button" data-video-ids="10938" data-button-menu-id="shared-addto-watch-later-login" role="button"><span class="yt-uix-button-content">  <img src="images/pixel-vfl3z5WfW.gif" alt="Watch Later">
                                                </span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW.gif" alt="" title=""></button>
                                                </a>
                                                <a class="lohp-video-link max-line-2 yt-uix-sessionlink " data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo" href="watch.php?id=<?php echo $video['id']; ?>" title="1 sec vids"><?php echo htmlspecialchars($video['title']); ?></a>
                                                <div class="lohp-video-metadata" bis_skin_checked="1">
                                                   <span class="view-count">
                                                   <?php echo $video['views']; ?> views
                                                   </span>
                                                   <span class="content-item-time-created" title="18 mins ago">
                                                   <?php echo $video['time_ago']; ?>    </span>
                                                </div>
                                             </div>
                                              <?php endforeach; ?>
<?php else: ?>
    <p>No recently uploaded videos available.</p>
<?php endif; ?>
                                          </div>
                                       </div>
                                    </div>
                                 </div>

                                 <div class="lohp-vbox-list vve-check lohp-left-vbox-list" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCAQ1R4oAQ">
                                    <div class="vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCEQyx4oAA">
                                       <div style="height:auto;" class="lohp-shelf-cell-container lohp-category-shelf vve-check last-shelf-in-line" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCIQzR4oAA" bis_skin_checked="1">
                                          <div class="lohp-category-shelf-item-list lohp-shelf-size-3" bis_skin_checked="1">
                                             <h2 class="branded-page-module-title">
                                                <a class="yt-uix-sessionlink branded-page-module-title-link spf-nolink" href="/user/SigmaVid/" title="Videos Being Watched Now" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCMQzh4">
                                                What's New
                                                </a>
                                             </h2>
                                             <?php if (!empty($recent_videos)): ?>
                                            <?php foreach (array_slice($recent_videos, 0, 6) as $video): ?>
                                             <div style="height:150px;"class="lohp-category-shelf-item context-data-item first-shelf-item " data-context-item-id="10938" data-context-item-views="2 views" data-context-item-type="video" data-context-item-time="1:20" data-context-item-title="1 sec vids" data-context-item-user="" bis_skin_checked="1">
                                                <a href="watch.php?id=<?php echo $video['id']; ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto lohp-thumb-wrap" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo">    <span class="video-thumb  yt-thumb yt-thumb-189">
                                                <span class="yt-thumb-default">
                                                <span class="yt-thumb-clip">
                                                <img alt="Thumbnail" src="<?php echo $video['thumbnail']; ?>" data-thumb="https://SigmaVidusercontent.0ci.lol/vi/thumb/video-6694a50f371302.40190297.jpg" width="189" data-group-key="thumb-group-0">
                                                <span class="vertical-align"></span>
                                                </span>
                                                </span>
                                                </span>
                                                <button onclick=";return false;" title="Watch Later" class="addto-button video-actions spf-nolink hide-until-delayloaded addto-watch-later-button-sign-in yt-uix-button yt-uix-button-default yt-uix-button-size-small yt-uix-tooltip" type="button" data-video-ids="10938" data-button-menu-id="shared-addto-watch-later-login" role="button"><span class="yt-uix-button-content">  <img src="images/pixel-vfl3z5WfW.gif" alt="Watch Later">
                                                </span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW.gif" alt="" title=""></button>
                                                </a>
                                                <a class="lohp-video-link max-line-2 yt-uix-sessionlink " data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo" href="watch.php?id=<?php echo $video['id']; ?>" title="1 sec vids"><?php echo htmlspecialchars($video['title']); ?></a>
                                                <div class="lohp-video-metadata" bis_skin_checked="1">
                                                   <span class="view-count">
                                                   <?php echo $video['views']; ?> views
                                                   </span>
                                                   <span class="content-item-time-created" title="18 mins ago">
                                                   <?php echo $video['time_ago']; ?>    </span>
                                                </div>
                                             </div>
                                              <?php endforeach; ?>
<?php else: ?>
    <p>No recent uploads available.</p>
<?php endif; ?>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 
                                 <div class="lohp-vbox-list vve-check lohp-right-vbox-list" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CGcQ1R4oAg">
                                    <div class="lohp-vertical-shelf vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CHwQzR4oAg">
                                       <h2 class="branded-page-module-title">
                                          <a class="yt-uix-sessionlink branded-page-module-title-link spf-nolink" href="/channel/HC4qRk91tndwg" title="Most Popular" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CH0Qzh4">
                                          Popular
                                          </a>
                                       </h2>
                                           <?php if (!empty($popular_videos)): ?>
        <?php foreach ($popular_videos as $video): ?>
                                       <div class="lohp-vertical-shelf-item context-data-item" data-context-item-id="10891" data-context-item-views="460,013 views" data-context-item-type="video" data-context-item-time="1:03" data-context-item-title="Rant: If you eat burgers without cheese you are a CREATURE" data-context-item-user="TestieTorsionGaming">
                                          <div class="lohp-media-object ">
                                             <a href="watch.php?id=<?php echo $video['id']; ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto lohp-thumb-wrap" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CIQBEM8eKAM&amp;feature=g-logo">    <span class="video-thumb  yt-thumb yt-thumb-64">
                                             <span class="yt-thumb-default">
                                             <span class="yt-thumb-clip">
                                             <img alt="Thumbnail" src="<?php echo $video['thumbnail']; ?>" data-thumb="https://SigmaVidusercontent.0ci.lol/vi/thumb/video-669286f0685647.67956299.jpg" width="64">
                                             <span class="vertical-align"></span>
                                             </span>
                                             </span>
                                             </span>
                                             <span class="video-time">1:03</span>
                                             <button onclick=";return false;" title="Watch Later" class="addto-button video-actions spf-nolink hide-until-delayloaded addto-watch-later-button-sign-in yt-uix-button yt-uix-button-default yt-uix-button-size-small yt-uix-tooltip" type="button" data-video-ids="10891" data-button-menu-id="shared-addto-watch-later-login" role="button"><span class="yt-uix-button-content">  <img src="images/pixel-vfl3z5WfW.gif" alt="Watch Later">
                                             </span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW.gif" alt="" title=""></button>
                                             </a>
                                          </div>
                                          <div class="lohp-vertical-shelf-item-content lohp-media-object-content">
                                             <a class="lohp-video-link max-line-3 yt-uix-sessionlink " data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CIQBEM8eKAM&amp;feature=g-logo" href="watch.php?id=<?php echo $video['id']; ?>" title="Rant: If you eat burgers without cheese you are a CREATURE"><?php echo htmlspecialchars($video['title']); ?></a>
                                             <div class="lohp-video-metadata attached">
                                                <span class="content-uploader spf-nolink">
                                                <span class="username-prepend">by</span> <a href="/channel?user_id=<?php echo $video['user_id']; ?>" class="g-hovercard yt-uix-sessionlink yt-user-name " data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ" dir="ltr" data-ytid="UCK8sQmJBp8GCxrOtXWBpyEA" data-name=""><?php echo htmlspecialchars($video['username']); ?></a>
                                                </span>
                                             </div>
                                          </div>
                                       </div>
                                            <?php endforeach; ?>
    <?php else: ?>
        <p>No popular videos available.</p>
    <?php endif; ?>
                                    </div>
                                 </div>
                                 <div style="clear:both;"></div>
                              </div>
                              <div id="footer-ads">
                                 <div id="ad_creative_3" class="ad-div " style="z-index: 1">
                                    <iframe id="ad_creative_iframe_3" height="1" width="1" scrolling="no" frameborder="0" style="z-index: 1" src="http://ad.doubleclick.net/N6762/adi/mkt.ythome_1x1/;sz=1x1;tile=3;dc_yt=1;kga=-1;kgg=-1;klg=en;kmyd=ad_creative_3;ytexp=903802,936905,910207,916611;ord=2125555551578688?"></iframe>
                                    <script>
                                       (function() {
                                         function tagMpuIframe() {
                                               var adIframe = document.getElementById("ad_creative_iframe_3");
                                               if (!adIframe) {
                                                 return;
                                               }
                                               var ord = Math.floor(Math.random() * 10000000000000000);
                                               adIframe.src = "http://ad.doubleclick.net/N6762/adi/mkt.ythome_1x1/;sz=1x1;tile=3;dc_yt=1;kga=-1;kgg=-1;klg=en;kmyd=ad_creative_3;ytexp=903802,936905,910207,916611;ord=" + ord + "?";
                                         }
                                       
                                          tagMpuIframe();
                                       })();
                                    </script>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      