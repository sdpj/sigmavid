<?php 
include 'db.php'; // Ensure db.php sets up the $conn variable correctly

function getTimeAgoString2($uploaded_at) {
    try {
        $now = new DateTime();
        $uploadedDate = new DateTime($uploaded_at);
        $interval = $now->diff($uploadedDate);

        if ($interval->y > 0) {
            return $interval->y . ' years ago';
        } elseif ($interval->m > 0) {
            return $interval->m . ' months ago';
        } elseif ($interval->d > 0) {
            return $interval->d . ' days ago';
        } elseif ($interval->h > 0) {
            return $interval->h . ' hours ago';
        } elseif ($interval->i > 0) {
            return $interval->i . ' minutes ago';
        } else {
            return $interval->s . ' seconds ago';
        }
    } catch (Exception $e) {
        // Log or display error message
        return 'Error calculating time ago';
    }
}

function isTrending($uploaded_at) {
    try {
        $now = new DateTime();
        $uploadedDate = new DateTime($uploaded_at);
        $interval = $now->diff($uploadedDate);

        return ($interval->d < 3);
    } catch (Exception $e) {
        // Log or display error message
        return false;
    }
}

$videos = [];
$userInfoMap = [];
$userVideosMap = [];

// Select a random channel for the first section
$channelSql = "SELECT DISTINCT user_id FROM videos ORDER BY RAND() LIMIT 1";
$channelResult = $conn->query($channelSql);

if ($channelResult->num_rows > 0) {
    // Get the channel ID
    $channelRow = $channelResult->fetch_assoc();
    $channelId = $channelRow['user_id'];

    // Fetch the most recent videos from the selected channel
    $videoSql = "SELECT * FROM videos WHERE user_id = '$channelId' ORDER BY uploaded_at DESC LIMIT 2"; // Fetch more videos to display in chunks
    $videoResult = $conn->query($videoSql);

    if ($videoResult->num_rows > 0) {
        // Fetch the video details and group by user
        while ($row = $videoResult->fetch_assoc()) {
            $videos[] = $row;
            // Map videos to user_id
            if (!isset($userVideosMap[$row['user_id']])) {
                $userVideosMap[$row['user_id']] = [];
            }
            $userVideosMap[$row['user_id']][] = $row;
            // Collect unique user IDs
            $userInfoMap[$row['user_id']] = null;
        }
    } else {
        echo "No recent videos found for the selected channel.";
    }
} else {
    echo "No channels found.";
}

// Select a different random channel for the second section
$popularChannelSql = "SELECT DISTINCT user_id FROM videos WHERE user_id != '$channelId' ORDER BY RAND() LIMIT 1";
$popularChannelResult = $conn->query($popularChannelSql);

$popularVideos = [];
if ($popularChannelResult->num_rows > 0) {
    // Get the channel ID
    $popularChannelRow = $popularChannelResult->fetch_assoc();
    $popularChannelId = $popularChannelRow['user_id'];

    // Fetch the most popular videos from the selected channel
    $popularVideoSql = "SELECT * FROM videos WHERE user_id = '$popularChannelId' ORDER BY views DESC LIMIT 3";
    $popularVideoResult = $conn->query($popularVideoSql);

    if ($popularVideoResult->num_rows > 0) {
        // Fetch the video details and group by user
        while ($row = $popularVideoResult->fetch_assoc()) {
            $popularVideos[] = $row;
            // Collect unique user IDs
            if (!isset($userInfoMap[$row['user_id']])) {
                $userInfoMap[$row['user_id']] = null;
            }
            $userInfoMap[$row['user_id']] = $row['user_id'];
        }
    } else {
        echo "No popular videos found for the selected channel.";
    }
} else {
    echo "No channels found.";
}

// Select random videos for the third section
$randomVideoSql = "SELECT * FROM videos ORDER BY RAND() LIMIT 3";
$randomVideoResult = $conn->query($randomVideoSql);

$randomVideos = [];
if ($randomVideoResult->num_rows > 0) {
    while ($row = $randomVideoResult->fetch_assoc()) {
        $randomVideos[] = $row;
        // Collect unique user IDs
        if (!isset($userInfoMap[$row['user_id']])) {
            $userInfoMap[$row['user_id']] = null;
        }
        $userInfoMap[$row['user_id']] = $row['user_id'];
    }
} else {
    echo "No random videos found.";
}

// Fetch trending videos
$trendingVideoSql = "SELECT * FROM videos WHERE uploaded_at >= NOW() - INTERVAL 3 DAY ORDER BY views DESC LIMIT 3";
$trendingVideoResult = $conn->query($trendingVideoSql);

$trendingVideos = [];
if ($trendingVideoResult->num_rows > 0) {
    while ($row = $trendingVideoResult->fetch_assoc()) {
        $trendingVideos[] = $row;
        // Collect unique user IDs
        if (!isset($userInfoMap[$row['user_id']])) {
            $userInfoMap[$row['user_id']] = null;
        }
        $userInfoMap[$row['user_id']] = $row['user_id'];
    }
} else {
    echo "No trending videos found.";
}

// Fetch videos sorted by upload date
$recentUploadSql = "SELECT * FROM videos ORDER BY uploaded_at DESC LIMIT 3";
$recentUploadResult = $conn->query($recentUploadSql);

$recentUploads = [];
if ($recentUploadResult->num_rows > 0) {
    while ($row = $recentUploadResult->fetch_assoc()) {
        $recentUploads[] = $row;
        // Collect unique user IDs
        if (!isset($userInfoMap[$row['user_id']])) {
            $userInfoMap[$row['user_id']] = null;
        }
        $userInfoMap[$row['user_id']] = $row['user_id'];
    }
} else {
    echo "No recent uploads found.";
}

// Fetch all unique user information in one query
if (!empty($userInfoMap)) {
    $userIds = implode(',', array_map('intval', array_keys($userInfoMap)));
    $userSql = "SELECT * FROM users WHERE id IN ($userIds)";
    $userResult = $conn->query($userSql);

    if ($userResult->num_rows > 0) {
        while ($userRow = $userResult->fetch_assoc()) {
            $userInfoMap[$userRow['id']] = $userRow;
        }
    }
}

function getUserInfo($userid) {
    global $userInfoMap;
    return isset($userInfoMap[$userid]) ? $userInfoMap[$userid] : [];
}
?>


<link class="www-core" rel="stylesheet" href="css/yt-framework.css" data-loaded="true">

<div class="branded-page-v2-container branded-page-v2-secondary-column-hidden" style="width:83%;">
    <div class="branded-page-v2-col-container">
        <div class="branded-page-v2-col-container-inner">
            <div class="branded-page-v2-primary-col" style="border-top:0;border-bottom:0;">
                <div class="branded-page-v2-primary-col-header-container branded-page-v2-primary-column-content">
                    <div id="context-source-container" data-context-source="Popular on SigmaVid" style="display:none;"></div>
                </div>
                <div class="bro">
                    <!--<div class="tabbable" style="border-bottom:1px solid #e2e2e2;width:100%;">
                        <ul class="yt-tabs ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" style="max-width:800px;width:100%;" role="tablist">
                            <li style="margin-bottom:0px;" class="ui-state-default ui-corner-top ui-tabs-active ui-state-active" role="tab" tabindex="0" aria-controls="about" aria-labelledby="ui-id-1" aria-selected="true">
                                <a href="#about" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="ui-id-1">Uploads only</a>
                            </li>
                        </ul>
                    </div>
					-->
					<?php if (!empty($trendingVideos)): ?>
                        <div class="section" id="section3" style="margin-top:15px;height:220px;margin-left:10px;">
                            <div class="userinfo" style="display:flex;gap:6px;">
                                <div style="border:1px solid #e2e2e2;">
                                    <img style="width:35px;height:35px;object-fit:cover;padding:5px;" src="images/trending.png">
                                </div>
                                <p style="margin-top:auto;margin-bottom:auto;">Trending</p>
                            </div>
                            <div id="videos" style="height:155px; list-style-type: none;margin-left:55px;">
                                <?php foreach ($trendingVideos as $video): ?>
                                    <div style="height: 150px;width:195px;" id="video" class="lohp-category-shelf-item context-data-item first-shelf-item" data-context-item-id="10938" data-context-item-views="<?php echo number_format($video['views']); ?> views" data-context-item-type="video" data-context-item-time="<?php echo $video['duration']; ?>" data-context-item-title="<?php echo htmlspecialchars($video['title']); ?>" data-context-item-user="<?php echo htmlspecialchars($video['username']); ?>" bis_skin_checked="1">
                                        <a href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto lohp-thumb-wrap" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo">
                                            <span class="video-thumb yt-thumb yt-thumb-189">
                                                <span class="yt-thumb-default">
                                                    <span class="yt-thumb-clip">
                                                        <img alt="Thumbnail" src="<?php echo htmlspecialchars($video['thumbnail']); ?>" data-thumb="<?php echo htmlspecialchars($video['thumbnail']); ?>" width="189" />
                                                        <span class="vertical-align"></span>
                                                    </span>
                                                </span>
                                            </span>
                                            <button>
                                                <span class="yt-uix-button-content"> <img src="images/pixel-vfl3z5WfW.gif" alt="Watch Later" /> </span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW.gif" alt="" title="" />
                                            </button>
                                        </a>
                                        <a style="text-overflow:ellipsis;height:15px;" class="lohp-video-link max-line-2 yt-uix-sessionlink" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo" href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>" title="<?php echo htmlspecialchars($video['title']); ?>"><?php echo htmlspecialchars($video['title']); ?></a>
                                        <div class="lohp-video-metadata" bis_skin_checked="1">
                                            <span class="view-count"><?php echo number_format($video['views']); ?> views</span>
                                            <span class="content-item-time-created" title="<?php echo getTimeAgoString2($video['uploaded_at']); ?>"> <?php echo getTimeAgoString2($video['uploaded_at']); ?> </span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <hr style="margin-left:70px;margin-right:30px;" class="guide-section-separator">
                        </div>
                    <?php endif; ?>
										<?php if (!empty($recentUploads)): ?>
                        <div class="section" id="section3" style="height:220px;margin-left:10px;">
                            <div class="userinfo" style="display:flex;gap:6px;">
                                <div style="border:1px solid #e2e2e2;">
                                    <img style="width:35px;height:35px;object-fit:cover;padding:5px;" src="images/UC2s7nUriqurPH0343t8oX.jpg">
                                </div>
                                <p style="margin-top:auto;margin-bottom:auto;">What's New</p>
                            </div>
                            <div id="videos" style="height:155px; list-style-type: none;margin-left:55px;">
                                <?php foreach ($recentUploads as $video): ?>
                                    <div style="height: 150px;width:195px;" id="video" class="lohp-category-shelf-item context-data-item first-shelf-item" data-context-item-id="10938" data-context-item-views="<?php echo number_format($video['views']); ?> views" data-context-item-type="video" data-context-item-time="<?php echo $video['duration']; ?>" data-context-item-title="<?php echo htmlspecialchars($video['title']); ?>" data-context-item-user="<?php echo htmlspecialchars($video['username']); ?>" bis_skin_checked="1">
                                        <a href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto lohp-thumb-wrap" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo">
                                            <span class="video-thumb yt-thumb yt-thumb-189">
                                                <span class="yt-thumb-default">
                                                    <span class="yt-thumb-clip">
                                                        <img alt="Thumbnail" src="<?php echo htmlspecialchars($video['thumbnail']); ?>" data-thumb="<?php echo htmlspecialchars($video['thumbnail']); ?>" width="189" />
                                                        <span class="vertical-align"></span>
                                                    </span>
                                                </span>
                                            </span>
                                            <button>
                                                <span class="yt-uix-button-content"> <img src="images/pixel-vfl3z5WfW.gif" alt="Watch Later" /> </span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW.gif" alt="" title="" />
                                            </button>
                                        </a>
                                        <a style="text-overflow:ellipsis;height:15px;" class="lohp-video-link max-line-2 yt-uix-sessionlink" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo" href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>" title="<?php echo htmlspecialchars($video['title']); ?>"><?php echo htmlspecialchars($video['title']); ?></a>
                                        <div class="lohp-video-metadata" bis_skin_checked="1">
                                            <span class="view-count"><?php echo number_format($video['views']); ?> views</span>
                                            <span class="content-item-time-created" title="<?php echo getTimeAgoString2($video['uploaded_at']); ?>"> <?php echo getTimeAgoString2($video['uploaded_at']); ?> </span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <hr style="margin-left:70px;margin-right:30px;" class="guide-section-separator">
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($userVideosMap)): ?>
                        <?php foreach ($userVideosMap as $userId => $userVideos): ?>
                            <div class="section" id="section1" style="margin-left:10px;">
                                <?php 
                                $userInfo = getUserInfo($userId); 
                                // Display user info once per section
                                ?>
                                <div class="userinfo" style="display:flex;gap:6px;">
                                    <div style="border:1px solid #e2e2e2;">
                                        <img style="width:35px;height:35px;object-fit:cover;padding:5px;" src="<?php echo $userInfo['profile_picture'] ?>">
                                    </div>
                                    <p style="margin-top:auto;margin-bottom:auto;"><?php echo $userInfo['username']; ?> posted</p>
                                </div>
                                <?php 
                                // Display videos for the user
                                foreach (array_chunk($userVideos, 2) as $videoChunk): 
                                    foreach ($videoChunk as $video): ?>
                                        <div id="videos" style="height:110px; list-style-type: none;margin-left:55px;" class="yt-lockup clearfix yt-uix-tile result-item-padding yt-lockup-video yt-lockup-tile context-data-item" data-context-item-views="1390 views" data-context-item-time="" data-context-item-title="bora toma uma" data-context-item-user="dreckin1" data-context-item-id="PaCGHPGQC9Q" data-context-item-type="video">
                                            <div class="yt-lockup-thumbnail" bis_skin_checked="1">
                                                <a href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto" data-sessionlink="ei=KN8qUvqxI-OgkgKarYGYDw&amp;ved=CAUQwBs">
                                                    <span class="video-thumb yt-thumb yt-thumb-185">
                                                        <span class="yt-thumb-default">
                                                            <span class="yt-thumb-clip">
                                                                <span class="yt-thumb-clip-inner">
                                                                    <img src="<?php echo htmlspecialchars($video['thumbnail']); ?>" alt="Thumbnail" width="185">
                                                                    <span class="vertical-align"></span>
                                                                </span>
                                                            </span>
                                                        </span>
                                                    </span>
                                                    <button type="button" title="Watch Later" class="addto-button video-actions spf-nolink addto-watch-later-button-sign-in yt-uix-button yt-uix-button-default yt-uix-button-size-small yt-uix-tooltip" onclick=";return false;" data-video-ids="PaCGHPGQC9Q" data-button-menu-id="shared-addto-watch-later-login" role="button">
                                                        <span class="yt-uix-button-content">
                                                            <img src="//web.archive.org/web/20130907080912im_/http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="Watch Later">
                                                        </span>
                                                        <img class="yt-uix-button-arrow" src="https://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="" title="">
                                                    </button>
                                                </a>
                                            </div>
                                            <div class="yt-lockup-content" bis_skin_checked="1">
                                                <h3 class="yt-lockup-title">
                                                    <a class="yt-uix-sessionlink yt-uix-tile-link yt-ui-ellipsis yt-ui-ellipsis-2" data-sessionlink="ei=KN8qUvqxI-OgkgKarYGYDw&amp;ved=CAUQwBs" title="bora toma uma" href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>">
                                                        <?php echo htmlspecialchars($video['title']); ?>
                                                    </a>
                                                </h3>
                                                <div class="yt-lockup-description yt-ui-ellipsis yt-ui-ellipsis-2">
                                                    <?php echo htmlspecialchars($video['description']); ?>
                                                </div>
                                                <div class="yt-lockup-meta">
                                                    <ul class="yt-lockup-meta-info">
                                                        <li><?php echo getTimeAgoString2($video['uploaded_at']); ?></li>
                                                        <li><?php echo number_format($video['views']) . ' views'; ?></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                    <hr>
                                <?php endforeach; ?>
							<hr style="margin-left:70px;margin-right:30px;" class="guide-section-separator">
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <?php if (!empty($popularVideos)): ?>
                        <div class="section" id="section2" style="height:220px;margin-left:10px;">
                            <?php
                            $popularUserInfo = getUserInfo($popularChannelId);
                            ?>
                            <div class="userinfo" style="display:flex;gap:6px;">
                                <div style="border:1px solid #e2e2e2;">
                                    <img style="width:35px;height:35px;object-fit:cover;padding:5px;" src="<?php echo $popularUserInfo['profile_picture'] ?>">
                                </div>
                                <p style="margin-top:auto;margin-bottom:auto;">Popular videos from <?php echo $popularUserInfo['username']; ?></p>
                            </div>
                            <div id="videos" style="height:155px; list-style-type: none;margin-left:55px;">
                                <?php foreach ($popularVideos as $video): ?>
                                    <div style="height: 150px;width:195px;" id="video" class="lohp-category-shelf-item context-data-item first-shelf-item" data-context-item-id="10938" data-context-item-views="<?php echo number_format($video['views']); ?> views" data-context-item-type="video" data-context-item-time="<?php echo $video['duration']; ?>" data-context-item-title="<?php echo htmlspecialchars($video['title']); ?>" data-context-item-user="<?php echo htmlspecialchars($video['username']); ?>" bis_skin_checked="1">
                                        <a href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto lohp-thumb-wrap" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo">
                                            <span class="video-thumb yt-thumb yt-thumb-189">
                                                <span class="yt-thumb-default">
                                                    <span class="yt-thumb-clip">
                                                        <img alt="Thumbnail" src="<?php echo htmlspecialchars($video['thumbnail']); ?>" data-thumb="<?php echo htmlspecialchars($video['thumbnail']); ?>" width="189" />
                                                        <span class="vertical-align"></span>
                                                    </span>
                                                </span>
                                            </span>
                                            <button>
                                                <span class="yt-uix-button-content"> <img src="images/pixel-vfl3z5WfW.gif" alt="Watch Later" /> </span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW.gif" alt="" title="" />
                                            </button>
                                        </a>
                                        <a style="text-overflow:ellipsis;height:15px;" class="lohp-video-link max-line-2 yt-uix-sessionlink" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo" href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>" title="<?php echo htmlspecialchars($video['title']); ?>"><?php echo htmlspecialchars($video['title']); ?></a>
                                        <div class="lohp-video-metadata" bis_skin_checked="1">
                                            <span class="view-count"><?php echo number_format($video['views']); ?> views</span>
                                            <span class="content-item-time-created" title="<?php echo getTimeAgoString2($video['uploaded_at']); ?>"> <?php echo getTimeAgoString2($video['uploaded_at']); ?> </span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <hr style="margin-left:70px;margin-right:30px;" class="guide-section-separator">
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($randomVideos)): ?>
                        <div class="section" id="section3" style="height:220px;margin-left:10px;">
                            <div class="userinfo" style="display:flex;gap:6px;">
                                <div style="border:1px solid #e2e2e2;">
                                    <img style="width:35px;height:35px;object-fit:cover;padding:5px;" src="images/UCjg7K9dXbITL7Rfq5jDly.jpg">
                                </div>
                                <p style="margin-top:auto;margin-bottom:auto;">Recommended for you</p>
                            </div>
                            <div id="videos" style="height:155px; list-style-type: none;margin-left:55px;">
                                <?php foreach ($randomVideos as $video): ?>
                                    <div style="height: 150px;width:195px;" id="video" class="lohp-category-shelf-item context-data-item first-shelf-item" data-context-item-id="10938" data-context-item-views="<?php echo number_format($video['views']); ?> views" data-context-item-type="video" data-context-item-time="<?php echo $video['duration']; ?>" data-context-item-title="<?php echo htmlspecialchars($video['title']); ?>" data-context-item-user="<?php echo htmlspecialchars($video['username']); ?>" bis_skin_checked="1">
                                        <a href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto lohp-thumb-wrap" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo">
                                            <span class="video-thumb yt-thumb yt-thumb-189">
                                                <span class="yt-thumb-default">
                                                    <span class="yt-thumb-clip">
                                                        <img alt="Thumbnail" src="<?php echo htmlspecialchars($video['thumbnail']); ?>" data-thumb="<?php echo htmlspecialchars($video['thumbnail']); ?>" width="189" />
                                                        <span class="vertical-align"></span>
                                                    </span>
                                                </span>
                                            </span>
                                            <button>
                                                <span class="yt-uix-button-content"> <img src="images/pixel-vfl3z5WfW.gif" alt="Watch Later" /> </span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW.gif" alt="" title="" />
                                            </button>
                                        </a>
                                        <a style="text-overflow:ellipsis;height:15px;" class="lohp-video-link max-line-2 yt-uix-sessionlink" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CCQQzx4oAA&amp;feature=g-logo" href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>" title="<?php echo htmlspecialchars($video['title']); ?>"><?php echo htmlspecialchars($video['title']); ?></a>
                                        <div class="lohp-video-metadata" bis_skin_checked="1">
                                            <span class="view-count"><?php echo number_format($video['views']); ?> views</span>
                                            <span class="content-item-time-created" title="<?php echo getTimeAgoString2($video['uploaded_at']); ?>"> <?php echo getTimeAgoString2($video['uploaded_at']); ?> </span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <hr style="margin-left:70px;margin-right:30px;" class="guide-section-separator">
                        </div>
                    <?php endif; ?>
					                        <div class="section" id="section2" style="height:220px;margin-left:auto;margin-right:auto;width:50.8px;margin-top:10px;">
					<button id="more" class="yt-button">More</button>
					
<script type="text/javascript">
    document.getElementById("more").onclick = function () {
        location.href = "https://sigmavid.nugg3t.xyz/?more=true";
    };
</script>
</div>
                </div>
            </div>
        </div>
    </div>
</div>
