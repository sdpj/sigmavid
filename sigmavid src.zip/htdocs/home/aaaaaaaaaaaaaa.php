<?php include '/siteinfo.php'; ?>

