<?php
session_start(); // Start the session

// Assuming you have a database connection file
include '../db.php'; // Ensure the path is correct

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (isset($_SESSION['user_id']) && isset($_POST['layout_home'])) {
    $userIdLayout = $_SESSION['user_id'];
    $layoutHome = (int)$_POST['layout_home'];
    
    // Debugging output
    error_log("User ID: " . $userIdLayout);
    error_log("Layout Home: " . $layoutHome);

    // Update the layout_home value in the database
    $stmt = $conn->prepare("UPDATE users SET layout_home = ? WHERE id = ?");
    $stmt->bind_param("ii", $layoutHome, $userIdLayout);
    if ($stmt->execute()) {
        echo "Layout preference saved.";
    } else {
        echo "Error saving layout preference.";
    }
    $stmt->close();
} else {
    echo "User not logged in or layout not set.";
}

$conn->close();
?>
