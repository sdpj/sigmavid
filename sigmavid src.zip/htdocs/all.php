<?php
session_start(); // Start the session
include 'check_maintenance.php';
include 'check_ban.php';
include 'ip.php';
include 'db.php';

// Function to get time ago string
function getTimeAgoString($video)
{
    if ($video['years_ago'] > 0) {
        return $video['years_ago'] . ' years ago';
    } elseif ($video['months_ago'] > 0) {
        return $video['months_ago'] . ' months ago';
    } elseif ($video['weeks_ago'] > 0) {
        return $video['weeks_ago'] . ' weeks ago';
    } elseif ($video['days_ago'] > 0) {
        return $video['days_ago'] . ' days ago';
    } elseif ($video['hours_ago'] > 0) {
        return $video['hours_ago'] . ' hours ago';
    } elseif ($video['minutes_ago'] > 0) {
        return $video['minutes_ago'] . ' minutes ago';
    } else {
        return $video['seconds_ago'] . ' seconds ago';
    }
}

// Fetch user details if logged in
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user = null;

function getSubscriberCount($userId, $conn) {
    $userId = mysqli_real_escape_string($conn, $userId);
    $query = "SELECT COUNT(*) AS subscriber_count FROM subscriptions WHERE user_id = '$userId'";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);
    return $data['subscriber_count'];
}

// Fetch subscriber count for the logged-in user if available
$subscriberCount = 0; // Default value

if ($user_id) {
    // Fetch user details from the database
    $stmt_user = $conn->prepare("SELECT id, username, profile_picture FROM users WHERE id = ?");
    $stmt_user->bind_param("i", $user_id);
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();
    $loggedInUserId = $_SESSION['user_id'];
    $subscriberCount = getSubscriberCount($loggedInUserId, $conn);
    
    if ($result_user->num_rows > 0) {
        $user = $result_user->fetch_assoc();
    }
    $stmt_user->close();
}







// Fetch featured videos with thumbnails, usernames, and upload time ago
$stmt_featured = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    WHERE v.is_featured = 1
    ORDER BY v.id DESC
    LIMIT 4
");
$stmt_featured->execute();
$result_featured = $stmt_featured->get_result();
$featured_videos = [];
while ($row = $result_featured->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $featured_videos[] = $row;
}
$stmt_featured->close();

// Fetch up to 6 most recent videos with thumbnails, usernames, and upload time ago, sorted by upload time
$stmt_recent = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    WHERE v.is_featured = 0
    ORDER BY v.uploaded_at DESC
    LIMIT 6
");
$stmt_recent->execute();
$result_recent = $stmt_recent->get_result();
$recent_videos = [];
while ($row = $result_recent->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $recent_videos[] = $row;
}
$stmt_recent->close();

// Fetch up to 3 videos sorted by last_viewed_time
$stmt_last_viewed = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    ORDER BY v.last_viewed_time DESC
    LIMIT 3
");
$stmt_last_viewed->execute();
$result_last_viewed = $stmt_last_viewed->get_result();
$last_viewed_videos = [];
while ($row = $result_last_viewed->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $last_viewed_videos[] = $row;
}
$stmt_last_viewed->close();

// Fetch 3 random videos
$stmt_random_videos = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    ORDER BY RAND()
    LIMIT 3
");
$stmt_random_videos->execute();
$result_random_videos = $stmt_random_videos->get_result();
$random_videos = [];
while ($row = $result_random_videos->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $random_videos[] = $row;
}
$stmt_random_videos->close();


// Fetch up to 8 most popular videos with thumbnails, usernames, and upload time ago, sorted by views
$stmt_popular = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    ORDER BY v.views DESC
    LIMIT 8
");
$stmt_popular->execute();
$result_popular = $stmt_popular->get_result();
$popular_videos = [];
while ($row = $result_popular->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $popular_videos[] = $row;
}
$stmt_popular->close();

$conn->close();
?>