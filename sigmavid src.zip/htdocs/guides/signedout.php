                        <div class="guide-module-content yt-scrollbar">
                           <ul class="guide-toplevel">
                              <li class="guide-section vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CAIQ5isoAA">
                                 <div class="guide-item-container personal-item">
                                    <ul class="guide-user-links yt-box">
                                       <li class="vve-check guide-channel" id="HCtnHdj3df7iM-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/user/popular" title="Popular on SigmaVid" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="images/UCjg7K9dXbITL7Rfq5jDly.jpg" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span>Popular on SigmaVid</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                       <li class="vve-check guide-channel" id="UC-9-kyTW8ZkZNDHQJ6FgpwQ-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/user/Music" title="Music" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="UC-9-kyTW8ZkZNDHQJ6FgpwQ" data-serialized-endpoint="0qDduQEaEhhVQy05LWt5VFc4WmtaTkRIUUo2Rmdwd1E%3D">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="images/71.jpg" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span>Music</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                       <li class="vve-check guide-channel" id="HChfZhJdhTqX8-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/user/Gaming" title="Gaming" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HChfZhJdhTqX8" data-serialized-endpoint="0qDduQEPEg1IQ2hmWmhKZGhUcVg4">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="images/UCJnrnDWpPPfyfIIQ4wLiN.jpg" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span>Gaming</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                       <li class="vve-check guide-channel" id="HChfZhJdhTqX8-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/user/News" title="News" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HChfZhJdhTqX8" data-serialized-endpoint="0qDduQEPEg1IQ2hmWmhKZGhUcVg4">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="images/UC2s7nUriqurPH0343t8oX.jpg" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span>News</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                       <li class="vve-check guide-channel" id="UCBR8-60-B28hp2BmDPdntcQ-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/user/SigmaVid" title="Spotlight" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="UCBR8-60-B28hp2BmDPdntcQ" data-serialized-endpoint="0qDduQEaEhhVQ0JSOC02MC1CMjhocDJCbURQZG50Y1E%3D">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="images/UC0wYm3ncbxqDKrA6rnFhZ.jpg" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span>Spotlight</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                    </ul>
                                 </div>
                                 <hr class="guide-section-separator">
                              </li>
                              <li class="guide-section vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CA0Q5isoAQ">
                                 <div class="guide-item-container personal-item">
                                    <h3><?php echo $heading; ?></h3>
                                    <ul class="guide-user-links yt-box">
                                            <?php if (!empty($random_channels)): ?>
                                                        <?php foreach ($random_channels as $channel): ?>
                                       <li class="vve-check guide-channel" id="UCujCZYL7mpAMHeBups0yTsA-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/channel?user_id=<?php echo $channel['id']; ?>" title="SigmaVid Spotlight">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="<?php echo $channel['profile_picture']; ?>" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span><?php echo htmlspecialchars($channel['username']); ?>
                                          </span></span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                                   <?php endforeach; ?>

                                           <?php else: ?>
                                           <p></p>
    <?php endif; ?>
                                    </ul>
                                 </div>
                                 <hr class="guide-section-separator">
                              </li>
                              <li class="guide-section vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CBMQ5isoAg">
                                 <div class="guide-item-container personal-item">
                                    <ul class="guide-user-links yt-box">
                                       <li class="vve-check guide-channel" id="guide_builder-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/channels" title="Browse channels" data-sessionlink="feature=g-manage&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="guide_builder" data-serialized-endpoint="0qPduQECCAE%3D">
                                          <span class="yt-valign-container">
                                          <img class="thumb guide-builder-icon" src="images/pixel-vfl3z5WfW.gif" alt="" title="">
                                          <span class="display-name  no-count">
                                          <span>Browse channels</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                    </ul>
                                 </div>
                              </li>
                            <?php if (!$user): ?>
                              <li class="guide-section guide-header signup-promo guided-help-box">
                                 <p>
                                    Sign in now to see your channels and recommendations!
                                 </p>
                                 <div id="guide-builder-promo-buttons" class="signed-out clearfix">
                                    <a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dsign_in_promo%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="yt-uix-button   yt-uix-sessionlink yt-uix-button-primary yt-uix-button-size-default" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ"><span class="yt-uix-button-content">Sign In </span></a>
                                 </div>
                              </li>
                              <?php endif; ?>
                           </ul>
                        </div>