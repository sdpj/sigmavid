                        <div class="guide-module-content yt-scrollbar">
                           <ul class="guide-toplevel">
                              <li class="guide-section vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CAIQ5isoAA">
                                 <div class="guide-item-container personal-item">
                                    <ul class="guide-user-links yt-box">
                                       <li class="vve-check guide-channel" id="HCtnHdj3df7iM-guide-item">
									   	<?php if ($page == 'Channel ' . $_SESSION['user_id']): ?>
											<a class="guide-item yt-uix-sessionlink yt-valign spf-nolink guide-item-selected" href="/channel?user_id=<?php echo htmlspecialchars($_SESSION['user_id']); ?>" title="<?php echo htmlspecialchars($user_header['username']); ?> on SigmaVid" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										<?php else: ?>
											<a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/channel?user_id=<?php echo htmlspecialchars($_SESSION['user_id']); ?>" title="<?php echo htmlspecialchars($user_header['username']); ?> on SigmaVid" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										<?php endif; ?>
                                          <span class="display-name  no-count">
                                          <span>+<?php echo htmlspecialchars($user_header['username']); ?></span>
                                          </span>
                                          </a>
                                       </li>
									   <li class="vve-check guide-channel" id="HCtnHdj3df7iM-guide-item">
									   	<?php if ($page == 'Watch Later'): ?>
											<a class="guide-item yt-uix-sessionlink yt-valign spf-nolink guide-item-selected" href="/watchlater" title="" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										<?php else: ?>
											<a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/watchlater" title="" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										<?php endif; ?>
                                          <span class="display-name  no-count">
                                          <span>Watch Later</span>
                                          </span>
                                          </a>
                                       </li>
									   <li class="vve-check guide-channel" id="HCtnHdj3df7iM-guide-item">
									   	<?php if ($page == 'History'): ?>
											<a class="guide-item yt-uix-sessionlink yt-valign spf-nolink guide-item-selected" href="/history" title="" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										<?php else: ?>
											<a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/history" title="" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										<?php endif; ?>
										<span class="display-name  no-count">
                                          <span>Watch History</span>
                                          </span>
                                          </a>
                                       </li>
									   <li class="vve-check guide-channel" id="HCtnHdj3df7iM-guide-item">
									   	<?php if ($page == 'Playlists'): ?>
											<a class="guide-item yt-uix-sessionlink yt-valign spf-nolink guide-item-selected" href="/playlists" title="" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										<?php else: ?>
											<a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/playlists" title="" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										<?php endif; ?>                                     
										<span class="display-name  no-count">
                                          <span>Playlists</span>
                                          </span>
                                          </a>
                                       </li>
                                    </ul>
                                 </div>
                                 <hr class="guide-section-separator">
                              </li>
							  <li class="guide-section vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CAIQ5isoAA">
                                 <div class="guide-item-container personal-item">
                                    <ul class="guide-user-links yt-box">
                                       <li class="vve-check guide-channel" id="HCtnHdj3df7iM-guide-item">
									   <?php if ($page == 'Home'): ?>
										    <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink guide-item-selected" href="/" title="<?php echo htmlspecialchars($user_header['username']); ?> on SigmaVid" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										  <?php else: ?>
										    <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/" title="<?php echo htmlspecialchars($user_header['username']); ?> on SigmaVid" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										<?php endif; ?>
                                          <span class="display-name  no-count">
                                          <span>What to watch</span>
                                          </span>
                                          </a>
                                       </li>
									   <li class="vve-check guide-channel" id="HCtnHdj3df7iM-guide-item">
									   									   <?php if ($page == 'Subscriptions'): ?>
										    <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink guide-item-selected" href="subscriptions" title="" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										  <?php else: ?>
										    <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="subscriptions" title="" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										<?php endif; ?>     
                                          <span class="display-name  no-count">
                                          <span>My subscriptions</span>
                                          </span>
                                          </a>
                                       </li>
									   <li class="vve-check guide-channel" id="HCtnHdj3df7iM-guide-item">
									   <?php if ($page == 'Social'): ?>
										    <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink guide-item-selected" href="social" title="" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										  <?php else: ?>
										    <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="social" title="" data-sessionlink="feature=g-channel&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="HCtnHdj3df7iM" data-serialized-endpoint="0qDduQEPEg1IQ3RuSGRqM2RmN2lN">
										<?php endif; ?>                                          
										<span class="display-name  no-count">
                                          <span>Social</span>
                                          </span>
                                          </a>
                                       </li>
                                    </ul>
                                 </div>
                                 <hr class="guide-section-separator">
                              </li>
                              <li class="guide-section vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CA0Q5isoAQ">
                                 <div class="guide-item-container personal-item">
                                    <h3><?php echo $heading; ?></h3>
                                    <ul class="guide-user-links yt-box">
                                            <?php if (!empty($random_channels)): ?>
                                                        <?php foreach ($random_channels as $channel): ?>
                                       <li class="vve-check guide-channel" id="UCujCZYL7mpAMHeBups0yTsA-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/channel?user_id=<?php echo $channel['id']; ?>" title="SigmaVid Spotlight">
                                          <span class="yt-valign-container">
                                          <span class="thumb">    <span class="video-thumb  yt-thumb yt-thumb-18">
                                          <span class="yt-thumb-square">
                                          <span class="yt-thumb-clip">
                                          <img data-group-key="guide-channel-thumbs" alt="Thumbnail" src="<?php echo $channel['profile_picture']; ?>" data-thumb-manual="1" width="18">
                                          <span class="vertical-align"></span>
                                          </span>
                                          </span>
                                          </span>
                                          </span>
                                          <span class="display-name  no-count">
                                          <span><?php echo htmlspecialchars($channel['username']); ?>
                                          </span></span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                                   <?php endforeach; ?>

                                           <?php else: ?>
                                           <p></p>
    <?php endif; ?>
                                    </ul>
                                 </div>
                                 <hr class="guide-section-separator">
                              </li>
                              <li class="guide-section vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CBMQ5isoAg">
                                 <div class="guide-item-container personal-item">
                                    <ul class="guide-user-links yt-box">
                                       <li class="vve-check guide-channel" id="guide_builder-guide-item">
                                          <a class="guide-item yt-uix-sessionlink yt-valign spf-nolink " href="/channels" title="Browse channels" data-sessionlink="feature=g-manage&amp;ei=yyOdUvWjKJOziAKBy4HABQ" data-external-id="guide_builder" data-serialized-endpoint="0qPduQECCAE%3D">
                                          <span class="yt-valign-container">
                                          <img class="thumb guide-builder-icon" src="images/pixel-vfl3z5WfW.gif" alt="" title="">
                                          <span class="display-name  no-count">
                                          <span>Browse channels</span>
                                          </span>
                                          </span>
                                          </a>
                                       </li>
                                    </ul>
                                 </div>
                              </li>
                           </ul>
                        </div>