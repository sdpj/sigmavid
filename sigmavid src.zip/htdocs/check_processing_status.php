<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $filename = $_GET['filename'];
    $statusFile = __DIR__ . '/processing_status/' . $filename . '.status';

    if (file_exists($statusFile)) {
        $status = file_get_contents($statusFile);

        if ($status === 'completed') {
            // Retrieve the final filenames
            $newFileName = $filename;
            $thumbnailFile = pathinfo($filename, PATHINFO_FILENAME) . '.jpg';
            echo json_encode([
                'status' => 'completed',
                'newFileName' => $newFileName,
                'thumbnailFile' => $thumbnailFile
            ]);
        } else {
            echo json_encode(['status' => 'processing']);
        }
    } else {
        echo json_encode(['status' => 'processing']);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed.']);
}
?>
