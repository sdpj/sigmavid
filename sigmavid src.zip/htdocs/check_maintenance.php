<?php

include 'db.php'; // Your database connection file

// Check maintenance mode
$query = "SELECT maintenance_mode FROM settings LIMIT 1";
$result = mysqli_query($conn, $query);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    
    if ($row['maintenance_mode']) {
        // Optionally allow admins to bypass maintenance mode
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];
            $query = "SELECT role FROM users WHERE id = $user_id LIMIT 1";
            $result = mysqli_query($conn, $query);

            if ($result) {
                $row = mysqli_fetch_assoc($result);

                if ($row['role'] !== 'admin') {
                    header('Location: maintenance.php'); // Redirect to a maintenance page
                    exit;
                }
            } else {
                // Handle query failure
                echo "Error: " . mysqli_error($conn);
                exit;
            }
        } else {
            // Redirect to maintenance if user_id is not set in the session
            header('Location: maintenance.php');
            exit;
        }
    }
} else {
    // Handle query failure
    echo "Error: " . mysqli_error($conn);
    exit;
}
?>
