<?php
// like.php

// Include database connection
include 'db.php';

// Check if video_id is provided via POST
if (!isset($_POST['video_id'])) {
    echo json_encode(['error' => 'Video ID not provided']);
    exit;
}

// Assume $current_user_id is set (retrieve from session or wherever applicable)
$current_user_id = $_SESSION['user_id']; // Adjust as per your session handling

$video_id = intval($_POST['video_id']); // Sanitize input

// Perform the update (insert like or update if already exists)
$stmt = $conn->prepare("INSERT INTO video_likes (video_id, user_id, status) VALUES (?, ?, 'like') ON DUPLICATE KEY UPDATE status = 'like'");
if ($stmt === false) {
    echo json_encode(['error' => 'Prepare failed: ' . $conn->error]);
    exit;
}
$stmt->bind_param("ii", $video_id, $current_user_id);
if (!$stmt->execute()) {
    echo json_encode(['error' => 'Execute failed: ' . $stmt->error]);
    exit;
}
$stmt->close();

// Get updated like and dislike counts
$response = getLikeDislikeCounts($conn, $video_id);
echo json_encode($response);
exit;

// Function to get like and dislike counts
function getLikeDislikeCounts($conn, $video_id) {
    $like_count_stmt = $conn->prepare("SELECT COUNT(*) FROM video_likes WHERE video_id = ? AND status = 'like'");
    if ($like_count_stmt === false) {
        return ['error' => 'Prepare failed: ' . $conn->error];
    }
    $like_count_stmt->bind_param("i", $video_id);
    if (!$like_count_stmt->execute()) {
        return ['error' => 'Execute failed: ' . $like_count_stmt->error];
    }
    $like_count_stmt->bind_result($likes);
    $like_count_stmt->fetch();
    $like_count_stmt->close();

    $dislike_count_stmt = $conn->prepare("SELECT COUNT(*) FROM video_likes WHERE video_id = ? AND status = 'dislike'");
    if ($dislike_count_stmt === false) {
        return ['error' => 'Prepare failed: ' . $conn->error];
    }
    $dislike_count_stmt->bind_param("i", $video_id);
    if (!$dislike_count_stmt->execute()) {
        return ['error' => 'Execute failed: ' . $dislike_count_stmt->error];
    }
    $dislike_count_stmt->bind_result($dislikes);
    $dislike_count_stmt->fetch();
    $dislike_count_stmt->close();

    return [
        'likeStatus' => 'like',
        'likes' => $likes,
        'dislikes' => $dislikes,
    ];
}
?>
