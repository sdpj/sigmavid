<?php
// Start session
session_start();

// Include database connection
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $video_id = $_POST['video_id'];
    $user_id = $_SESSION['user_id'];
    $action = $_POST['action'];

    // Check if user has already liked or disliked the video
    $stmt_check = $conn->prepare("SELECT status FROM video_likes WHERE video_id = ? AND user_id = ?");
    $stmt_check->bind_param("ii", $video_id, $user_id);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        // User has already liked or disliked, update the status
        $stmt_update = $conn->prepare("UPDATE video_likes SET status = ? WHERE video_id = ? AND user_id = ?");
        $stmt_update->bind_param("sii", $action, $video_id, $user_id);
        $stmt_update->execute();
        $stmt_update->close();
    } else {
        // User is liking or disliking the video for the first time
        $stmt_insert = $conn->prepare("INSERT INTO video_likes (video_id, user_id, status) VALUES (?, ?, ?)");
        $stmt_insert->bind_param("iis", $video_id, $user_id, $action);
        $stmt_insert->execute();
        $stmt_insert->close();
    }
}

// Redirect back to watch.php with video ID
header("Location: watch.php?id=$video_id");
exit();

// Close database connection
$conn->close();
?>
