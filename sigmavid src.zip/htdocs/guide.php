<?php
include 'db.php';

function getChannels($conn) {
    $random_channels = [];

    if (isset($_SESSION['user_id'])) {
        // User is logged in, fetch all subscriptions
        $session_user_id = $_SESSION['user_id'];
        $stmt_subs = $conn->prepare("
            SELECT u.id, u.username, u.profile_picture
            FROM subscriptions s
            JOIN users u ON s.user_id = u.id
            WHERE s.subscriber_id = ?
        ");
        if (!$stmt_subs) {
            // Error handling: Output the SQL error for debugging
            die('Subscription SQL prepare error: ' . $conn->error);
        }

        $stmt_subs->bind_param("i", $session_user_id);
        $stmt_subs->execute();
        $result_subs = $stmt_subs->get_result();

        while ($row = $result_subs->fetch_assoc()) {
            $random_channels[] = $row;
        }

        $stmt_subs->close();
        $heading = "Subscriptions"; // Change heading string when logged in
    } else {
        // User is not logged in, limit to 3 random channels
        $stmt_random = $conn->prepare("
            SELECT id, username, profile_picture
            FROM users
            ORDER BY RAND()
            LIMIT 3
        ");
        if (!$stmt_random) {
            // Error handling: Output the SQL error for debugging
            die('Random channels SQL prepare error: ' . $conn->error);
        }

        $stmt_random->execute();
        $result_random = $stmt_random->get_result();

        while ($row = $result_random->fetch_assoc()) {
            $random_channels[] = $row;
        }

        $stmt_random->close();
        $heading = "Channels for you"; // Default heading string when logged out
    }

    return ['channels' => $random_channels, 'heading' => $heading];
}

// Usage example: get channels
$channels_data = getChannels($conn);
$random_channels = $channels_data['channels'];
$heading = htmlspecialchars($channels_data['heading'], ENT_QUOTES, 'UTF-8');

// Display or use $random_channels and $heading as needed

$fuh420 = $_SESSION["user_id"];
?>





               <div id="guide">
                  <div id="guide-container" class=" vve-check" data-sessionlink="ei=yyOdUvWjKJOziAKBy4HABQ&amp;ved=CAEQ_h4">
                     <div id="guide-main" class="    guide-module     spf-nolink   yt-uix-tdl ">
                        <div class="guide-module-toggle">
                           <span class="guide-module-toggle-icon">
                           <span class="guide-module-toggle-arrow"></span>
                           <img src="images/pixel-vfl3z5WfW.gif" alt="">
                           <img src="images/pixel-vfl3z5WfW.gif" alt="" id="collapsed-notification-icon">
                           </span>
                           <div class="guide-module-toggle-label">
                              <h3>
                                 <span>
                                 Guide
                                 </span>
                              </h3>
                           </div>
                        </div>
						<?php if (!$fuh420) {
							include 'guides/signedout.php';
						}
						else {
							include 'guides/signedin.php';
						}
						?>
                     </div>
                     <div id="watch-context-container" class="guide-module collapsed hid"></div>
                  </div>
               </div>
