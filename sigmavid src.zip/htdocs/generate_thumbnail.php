<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $targetDir = __DIR__ . '/uploads/';
    $filename = $_POST['filename'];

    if (empty($filename)) {
        http_response_code(400);
        echo json_encode(["error" => "Filename is required."]);
        exit;
    }

    $targetFile = $targetDir . $filename;

    if (!file_exists($targetFile)) {
        http_response_code(404);
        echo json_encode(["error" => "File not found."]);
        exit;
    }

    // Get the duration of the video
    $durationCommand = "ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 " . escapeshellarg($targetFile);
    $duration = exec($durationCommand);

    if (!$duration) {
        http_response_code(500);
        echo json_encode(["error" => "Failed to get video duration."]);
        exit;
    }

    // Calculate the midpoint of the video
    $midpoint = $duration / 2;

    // Generate thumbnail at the midpoint
    $thumbnailFile = $targetDir . 'thumb_' . pathinfo($filename, PATHINFO_FILENAME) . '.jpg';
    $thumbnailCommand = "ffmpeg -i " . escapeshellarg($targetFile) . " -ss " . escapeshellarg($midpoint) . " -vframes 1 -an -y " . escapeshellarg($thumbnailFile);
    exec($thumbnailCommand);

    // Check if thumbnail was created
    if (file_exists($thumbnailFile)) {
        echo json_encode([
            "success" => true,
            "thumbnailPath" => 'uploads/' . 'thumb_' . pathinfo($filename, PATHINFO_FILENAME) . '.jpg'
        ]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Failed to generate thumbnail."]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed."]);
}
?>
