<?php
session_start(); // Start session for user authentication

include 'db.php'; // Include your database connection file

// Check if user is logged in
if (isset($_SESSION['user_id'])) {
    $subscriberId = $_SESSION['user_id'];

    // Check if user_id is provided via POST
    if (isset($_POST['user_id'])) {
        $userId = $_POST['user_id'];

        // Ensure user cannot subscribe to themselves
        if ($subscriberId == $userId) {
            echo "You cannot subscribe to your own channel.";
        } else {
            // Check if already subscribed
            $query = "SELECT * FROM subscriptions WHERE user_id = '$userId' AND subscriber_id = '$subscriberId'";
            $result = mysqli_query($conn, $query);

            if (mysqli_num_rows($result) > 0) {
                echo "You are already subscribed to this channel.";
            } else {
                // Perform subscription
                $query = "INSERT INTO subscriptions (user_id, subscriber_id) VALUES ('$userId', '$subscriberId')";
                if (mysqli_query($conn, $query)) {
                    echo "Subscription successful."; // Return success message
                } else {
                    echo "Error subscribing to the channel: " . mysqli_error($conn);
                }
            }
        }
    } else {
        echo "User ID not provided.";
    }
} else {
    echo "Please log in to subscribe to channels.";
}
?>
