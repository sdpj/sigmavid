<?php
include 'db.php'; // Your database connection file

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Function to check if the user is an admin
function isAdmin($conn, $user_id) {
    $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($role);
    $stmt->fetch();
    $stmt->close();
    return $role === 'admin';
}

// Function to get user ID from username
function getUserIdByUsername($conn, $username) {
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($user_id);
    $stmt->fetch();
    $stmt->close();
    return $user_id;
}

// Function to get IP address from username
function getIPByUsername($conn, $username) {
    $stmt = $conn->prepare("SELECT ip_address FROM users WHERE username = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($ip_address);
    $stmt->fetch();
    $stmt->close();
    return $ip_address;
}

// Function to ban a user
function banUser($conn, $username, $ip_address, $reason, $expires_at) {
    $stmt = $conn->prepare("INSERT INTO bans (username, ip_address, is_ip_ban, reason, expires_at) VALUES (?, ?, 1, ?, ?)");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("ssss", $username, $ip_address, $reason, $expires_at);
    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }
    return $stmt->affected_rows > 0;
}

// Function to ban an IP
function banIP($conn, $ip_address, $reason, $expires_at) {
    $stmt = $conn->prepare("INSERT INTO bans (username, ip_address, is_ip_ban, reason, expires_at) VALUES (NULL, ?, 1, ?, ?)");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("sss", $ip_address, $reason, $expires_at);
    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }
    return $stmt->affected_rows > 0;
}

// Function to fetch banned users and IPs
function fetchBans($conn) {
    $result = $conn->query("SELECT * FROM bans WHERE expires_at > NOW() OR expires_at IS NULL");
    if ($result === false) {
        die('Query failed: ' . $conn->error);
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to delete a video
function deleteVideo($conn, $video_id) {
    $stmt = $conn->prepare("DELETE FROM videos WHERE id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("i", $video_id);
    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }
    return $stmt->affected_rows > 0;
}

// Function to set a video as featured
function setVideoFeatured($conn, $video_id) {
    $stmt = $conn->prepare("UPDATE videos SET is_featured = TRUE WHERE id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("i", $video_id);
    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }
    return $stmt->affected_rows > 0;
}

// Function to remove a user and their associated data
function removeUser($conn, $username) {
    $user_id = getUserIdByUsername($conn, $username);
    if (!$user_id) {
        return false;
    }
    // Delete user videos
    $stmt = $conn->prepare("DELETE FROM videos WHERE user_id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    // Delete user comments
    $stmt = $conn->prepare("DELETE FROM comments WHERE user_id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    // Delete user messages
    $stmt = $conn->prepare("DELETE FROM messages WHERE user_id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    // Delete user
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }
    return $stmt->affected_rows > 0;
}

// Function to set a user role to admin
function setUserRoleToAdmin($conn, $username) {
    $user_id = getUserIdByUsername($conn, $username);
    if (!$user_id) {
        return false;
    }
    $stmt = $conn->prepare("UPDATE users SET role = 'admin' WHERE id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }
    return $stmt->affected_rows > 0;
}

// Function to get current maintenance mode status
function getMaintenanceMode($conn) {
    $result = $conn->query("SELECT maintenance_mode FROM settings LIMIT 1");
    if ($result === false) {
        die('Query failed: ' . $conn->error);
    }
    $row = $result->fetch_assoc();
    return isset($row['maintenance_mode']) ? (bool)$row['maintenance_mode'] : false;
}

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || !isAdmin($conn, $_SESSION['user_id'])) {
    die('Access denied.');
}

// Check if form is submitted for banning
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['ban_type'])) {
        $ban_type = $_POST['ban_type'];
        $reason = $_POST['reason'];
        $expires_at = isset($_POST['expires_at']) ? $_POST['expires_at'] : null;

        if (isset($_POST['infinite_ban']) && $_POST['infinite_ban'] === 'on') {
            $expires_at = null; // Use NULL for infinite ban
        }

        if ($ban_type === 'user') {
            $username = $_POST['username'];
            if (!empty($username)) {
                $user_id = getUserIdByUsername($conn, $username);
                $ip_address = getIPByUsername($conn, $username);
                if ($user_id) {
                    if (banUser($conn, $username, $ip_address, $reason, $expires_at)) {
                        if (removeUser($conn, $username)) {
                            echo "User '$username' banned and their information removed successfully.";
                        } else {
                            echo "User banned, but failed to remove their information.";
                        }
                    } else {
                        echo "Failed to ban user.";
                    }
                } else {
                    echo "User ID for the username not found.";
                }
            } else {
                echo "Username is required.";
            }
        } elseif ($ban_type === 'ip') {
            $ip_address = $_POST['ip_address'];
            if (banIP($conn, $ip_address, $reason, $expires_at)) {
                echo "IP address banned successfully.";
            } else {
                echo "Failed to ban IP address.";
            }
        }
    } elseif (isset($_POST['maintenance_mode'])) {
        $new_status = isset($_POST['maintenance_mode']) ? 1 : 0;

        // Update maintenance mode status in the database
        $update_query = "UPDATE settings SET maintenance_mode = $new_status";
        if ($conn->query($update_query) === false) {
            die('Query failed: ' . $conn->error);
        }

        header('Location: admin'); // Redirect to avoid form resubmission
        exit;
    } elseif (isset($_POST['video_action'])) {
        $video_id = $_POST['video_id'];
        $action = $_POST['video_action'];

        if ($action === 'delete') {
            if (deleteVideo($conn, $video_id)) {
                echo "Video with ID '$video_id' deleted successfully.";
            } else {
                echo "Failed to delete video.";
            }
        } elseif ($action === 'feature') {
            if (setVideoFeatured($conn, $video_id)) {
                echo "Video with ID '$video_id' set as featured.";
            } else {
                echo "Failed to set video as featured.";
            }
        }
    } elseif (isset($_POST['user_action'])) {
        $username = $_POST['username'];
        $action = $_POST['user_action'];

        if ($action === 'remove') {
            if (removeUser($conn, $username)) {
                echo "User '$username' and their videos removed successfully.";
            } else {
                echo "Failed to remove user.";
            }
        } elseif ($action === 'set_admin') {
            if (setUserRoleToAdmin($conn, $username)) {
                echo "User '$username' role set to admin.";
            } else {
                echo "Failed to set user role to admin.";
            }
        }
    }
}

// Fetch existing bans
$bans = fetchBans($conn);
$maintenance_mode = getMaintenanceMode($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
</head>
<body>
    <h1>Admin Panel</h1>

    <h2>Ban User or IP</h2>
	<a href="ban_user.php">UPDATE: Ban people here</a>

    <!-- <form method="post" action="admin">
        <label>
            <input type="checkbox" name="maintenance_mode" <?php if ($maintenance_mode) echo 'checked'; ?>> Enable Maintenance Mode
        </label>
        <button type="submit">Save</button>
    </form> -->
    <?php include 'toggle_maintenance.php'; ?>

    <h2>Manage Videos</h2>
    <form method="POST" action="admin">
        <label for="video_id">Video ID:</label>
        <input type="number" id="video_id" name="video_id" required><br><br>

        <label for="video_action">Action:</label>
        <select id="video_action" name="video_action" required>
            <option value="delete">Delete Video</option>
            <option value="feature">Feature Video</option>
        </select><br><br>

        <input type="submit" value="Perform Action">
    </form>

    <h2>Manage Users</h2>
    <form method="POST" action="admin">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>

        <label for="user_action">Action:</label>
        <select id="user_action" name="user_action" required>
            <option value="remove">Remove User</option>
            <option value="set_admin">Set as Admin</option>
        </select><br><br>

        <input type="submit" value="Perform Action">
    </form>

    <h2>Currently Banned Users and IPs</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>IP Address</th>
            <th>Reason</th>
            <th>Issued At</th>
            <th>Expires At</th>
        </tr>
        <?php foreach ($bans as $ban): ?>
            <tr>
                <td><?php echo htmlspecialchars($ban['id']); ?></td>
                <td><?php echo htmlspecialchars($ban['username']); ?></td>
                <td><?php echo htmlspecialchars($ban['ip_address']); ?></td>
                <td><?php echo htmlspecialchars($ban['reason']); ?></td>
                <td><?php echo htmlspecialchars($ban['issued_at']); ?></td>
                <td><?php echo htmlspecialchars($ban['expires_at']) ?: 'Never'; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <script>
        document.getElementById('ban_type').addEventListener('change', function() {
            var banType = this.value;
            if (banType === 'user') {
                document.getElementById('user_ban').style.display = 'block';
                document.getElementById('ip_ban').style.display = 'none';
            } else if (banType === 'ip') {
                document.getElementById('user_ban').style.display = 'none';
                document.getElementById('ip_ban').style.display = 'block';
            }
        });

        document.getElementById('infinite_ban').addEventListener('change', function() {
            var expiresAtField = document.getElementById('expires_at');
            if (this.checked) {
                expiresAtField.disabled = true;
                expiresAtField.value = ''; // Clear the date if infinite ban is checked
            } else {
                expiresAtField.disabled = false;
            }
        });
    </script>
</body>
</html>
