<?php
session_start(); // Start the session

include 'db.php';
include 'log_history.php';

// Function to get time ago string
function getTimeAgoString($video)
{
    if ($video['years_ago'] > 0) {
        return $video['years_ago'] . ' years ago';
    } elseif ($video['months_ago'] > 0) {
        return $video['months_ago'] . ' months ago';
    } elseif ($video['weeks_ago'] > 0) {
        return $video['weeks_ago'] . ' weeks ago';
    } elseif ($video['days_ago'] > 0) {
        return $video['days_ago'] . ' days ago';
    } elseif ($video['hours_ago'] > 0) {
        return $video['hours_ago'] . ' hours ago';
    } elseif ($video['minutes_ago'] > 0) {
        return $video['minutes_ago'] . ' minutes ago';
    } else {
        return $video['seconds_ago'] . ' seconds ago';
    }
}

// Fetch user details if logged in
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user = null;

function getSubscriberCount($userId, $conn) {
    $userId = mysqli_real_escape_string($conn, $userId);
    $query = "SELECT COUNT(*) AS subscriber_count FROM subscriptions WHERE user_id = '$userId'";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);
    return $data['subscriber_count'];
}

// Fetch subscriber count for the logged-in user if available
$subscriberCount = 0; // Default value

if ($user_id) {
    // Fetch user details from the database
    $stmt_user = $conn->prepare("SELECT id, username, profile_picture FROM users WHERE id = ?");
    $stmt_user->bind_param("i", $user_id);
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();
    $loggedInUserId = $_SESSION['user_id'];
    $subscriberCount = getSubscriberCount($loggedInUserId, $conn);
    
    if ($result_user->num_rows > 0) {
        $user = $result_user->fetch_assoc();
    }
    $stmt_user->close();
}

// Fetch featured videos with thumbnails, usernames, and upload time ago
$stmt_featured = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    WHERE v.is_featured = 1
    ORDER BY v.id DESC
    LIMIT 4
");
$stmt_featured->execute();
$result_featured = $stmt_featured->get_result();
$featured_videos = [];
while ($row = $result_featured->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $featured_videos[] = $row;
}
$stmt_featured->close();

// Fetch up to 6 most recent videos with thumbnails, usernames, and upload time ago, sorted by upload time
$stmt_recent = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    WHERE v.is_featured = 0
    ORDER BY v.uploaded_at DESC
    LIMIT 6
");
$stmt_recent->execute();
$result_recent = $stmt_recent->get_result();
$recent_videos = [];
while ($row = $result_recent->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $recent_videos[] = $row;
}
$stmt_recent->close();

function getRandomChannels($conn, $count = 3) {
    $stmt_random = $conn->prepare("
        SELECT id, username, profile_picture
        FROM users
        ORDER BY RAND()
        LIMIT $count
    ");
    $stmt_random->execute();
    $result_random = $stmt_random->get_result();
    $random_channels = [];
    while ($row = $result_random->fetch_assoc()) {
        $random_channels[] = $row;
    }
    $stmt_random->close();
    return $random_channels;
}

// Fetch up to 8 most popular videos with thumbnails, usernames, and upload time ago, sorted by views
$stmt_popular = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    ORDER BY v.views DESC
    LIMIT 8
");
$random_channels = getRandomChannels($conn, 3);
$stmt_popular->execute();
$result_popular = $stmt_popular->get_result();
$popular_videos = [];
while ($row = $result_popular->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $popular_videos[] = $row;
}
$stmt_popular->close();

// Function to fetch random videos with pagination
function getRandomVideos($conn, $offset = 0, $limit = 30) {
    $stmt_random = $conn->prepare("
        SELECT v.id, v.title, v.thumbnail, v.views, v.user_id, u.username
        FROM videos v
        LEFT JOIN users u ON v.user_id = u.id
        ORDER BY RAND()
        LIMIT ?, ?
    ");
    $stmt_random->bind_param("ii", $offset, $limit);
    $stmt_random->execute();
    $result_random = $stmt_random->get_result();
    $random_videos = [];
    while ($row = $result_random->fetch_assoc()) {
        $random_videos[] = $row;
    }
    $stmt_random->close();
    return $random_videos;
}


// Fetch random videos with an offset (for pagination)
$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
$limit = 30; // Number of videos to load per request
$random_videos = getRandomVideos($conn, $offset, $limit);


$conn->close();
?>
<?php
$page = 'Watch';
// Include database connection
include 'db.php';
include 'check_maintenance.php';
include 'check_ban.php';

// Function to get default profile picture or thumbnail if not set
function getDefaultImage($type) {
    switch ($type) {
        case 'profile':
            return 'default_profile_picture.jpg'; // Replace with your default profile picture filename
        case 'thumbnail':
            return 'default_thumbnail.jpg'; // Replace with your default video thumbnail filename
        default:
            return 'default_image.jpg'; // Replace with a default image filename
    }
}

// Fetch video ID from URL parameter
$video_id = isset($_GET['id']) ? $_GET['id'] : null;
if (!$video_id) {
    die('Video ID is missing');
}

// Get the user's IP address
$user_ip = $_SERVER['REMOTE_ADDR'];

// Rate limiting: Check if the user has viewed this video recently by IP address
$rate_limit_stmt = $conn->prepare("SELECT last_viewed_time FROM video_views WHERE ip_address = ? AND video_id = ?");
if (!$rate_limit_stmt) {
    die('Prepare failed: ' . $conn->error);
}
$rate_limit_stmt->bind_param("si", $user_ip, $video_id);
$rate_limit_stmt->execute();
$rate_limit_stmt->bind_result($last_viewed_time);
$rate_limit_stmt->fetch();
$rate_limit_stmt->close();

if ($last_viewed_time) {
    $current_time = new DateTime();
    $last_viewed_time = new DateTime($last_viewed_time);
    $interval = $current_time->diff($last_viewed_time);

    if ($interval->i < 5) {
        // Less than 5 minutes since the last view, do not update view count
        $rate_limit_exceeded = true;
    }
}

if (!isset($rate_limit_exceeded)) {
    // Directly update video views count
    $stmt_update_new = $conn->prepare("UPDATE videos SET views = views + 1, last_viewed_time = NOW() WHERE id = ?");
    if (!$stmt_update_new) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt_update_new->bind_param("i", $video_id);
    $stmt_update_new->execute();
    $stmt_update_new->close();

    // Update the video_views table
    $insert_view_stmt = $conn->prepare("INSERT INTO video_views (ip_address, video_id, last_viewed_time) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE last_viewed_time = NOW()");
    if (!$insert_view_stmt) {
        die('Prepare failed: ' . $conn->error);
    }
    $insert_view_stmt->bind_param("si", $user_ip, $video_id);
    $insert_view_stmt->execute();
    $insert_view_stmt->close();
}

// Fetch video details including uploaded_at
$stmt = $conn->prepare("SELECT id, user_id, title, description, filename, views, uploaded_at FROM videos WHERE id = ?");
if (!$stmt) {
    die('Prepare failed: ' . $conn->error);
}
$stmt->bind_param("i", $video_id);
$stmt->execute();
$stmt->bind_result($video_id, $user_id, $title, $description, $filename, $views, $uploaded_at);
$stmt->fetch();
$stmt->close();

// Fetch uploader details
$user_stmt = $conn->prepare("SELECT username, profile_picture FROM users WHERE id = ?");
if (!$user_stmt) {
    die('Prepare failed: ' . $conn->error);
}
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_stmt->bind_result($username, $profile_picture);
$user_stmt->fetch();
$supercoolvariable = $user_id; // Reintroduced supercoolvariable
$user_stmt->close();

// Count the number of videos the uploader has made
$video_count_stmt = $conn->prepare("SELECT COUNT(*) as video_count FROM videos WHERE user_id = ?");
if (!$video_count_stmt) {
    die('Prepare failed: ' . $conn->error);
}
$video_count_stmt->bind_param("i", $user_id);
$video_count_stmt->execute();
$video_count_stmt->bind_result($video_count);
$video_count_stmt->fetch();
$video_count_stmt->close();

// Format the uploaded_at date
$uploaded_at_obj = new DateTime($uploaded_at);
$formatted_uploaded_at = $uploaded_at_obj->format('M d, Y');
$uploaded_at_str = "Published on $formatted_uploaded_at";

// Fetch subscriber count
$sub_count_stmt = $conn->prepare("SELECT COUNT(*) as subscriber_count FROM subscriptions WHERE user_id = ?");
if (!$sub_count_stmt) {
    die('Prepare failed: ' . $conn->error);
}
$sub_count_stmt->bind_param("i", $user_id);
$sub_count_stmt->execute();
$sub_count_stmt->bind_result($subscriber_count);
$sub_count_stmt->fetch();
$sub_count_stmt->close();

// Determine profile picture or default
$profile_image = ($profile_picture) ? htmlspecialchars($profile_picture) : getDefaultImage('profile');

// Fetch like and dislike counts
$like_count_stmt = $conn->prepare("SELECT COUNT(*) as like_count FROM video_likes WHERE video_id = ? AND status = 'like'");
if (!$like_count_stmt) {
    die('Prepare failed: ' . $conn->error);
}
$like_count_stmt->bind_param("i", $video_id);
$like_count_stmt->execute();
$like_count_stmt->bind_result($like_count);
$like_count_stmt->fetch();
$like_count_stmt->close();

$dislike_count_stmt = $conn->prepare("SELECT COUNT(*) as dislike_count FROM video_likes WHERE video_id = ? AND status = 'dislike'");
if (!$dislike_count_stmt) {
    die('Prepare failed: ' . $conn->error);
}
$dislike_count_stmt->bind_param("i", $video_id);
$dislike_count_stmt->execute();
$dislike_count_stmt->bind_result($dislike_count);
$dislike_count_stmt->fetch();
$dislike_count_stmt->close();

// Check if user is logged in to show like/dislike buttons and status
$like_btn_text = 'Like';
$dislike_btn_text = 'Dislike';
$user_action = '';

if (isset($_SESSION['user_id'])) {
    // Check if user has liked or disliked this video
    $like_status_stmt = $conn->prepare("SELECT status FROM video_likes WHERE video_id = ? AND user_id = ?");
    if (!$like_status_stmt) {
        die('Prepare failed: ' . $conn->error);
    }
    $like_status_stmt->bind_param("ii", $video_id, $_SESSION['user_id']);
    $like_status_stmt->execute();
    $like_status_stmt->store_result();

    if ($like_status_stmt->num_rows > 0) {
        $like_status_stmt->bind_result($status);
        $like_status_stmt->fetch();

        if ($status === 'like') {
            $like_btn_text = 'Liked';
            $dislike_btn_text = 'Dislike';
            $user_action = 'liked';
        } elseif ($status === 'dislike') {
            $like_btn_text = 'Like';
            $dislike_btn_text = 'Disliked';
            $user_action = 'disliked';
        }
    }
    $like_status_stmt->close();
}

// Fetch comments along with like/dislike counts and status
$comments_stmt = $conn->prepare("
    SELECT c.id, c.user_id, u.username, u.profile_picture, c.comment_text, c.comment_date, 
           COALESCE(like_counts.like_count, 0) AS like_count,
           COALESCE(dislike_counts.dislike_count, 0) AS dislike_count,
           IF(cl.status = 'like', 'liked', IF(cl.status = 'dislike', 'disliked', 'none')) AS user_status
    FROM comments c
    JOIN users u ON c.user_id = u.id
    LEFT JOIN (
        SELECT comment_id, COUNT(*) AS like_count
        FROM comment_likes
        WHERE status = 'like'
        GROUP BY comment_id
    ) AS like_counts ON c.id = like_counts.comment_id
    LEFT JOIN (
        SELECT comment_id, COUNT(*) AS dislike_count
        FROM comment_likes
        WHERE status = 'dislike'
        GROUP BY comment_id
    ) AS dislike_counts ON c.id = dislike_counts.comment_id
    LEFT JOIN comment_likes cl ON c.id = cl.comment_id AND cl.user_id = ?
    WHERE c.video_id = ?
    ORDER BY c.comment_date DESC
");

$user_id_param = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
$comments_stmt->bind_param("ii", $user_id_param, $video_id);
$comments_stmt->execute();
$comments_result = $comments_stmt->get_result();
$comments = $comments_result->fetch_all(MYSQLI_ASSOC);
$comments_stmt->close();

// Close database connection
$conn->close();
?>





<html lang="en" data-cast-api-enabled="true"><head><meta name="twitter:card" content="player">
<meta property="og:video:type" content="video/mp4">
    <link id="css-2838365198" class="www-core" rel="stylesheet" href="css/main.css" data-loaded="true">



<title><?php echo htmlspecialchars($title); ?> - SigmaVid</title><link rel="search" type="application/opensearchdescription+xml" href="https://www.youtube.com/opensearch?locale=en_US" title="BetaCast Video Search"><link rel="shortcut icon" href="favicon-vfldLzJxy.ico" type="image/x-icon">     <link rel="icon" href="images/favicon_32-vflWoMFGx.png" sizes="32x32"><link rel="alternate" media="handheld" href="https://m.youtube.com/index?&amp;desktop_uri=%2F"><link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.youtube.com/index?&amp;desktop_uri=%2F"><meta name="description" content="Share your videos with friends, family, and the world"><meta name="keywords" content="video, sharing, camera phone, video phone, free, upload">  <meta property="og:image" content="images/youtube_logo_stacked-vfl225ZTx.png">
  <meta property="fb:app_id" content="87741124305">
  <link rel="publisher" href="https://plus.google.com/115229808208707341778">
  
  <style>
      .yt-uix-subscription-button {
    /* Add your button styles */
    cursor: pointer !important;  /* Ensure cursor changes to pointer on hover */
}

.yt-uix-button-subscribed-branded .subscribe-label,
.yt-uix-button-subscribe-branded .subscribed-label,
.yt-uix-button-subscribe-branded .unsubscribe-label {
    display: none !important; /* Hide all labels by default */
}

.yt-uix-button-subscribe-branded:hover .unsubscribe-label {
    display: inline !important; /* Show unsubscribe label on hover */
}

.yt-uix-button-subscribe-branded:hover .subscribed-label {
    display: none!important; /* Hide subscribed label on hover */
}

  </style>
<script>if (window.ytcsi) {window.ytcsi.tick("cl", null, '');}</script></head><!-- machid: palZfX2ZGYUViS0hwbGFMVlBQendwdzI3bU9YYzVsVk1ZQkNyVGpZS1VZUWEtME9uZkR2WFZn -->
    <body dir="ltr" class="  ltr        site-left-aligned  hitchhiker-enabled    guide-enabled  guide-expanded  " id="body">

<div id="body-container"><form name="logoutForm" method="POST" action="/logout"><input type="hidden" name="action_logout" value="1"></form>    
    
<?php include 'header.php' ?>
    
  <div id="alerts">
      

  </div>
  

<div id="page-container"><div id="page" class="  watch  clearfix">
    
<?php include 'guide.php' ?>    
<!-- start channel: UCd9iwO1kWCIgMblqlAOI8 -->
<div id="player" class="" bis_skin_checked="1">
 <iframe height="390" width="640" src="player/embed.php?video=<?php echo $filename; ?>&width=640&height=390" allowfullscreen="" bis_size="{" x":256,"y":366,"w":450,"h":200,"abs_x":256,"abs_y":366}"="" bis_id="fr_zzp1twq7tei6tdm3d1vb8w" bis_depth="0" bis_chainid="1"></iframe>
  <div id="playlist" class="playlist" bis_skin_checked="1">
    
  </div>

  <div id="player-unavailable" class="    hid    player-unavailable " bis_skin_checked="1">
    
  </div>

    

    <script>if (window.ytcsi) {window.ytcsi.tick("bf", null, '');}</script>        


  <div id="playlist-tray" class="playlist-tray" bis_skin_checked="1">
    
  </div>

  

  <div id="player-branded-banner" class="player-branded-banner" bis_skin_checked="1">
    
  </div>
</div>
<div id="content" bis_skin_checked="1">  <div id="watch7-container" class="" itemscope="" itemid="" itemtype="http://schema.org/VideoObject" bis_skin_checked="1">

    <div id="watch7-main-container" bis_skin_checked="1">
      <div id="watch7-main" class="clearfix" bis_skin_checked="1">
        <div id="watch7-content" class="watch-content" bis_skin_checked="1">
              <div class="yt-uix-button-panel" bis_skin_checked="1">
        <div id="watch7-headline" class="clearfix  yt-uix-expander yt-uix-expander-collapsed" bis_skin_checked="1">
      

  

<h1 id="watch-headline-title" class="yt">
  <span id="eow-title" class="watch-title  yt-uix-expander-head" dir="ltr" title="Rant: If you eat burgers without cheese you are a CREATURE">
    <?php echo htmlspecialchars($title); ?>  </span>

    </h1>
  </div>

      <div id="watch7-user-header" bis_skin_checked="1"><a href="/channel/UCd9iwO1kWCIgMblqlAOI8?feature=watch" class="yt-user-photo ">    <span class="video-thumb  yt-thumb yt-thumb-48 g-hovercard" data-ytid="UCY30JRSgfhYXA6i6xX1erWg">
      <span class="yt-thumb-square">
        <span class="yt-thumb-clip">
          <span class="yt-thumb-clip-inner">
            <img alt="TestieTorsionGaming" src="<?php echo htmlspecialchars($profile_picture); ?>" width="48">
            <span class="vertical-align"></span>
          </span>
        </span>
      </span>
    </span>
    <?php
    include 'db.php';
    // Prepare and bind
$stmt_sigmaaaa = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt_sigmaaaa->bind_param("i", $supercoolvariable);

// Execute the query
$stmt_sigmaaaa->execute();

// Bind the result to a variable
$stmt_sigmaaaa->bind_result($sigmausername);
$stmt_sigmaaaa->fetch();


// Close the statement and connection
$stmt_sigmaaaa->close();
$conn->close();
?>
</a><a href="/channel?user_id=<?php echo $supercoolvariable; ?>" class="g-hovercard yt-uix-sessionlink yt-user-name " data-sessionlink="ei=I3oUUvO0DM-0iAKV34H4BQ&amp;feature=watch" dir="ltr" data-ytid="UCY30JRSgfhYXA6i6xX1erWg" data-name="watch"><?php echo htmlspecialchars($sigmausername); ?></a><span class="yt-user-separator">·</span><a class="yt-uix-sessionlink yt-user-videos" href="/channel?user_id=<?php echo $supercoolvariable; ?>/videos" data-sessionlink="ei=I3oUUvO0DM-0iAKV34H4BQ&amp;feature=watch"><?php echo $video_count; ?> videos</a><br><span id="watch7-subscription-container"><!-- Subscription Button -->
	<span class="">
	    <button type="button" class="yt-uix-subscription-button yt-uix-button yt-uix-button-subscribe-branded yt-uix-button-size-default" aria-role="button" data-channel-external-id="UCd9iwO1kWCIgMblqlAOI8" onclick="handleSubscription('<?php echo $supercoolvariable; ?>', '539502', false)">
		<span class="yt-uix-button-icon-wrapper">
		    <img class="yt-uix-button-icon yt-uix-button-icon-subscribe" src="images/pixel-vfl3z5WfW.gif" alt="">
		</span>
		<span class="yt-uix-button-content">
		    <span class="subscribe-label" aria-label="Subscribe">Subscribe</span>
		    <span class="subscribed-label" aria-label="Unsubscribe">Subscribed</span>
		    <span class="unsubscribe-label" aria-label="Unsubscribe"></span>
		</span>
	    </button>
	    <span class="yt-subscription-button-subscriber-count-branded-horizontal subscribed"><?php echo $subscriber_count; ?></span>  
	</span>
  <div class="yt-uix-overlay " data-overlay-style="primary" data-overlay-shape="tiny" bis_skin_checked="1">
    
        <div class="yt-dialog hid" bis_skin_checked="1">
    <div class="yt-dialog-base" bis_skin_checked="1">
      <span class="yt-dialog-align"></span>
      <div class="yt-dialog-fg" bis_skin_checked="1">
        <div class="yt-dialog-fg-content" bis_skin_checked="1">
            <div class="yt-dialog-header" bis_skin_checked="1">
              <h2 class="yt-dialog-title">
                      Subscription preferences


              </h2>
            </div>
          <div class="yt-dialog-loading" bis_skin_checked="1">
              <div class="yt-dialog-waiting-content" bis_skin_checked="1">
    <div class="yt-spinner-img" bis_skin_checked="1"></div><div class="yt-dialog-waiting-text" bis_skin_checked="1">Loading...</div>
  </div>

          </div>
          <div class="yt-dialog-content" bis_skin_checked="1">
              <div class="subscription-preferences-overlay-content-container" bis_skin_checked="1">
    <div class="subscription-preferences-overlay-loading " bis_skin_checked="1">
        <p class="yt-spinner">
      <img src="images/pixel-vfl3z5WfW_2.gif" class="yt-spinner-img" alt="Loading icon">

    <span class="yt-spinner-message">
Loading...
    </span>
  </p>

    </div>
    <div class="subscription-preferences-overlay-content" bis_skin_checked="1">
    </div>
  </div>

          </div>
          <div class="yt-dialog-working" bis_skin_checked="1">
              <div id="yt-dialog-working-overlay" bis_skin_checked="1">
  </div>
  <div id="yt-dialog-working-bubble" bis_skin_checked="1">
    <div class="yt-dialog-waiting-content" bis_skin_checked="1">
      <div class="yt-spinner-img" bis_skin_checked="1"></div><div class="yt-dialog-waiting-text" bis_skin_checked="1">Working...</div>
    </div>
  </div>

          </div>
        </div>
      </div>
    </div>
  </div>


  </div>

</span><div id="watch7-views-info" bis_skin_checked="1">      <span class="watch-view-count ">
    <?php echo $views; ?> views </span>

    <div class="video-extras-sparkbars" bis_skin_checked="1">
    <div class="video-extras-sparkbar-likes" style="width: 100%" bis_skin_checked="1"></div>
    <!--<div class="video-extras-sparkbar-dislikes" style="width: 2.96495278069%" bis_skin_checked="1"></div>-->
  </div>
  <span class="video-extras-likes-dislikes">
      <img  class="icon-watch-stats-like" src="images/pixel-vfl3z5WfW.gif" alt="Like">
  <span class="likes-count"><?php echo $like_count; ?></span>
 &nbsp;&nbsp;&nbsp;   <img class="icon-watch-stats-dislike" src="images/pixel-vfl3z5WfW.gif" alt="Dislike">
  <span class="dislikes-count"><?php echo $dislike_count; ?></span>

  </span>

</div></div>
        <div id="watch7-action-buttons" class="clearfix" bis_skin_checked="1">
            <form action="like_dislike.php" method="post">
                            <input type="hidden" name="video_id" value="<?php echo $video_id; ?>">
            <?php if ($user_action === 'liked'): ?>

                <div id="watch7-sentiment-actions" bis_skin_checked="1">
      <span id="watch-like-dislike-buttons" class="yt-uix-button-group " data-button-toggle-group="optional"><span class="yt-uix-clickcard">       
      <button type="submit" name="action" value="unlike" title="" type="button" class="yt-uix-clickcard-target yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip" data-orientation="vertical" data-button-toggle="true" data-force-position="true" data-unlike-tooltip="Unlike" data-position="bottomright" data-like-tooltip="I like this" role="button">
      
      <span class="yt-uix-button-icon-wrapper">
      <img class="yt-uix-button-icon yt-uix-button-icon-watch-like" src="images/pixel-vfl3z5WfW.gif" alt="" title="">
      <span class="yt-uix-button-valign"></span>
    </span>
    <span id="likeButton" class="yt-uix-button-content">
Liked 
    </span>
</button>  
  </span><span class="yt-uix-clickcard"><button type="submit" name="action" value="dislike" title="I dislike this" id="watch-dislike" type="button" class="yt-uix-clickcard-target yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip yt-uix-button-empty" data-position="bottomright" data-orientation="vertical" data-button-toggle="true" data-force-position="true" role="button">    <span class="yt-uix-button-icon-wrapper">
      <img class="yt-uix-button-icon yt-uix-button-icon-watch-dislike" src="images/pixel-vfl3z5WfW.gif" alt="I dislike this" title="">
      <span class="yt-uix-button-valign"></span>
    </span>
</button></form> 
</span></span>
    </div>
            <?php elseif ($user_action === 'disliked'): ?>
            <div id="watch7-sentiment-actions" bis_skin_checked="1">
      <span id="watch-like-dislike-buttons" class="yt-uix-button-group " data-button-toggle-group="optional"><span class="yt-uix-clickcard">       
      <button type="submit" name="action" value="like" title="" type="button" class="yt-uix-clickcard-target yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip" data-orientation="vertical" data-button-toggle="true" data-force-position="true" data-unlike-tooltip="Unlike" data-position="bottomright" data-like-tooltip="I like this" role="button">
      
      <span class="yt-uix-button-icon-wrapper">
      <img class="yt-uix-button-icon yt-uix-button-icon-watch-like" src="images/pixel-vfl3z5WfW.gif" alt="" title="">
      <span class="yt-uix-button-valign"></span>
    </span>
    <span id="likeButton" class="yt-uix-button-content">
Like 
    </span>
</button>  
  </span><span class="yt-uix-clickcard"><button type="submit" name="action" value="undislike" title="I dislike this" id="watch-dislike" type="button" class="yt-uix-clickcard-target yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip yt-uix-button-empty" data-position="bottomright" data-orientation="vertical" data-button-toggle="true" data-force-position="true" role="button">    <span class="yt-uix-button-icon-wrapper">
      <img class="yt-uix-button-icon yt-uix-button-icon-watch-dislike" src="images/pixel-vfl3z5WfW.gif" alt="I dislike this" title="">
      <span class="yt-uix-button-valign"></span>
    </span>
</button></form> 
</span></span>
    </div>
            <?php else: ?>
            <div id="watch7-sentiment-actions" bis_skin_checked="1">
      <span id="watch-like-dislike-buttons" class="yt-uix-button-group " data-button-toggle-group="optional"><span class="yt-uix-clickcard">       
      <button type="submit" name="action" value="like" title="" type="button" class="yt-uix-clickcard-target yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip" data-orientation="vertical" data-button-toggle="true" data-force-position="true" data-unlike-tooltip="Unlike" data-position="bottomright" data-like-tooltip="I like this" role="button">
      
      <span class="yt-uix-button-icon-wrapper">
      <img class="yt-uix-button-icon yt-uix-button-icon-watch-like" src="images/pixel-vfl3z5WfW.gif" alt="" title="">
      <span class="yt-uix-button-valign"></span>
    </span>
    <span id="likeButton" class="yt-uix-button-content">
Like 
    </span>
</button>  
  </span><span class="yt-uix-clickcard"><button type="submit" name="action" value="dislike" title="I dislike this" id="watch-dislike" type="button" class="yt-uix-clickcard-target yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip yt-uix-button-empty" data-position="bottomright" data-orientation="vertical" data-button-toggle="true" data-force-position="true" role="button">    <span class="yt-uix-button-icon-wrapper">
      <img class="yt-uix-button-icon yt-uix-button-icon-watch-dislike" src="images/pixel-vfl3z5WfW.gif" alt="I dislike this" title="">
      <span class="yt-uix-button-valign"></span>
    </span>
</button></form> 
</span></span>
    </div>
            <?php endif; ?>
    <div id="watch7-secondary-actions" class="yt-uix-button-group" data-button-toggle-group="required" bis_skin_checked="1">
        <span>
    <button onclick=";return false;" title="" type="button" class="action-panel-trigger yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip yt-uix-button-toggled" data-button-toggle="true" data-trigger-for="action-panel-details" role="button">    <span class="yt-uix-button-content">
About 
    </span>
</button>
  </span>

          <span>
    <button onclick=";return false;" title="" type="button" class="action-panel-trigger yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip" data-button-toggle="true" data-trigger-for="action-panel-share" role="button">    <span class="yt-uix-button-content">
Share 
    </span>
</button>
  </span>

          <span class="yt-uix-clickcard">
    <button onclick=";return false;" title="" type="button" class="action-panel-trigger yt-uix-clickcard-target yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip" data-position="bottomleft" data-upsell="playlist" data-orientation="vertical" data-button-toggle="true" data-trigger-for="action-panel-none" role="button">    <span class="yt-uix-button-content">
Add to 
    </span>
</button>
        <div class="watch7-hovercard yt-uix-clickcard-content" bis_skin_checked="1">
    <h3 class="watch7-hovercard-header">Sign in to BetaCast</h3>
    <div class="watch7-hovercard-message" bis_skin_checked="1">
      Sign in with your BetaCast Account (BetaCast E-Mail) to add <span class="yt-user-name  g-hovercard" dir="ltr" data-ytid="UCY30JRSgfhYXA6i6xX1erWg">TestieTorsionGaming</span>'s video to your playlist.

    </div>
    <ul class="watch7-hovercard-icon-strip clearfix">
      <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-youtube-icon" bis_skin_checked="1"></div>
      </li>
      <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-gplus-icon" bis_skin_checked="1"></div>
      </li>
      <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-gmail-icon" bis_skin_checked="1"></div>
      </li>
      <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-picasa-icon" bis_skin_checked="1"></div>
      </li>
      <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-chrome-icon" bis_skin_checked="1"></div>
      </li>
    </ul>
    <div class="watch7-hovercard-account-line" bis_skin_checked="1">
      <a href="https://web.archive.org/web/20130821082818/https://accounts.google.com/ServiceLogin?service=youtube&amp;uilel=3&amp;hl=en_US&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26feature%3D__FEATURE__%26hl%3Den_US%26next%3D%252Fwatch%253Fv%253DuxxPlbT8RaA%26nomobiletemp%3D1&amp;passive=true" class="yt-uix-button yt-uix-sessionlink yt-uix-button-primary yt-uix-button-size-default" data-sessionlink="ei=I3oUUvO0DM-0iAKV34H4BQ"><span class="yt-uix-button-content">Sign in</span></a>
    </div>
  </div>

  </span>

          <span>
    <button onclick=";return false;" title="Transcript" type="button" class="action-panel-trigger yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip yt-uix-button-empty" data-button-toggle="true" data-trigger-for="action-panel-transcript" role="button">    <span class="yt-uix-button-icon-wrapper">
      <img class="yt-uix-button-icon yt-uix-button-icon-action-panel-transcript" src="images/pixel-vfl3z5WfW_2.gif" alt="Transcript" title="">
      <span class="yt-uix-button-valign"></span>
    </span>
</button>
  </span>

          <span>
    <button onclick=";return false;" title="Statistics" type="button" class="action-panel-trigger yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip yt-uix-button-empty" data-button-toggle="true" data-trigger-for="action-panel-stats" role="button">    <span class="yt-uix-button-icon-wrapper">
      <img class="yt-uix-button-icon yt-uix-button-icon-action-panel-stats" src="images/pixel-vfl3z5WfW_2.gif" alt="Statistics" title="">
      <span class="yt-uix-button-valign"></span>
    </span>
</button>
  </span>


        <span>
    <button onclick=";return false;" title="Report" type="button" class="action-panel-trigger yt-uix-button yt-uix-button-text yt-uix-button-size-default yt-uix-tooltip yt-uix-button-empty" data-button-toggle="true" data-trigger-for="action-panel-report" role="button">    <span class="yt-uix-button-icon-wrapper">
      <img class="yt-uix-button-icon yt-uix-button-icon-action-panel-report" src="images/pixel-vfl3z5WfW_2.gif" alt="Report" title="">
      <span class="yt-uix-button-valign"></span>
    </span>
</button>
  </span>

    </div>
  </div>

        <div id="watch7-action-panels" class="yt-uix-button-panel" bis_skin_checked="1" style="">
      <div id="action-panel-details" class="action-panel-content" bis_skin_checked="1" data-panel-loaded="true" style="">
    <div id="watch-description" class="yt-uix-expander yt-uix-button-panel yt-uix-expander-collapsed" bis_skin_checked="1">
      <div id="watch-description-content" bis_skin_checked="1">
        <div id="watch-description-clip" bis_skin_checked="1">
          <p id="watch-uploader-info">
            <strong><?php echo $uploaded_at_str; ?></span>
</strong>
          </p>
          <div id="watch-description-text" bis_skin_checked="1">
                      <p id="eow-description"><?php echo htmlspecialchars($description); ?></p>
          </div>
            <div id="watch-description-extras" bis_skin_checked="1">
    <ul class="watch-extras-section">
                  <li>
        <h4 class="title">
Category
        </h4>
        <div class="content" bis_skin_checked="1">
              <p id="eow-category"><a href="/entertainment">Entertainment</a></p>

        </div>
      </li>


        <li>
          <h4 class="title">License</h4>
          <div class="content" bis_skin_checked="1">
              <p id="eow-reuse">
Standard BetaCast License
  </p>

          </div></li>
        
    </ul>
  </div>

        </div>
        <ul id="watch-description-extra-info">
          
        </ul>
      </div>

      <div id="watch-description-toggle" class="yt-uix-expander-head yt-uix-button-panel" bis_skin_checked="1">
        <div id="watch-description-expand" class="expand" bis_skin_checked="1">
          <!--button onclick=";return false;" type="button" class="metadata-inline yt-uix-button yt-uix-button-text yt-uix-button-size-default" role="button">    <span class="yt-uix-button-content">
Show more -->
    </span>
</button>
        </div>
        <div id="watch-description-collapse" class="collapse" bis_skin_checked="1">
          <button onclick=";return false;" type="button" class="metadata-inline yt-uix-button yt-uix-button-text yt-uix-button-size-default" role="button">    <span class="yt-uix-button-content">
Show less 
    </span>
</button>
        </div>
      </div>
    </div>
  </div>

      <div id="action-panel-share" class="action-panel-content hid" bis_skin_checked="1" data-panel-loaded="true" style="display: none;">
      <div id="watch-actions-share-loading" bis_skin_checked="1">
    <div class="action-panel-loading" bis_skin_checked="1">
        <p class="yt-spinner">
      <img src="images/pixel-vfl3z5WfW_2.gif" class="yt-spinner-img" alt="Loading icon">

    <span class="yt-spinner-message">
Loading...
    </span>
  </p>

    </div>
  </div>
  <div id="watch-actions-share-panel" bis_skin_checked="1"></div>

  </div>

      <div id="action-panel-addto" class="action-panel-content hid" data-auth-required="true" bis_skin_checked="1">
    <div class="action-panel-loading" bis_skin_checked="1">
        <p class="yt-spinner">
      <img src="images/pixel-vfl3z5WfW_2.gif" class="yt-spinner-img" alt="Loading icon">

    <span class="yt-spinner-message">
Loading...
    </span>
  </p>

    </div>
  </div>

        <div id="action-panel-transcript" class="action-panel-content hid" bis_skin_checked="1">
    <div id="watch-actions-transcript-loading" bis_skin_checked="1">
      <div class="action-panel-loading" bis_skin_checked="1">
          <p class="yt-spinner">
      <img src="images/pixel-vfl3z5WfW_2.gif" class="yt-spinner-img" alt="Loading icon">

    <span class="yt-spinner-message">
Loading...
    </span>
  </p>

      </div>
    </div>
      <div id="watch-actions-transcript" class="watch-actions-panel hid" bis_skin_checked="1">
      <div id="caption-line-template" class="hid" bis_skin_checked="1">
    <!--
    <div class="caption-line-time">
      <div class="caption-line-start">__start__</div>
    </div>
    <div class="editable-line-text">
      <span class="editable-line-text-original">__original__</span>
      <label class="editable-line-text-current hid">__current__</label>
      <textarea class="editable-line-text-input hid">__input__</textarea>
    </div>
    -->
  </div>



    <div id="watch-transcript-container" bis_skin_checked="1">
      <div id="watch-transcript-not-found" class="hid" bis_skin_checked="1">
The interactive transcript could not be loaded.
      </div>

      
    </div>
  </div>

  </div>

      <div id="action-panel-stats" class="action-panel-content hid" bis_skin_checked="1">
    <div class="action-panel-loading" bis_skin_checked="1">
        <p class="yt-spinner">
      <img src="images/pixel-vfl3z5WfW_2.gif" class="yt-spinner-img" alt="Loading icon">

    <span class="yt-spinner-message">
Loading...
    </span>
  </p>

    </div>
  </div>

      <div id="action-panel-report" class="action-panel-content hid" data-auth-required="true" bis_skin_checked="1">
    <div class="action-panel-loading" bis_skin_checked="1">
        <p class="yt-spinner">
      <img src="images/pixel-vfl3z5WfW_2.gif" class="yt-spinner-img" alt="Loading icon">

    <span class="yt-spinner-message">
Loading...
    </span>
  </p>

    </div>
  </div>

      <div id="action-panel-login" class="action-panel-content hid" bis_skin_checked="1">
    <div class="action-panel-login" bis_skin_checked="1">
      <a href="https://web.archive.org/web/20130821082818/https://accounts.google.com/ServiceLogin?service=youtube&amp;uilel=3&amp;hl=en_US&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26feature%3D__FEATURE__%26hl%3Den_US%26next%3D%252Fwatch%253Fv%253DuxxPlbT8RaA%26nomobiletemp%3D1&amp;passive=true" class="yt-uix-button   yt-uix-sessionlink yt-uix-button-default yt-uix-button-size-default" data-sessionlink="ei=I3oUUvO0DM-0iAKV34H4BQ"><span class="yt-uix-button-content">Sign in</span></a>
    </div>
  </div>

  <div id="action-panel-ratings-disabled" class="action-panel-content hid" bis_skin_checked="1">
      <div id="watch-actions-ratings-disabled" class="watch-actions-panel" bis_skin_checked="1">
    <em>Ratings have been disabled for this video.</em>
  </div>

  </div>

  <div id="action-panel-rental-required" class="action-panel-content hid" bis_skin_checked="1">
      <div id="watch-actions-rental-required" class="watch-actions-panel" bis_skin_checked="1">
    <strong>Rating is available when the video has been rented.</strong>
  </div>

  </div>

  <div id="action-panel-error" class="action-panel-content hid" bis_skin_checked="1">
    <div class="action-panel-error" bis_skin_checked="1">
      This feature is not available right now. Please try again later.
    </div>
  </div>

    <div id="watch7-action-panel-footer" bis_skin_checked="1">
        <hr class="yt-horizontal-rule ">

    </div>
  </div>

  </div>
          <div class="cmt_iframe_holder" data-href="http://www.youtube.com/watch?v=uxxPlbT8RaA" data-viewtype="FILTERED_POSTMOD" style="display: none;" bis_skin_checked="1"></div>








<div id="watch-discussion" bis_skin_checked="1">
<div id="comments-view" data-type="highlights" class="" bis_skin_checked="1">
<h4>
<strong>Comments</strong>
</h4>
<?php $error = ""; ?>
<?php $error = htmlspecialchars($_GET['error']); ?>
<?php if(isset($error)): ?>
<p style="color:red;"><?php echo $error; ?></p><br>
<?php endif; ?>
            <?php if (isset($_SESSION['user_id'])): ?>
            
            <a class="yt-user-photo"> <span class="video-thumb  yt-thumb yt-thumb-48">
<span class="yt-thumb-square">
<span class="yt-thumb-clip">
<span class="yt-thumb-clip-inner">
<img src="<?php echo htmlspecialchars($user_header['profile_picture']); ?>" width="48">
<span class="vertical-align"></span>
</span>
</span>
</span>
</span>
</a>

                <form id="commentform" action="post_comment.php" method="post">
                    <div id="masthead-search-terms" style="width:543px;margin-left:auto;height:48px;"class="masthead-search-terms-border" dir="ltr">
                        <label>
                            <input type="hidden" name="video_id" value="<?php echo $video_id; ?>">
                            <input style="height:100%;" name="comment_text" type="text" id="commentbox" autocomplete="off" autofocus="" class="search-term yt-uix-form-input-bidi" placeholder="Write a comment!" name="search_query" value="" type="text" tabindex="1" title="Search">
                        </label>
                        <script>var searchBox = document.getElementById('masthead-search-term');if (searchBox) {searchBox.focus();}</script>
                    </div>
                </form><br>
        <?php else: ?>
        <div class="comments-post-alert comments-post" bis_skin_checked="1">
        <a href="/login">Sign in</a> now to post a comment!
        </div>
        <?php endif; ?>


<div bis_skin_checked="1">

<?php if (count($comments) > 0): ?>
<ul id="all-comments">
                    <?php foreach ($comments as $comment): ?>
<li class="comment" style="width: 100%;" data-author-id="OuRz-I6kmcxWKEXCVQMxQw" data-id="yg8Twl6Bh94fhIf8B-kMnW0NRkVyS39pwzPObDRQZPw">
<button type="button" class="flip close yt-uix-button yt-uix-button-link yt-uix-button-empty" onclick=";return false;" data-button-has-sibling-menu="true" role="button" aria-pressed="false" aria-expanded="false" aria-haspopup="true" aria-activedescendant=""><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-comment-close" src="images/pixel-vfl3z5WfW.gif" alt="" title=""><span class="yt-uix-button-valign"></span></span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW_1.gif" alt="" title=""><div class=" yt-uix-button-menu yt-uix-button-menu-link" style="display: none;" bis_skin_checked="1"><ul><li class="comment-action-remove comment-action" data-action="remove"><span class="yt-uix-button-menu-item">Remove</span></li><li class="comment-action" data-action="flag-profile-pic"><span class="yt-uix-button-menu-item">Report profile image</span></li><li class="comment-action" data-action="flag"><span class="yt-uix-button-menu-item">Flag for spam</span></li><li class="comment-action-block comment-action" data-action="block"><span class="yt-uix-button-menu-item">Block User</span></li><li class="comment-action-unblock comment-action" data-action="unblock"><span class="yt-uix-button-menu-item">Unblock User</span></li></ul></div></button>
<a href="/channel.php?user_id=<?php echo htmlspecialchars($comment['user_id']); ?>" class="yt-user-photo "> <span class="video-thumb  yt-thumb yt-thumb-48">
<span class="yt-thumb-square">
<span class="yt-thumb-clip">
<span class="yt-thumb-clip-inner">
<img src="<?php echo htmlspecialchars($comment['profile_picture']); ?>" width="48">
<span class="vertical-align"></span>
</span>
</span>
</span>
</span>
</a>
<div class="content" style="width: 47%" bis_skin_checked="1">
<p class="metadata">
<span class="author ">
<a href="/channel.php?user_id=<?php echo htmlspecialchars($comment['user_id']); ?>" dir="ltr"><?php echo htmlspecialchars($comment['username']); ?></a></span>
<span class="time" dir="ltr">
<!-- <a dir="ltr">
52 minutes ago</a> -->
</span>
</p>
<div class="comment-text" style="width: 187%;" dir="ltr" bis_skin_checked="1">
<p><?php echo nl2br(htmlspecialchars($comment['comment_text'])); ?></p>
</div>

        <div class="comment-actions" bis_skin_checked="1">
        <button type="button" class="start comment-action yt-uix-button yt-uix-button-link" onclick="reply(3678);" data-action="reply" role="button"><span class="yt-uix-button-content">Reply </span></button>
        <span class="separator">·</span>
        <?php 
            $liketodislike = $comment['like_count'] - $comment['dislike_count']; 
            
            if ($liketodislike > -1) {
                $color = 'green';
            }
            else {
                $color = 'red';
            }
        ?>
        <span style="color: <?php echo $color; ?>"><?php echo $liketodislike; ?></span>
        <span class="yt-uix-clickcard">
        <a href="/like_dislike_comment.php?action=like&comment_id=<?php echo $comment['id']; ?>&video_id=<?php echo $video_id; ?>">
        </a><button type="button" class="start comment-action-vote-up comment-action yt-uix-clickcard-target yt-uix-button yt-uix-button-link yt-uix-tooltip yt-uix-button-empty" title="" data-action="" data-tooltip-show-delay="300" role="button"><a href="/like_dislike_comment.php?action=like&comment_id=<?php echo $comment['id']; ?>&video_id=<?php echo $video_id; ?>">
        <span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-watch-comment-vote-up" src="images/pixel-vfl3z5WfW.gif" alt="" title="">
        <span class="yt-uix-button-valign"></span></span>
        </a>
        </button>
        <div class="watch7-hovercard yt-uix-clickcard-content" bis_skin_checked="1">
        <h3 class="watch7-hovercard-header">Sign in to YouTube</h3>
        <div class="watch7-hovercard-message" bis_skin_checked="1">
        Sign in with your YouTube Account (YouTube, Google+, Gmail, Orkut, Picasa, or Chrome) to rate <span class="yt-user-name " dir="ltr">powerofpride</span>'s comment.
        </div>
        <ul class="watch7-hovercard-icon-strip clearfix">
        <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-youtube-icon" bis_skin_checked="1"></div>
        </li>
        <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-gplus-icon" bis_skin_checked="1"></div>
        </li>
        <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-gmail-icon" bis_skin_checked="1"></div>
        </li>
        <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-picasa-icon" bis_skin_checked="1"></div>
        </li>
        <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-chrome-icon" bis_skin_checked="1"></div>
        </li>
        </ul>
        </div>
        </span><span class="yt-uix-clickcard">
        <a href="/like_dislike_comment.php?action=dislike&comment_id=<?php echo $comment['id']; ?>&video_id=<?php echo $video_id; ?>">
        <button type="button" class="end comment-action-vote-down comment-action yt-uix-clickcard-target yt-uix-button yt-uix-button-link yt-uix-tooltip yt-uix-button-empty" title="" data-action="" data-tooltip-show-delay="300" role="button"><a href="/like_dislike_comment.php?action=dislike&comment_id=<?php echo $comment['id']; ?>&video_id=<?php echo $video_id; ?>">
        <span class="yt-uix-button-icon-wrapper">
        <img class="yt-uix-button-icon yt-uix-button-icon-watch-comment-vote-down" src="images/pixel-vfl3z5WfW_1.gif" alt="" title="">
        <span class="yt-uix-button-valign"></span></span>
        </a>
        </button>
        </a>
        <div class="watch7-hovercard yt-uix-clickcard-content" bis_skin_checked="1">
        <h3 class="watch7-hovercard-header">Sign in to YouTube</h3>
        <div class="watch7-hovercard-message" bis_skin_checked="1">
         Sign in with your YouTube Account (YouTube, Google+, Gmail, Orkut, Picasa, or Chrome) to rate <span class="yt-user-name " dir="ltr">powerofpride</span>'s comment.
        </div>
        <ul class="watch7-hovercard-icon-strip clearfix">
        <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-youtube-icon" bis_skin_checked="1"></div>
        </li>
        <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-gplus-icon" bis_skin_checked="1"></div>
        </li>
        <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-gmail-icon" bis_skin_checked="1"></div>
        </li>
        <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-picasa-icon" bis_skin_checked="1"></div>
        </li>
        <li class="watch7-hovercard-icon">
        <div class="watch7-hovercard-chrome-icon" bis_skin_checked="1"></div>
        </li>
        </ul>
        <div class="watch7-hovercard-account-line" bis_skin_checked="1">
        <a href="https://web.archive.org/web/20210213060416/http://web.archive.org/web/20130511011604/https://accounts.google.com/ServiceLogin?service=youtube&amp;uilel=3&amp;hl=en_US&amp;passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26hl%3Den_US%26next%3D%252Fwatch%253Fv%253D5Q74CG8RrU0%2526feature%253Drelated%26nomobiletemp%3D1" class="yt-uix-button   yt-uix-sessionlink yt-uix-button-primary" data-sessionlink="ei=05uNUevcOYmpkgLd-IDQDQ"><span class="yt-uix-button-content">Sign in</span></a>
        </div>
        </div>
        </span>
        </div>

</div>
<span id="comment_3678" style="display: none;position: relative; left: 53px; height: 113px; top: 11px;">
<form method="post" action="/watch?v=10891">
<textarea rows="6" name="msg"></textarea><br>
<input style="display:none;" name="keys" value="">
<input style="display:none;" name="touser" value="10891">
<input name="reply" value="3678" style="display:none;">
<input type="submit">
</form>
</span>
</li>
                <?php endforeach; ?>
</ul>
        <?php else: ?>
            <p>No comments yet.</p>
        <?php endif; ?>




<script>
    // Function to check and update subscription status
    function checkSubscriptionStatus(channelId) {
        // Replace with your PHP endpoint URL
        const checkUrl = `check_subscription.php`;

        // Data to send via POST to PHP
        const formData = new FormData();
        formData.append('user_id', channelId); // Adjust as per your PHP variable name

        // AJAX request to check subscription status
        fetch(checkUrl, {
            method: 'POST',
            body: formData,
        })
        .then(response => response.text())
        .then(data => {
            // Handle PHP response
            if (data.trim() === 'subscribed') {
                // User is already subscribed, update UI
                updateSubscriptionUI(true);
            } else {
                // User is not subscribed, update UI
                updateSubscriptionUI(false);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Error checking subscription status. Please refresh your page.");
        });
    }

    // Function to handle subscription toggle
    function handleSubscriptionToggle(channelId, isSubscribed) {
        // Replace with your PHP endpoint URL
        const actionUrl = isSubscribed ? 'unsubscribe.php' : 'subscribe.php';

        // Data to send via POST to PHP
        const formData = new FormData();
        formData.append('user_id', channelId); // Adjust as per your PHP variable name

        // AJAX request to handle subscription toggle
        fetch(actionUrl, {
            method: 'POST',
            body: formData,
        })
        .then(response => response.text())
        .then(data => {
            // Handle PHP response
            if (data.startsWith("Error")) {
                alert(data); // Display PHP error message
            } else {
                // Update UI based on new subscription status
                if (isSubscribed) {
                    updateSubscriptionUI(false); // Unsubscribed successfully
                } else {
                    updateSubscriptionUI(true); // Subscribed successfully
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Error toggling subscription. Please refresh your page.");
        });
    }

    // Function to update UI based on subscription status
    function updateSubscriptionUI(isSubscribed) {
        var button = document.querySelector('.yt-uix-subscription-button');
        var subscribeLabel = button.querySelector('.subscribe-label');
        var subscribedLabel = button.querySelector('.subscribed-label');
        var unsubscribeLabel = button.querySelector('.unsubscribe-label');

        if (isSubscribed) {
            // Update UI to 'subscribed' appearance
            button.classList.remove('yt-uix-button-subscribe-branded');
            button.classList.add('yt-uix-button-subscribed-branded');
            subscribeLabel.style.display = 'none';
            subscribedLabel.style.display = 'inline';
            unsubscribeLabel.style.display = 'inline'; // Show unsubscribe option
        } else {
            // Update UI to 'not subscribed' appearance
            button.classList.add('yt-uix-button-subscribe-branded');
            button.classList.remove('yt-uix-button-subscribed-branded');
            subscribeLabel.style.display = 'inline';
            subscribedLabel.style.display = 'none';
            unsubscribeLabel.style.display = 'none'; // Hide unsubscribe option
        }
    }

    // Call checkSubscriptionStatus when the page loads or as needed
    document.addEventListener('DOMContentLoaded', function() {
        const channelId = '<?php echo $supercoolvariable; ?>'; // Replace with actual channelId or fetch dynamically
        checkSubscriptionStatus(channelId);
    });

    // Example usage to handle subscription toggle on button click
    document.querySelector('.yt-uix-subscription-button').addEventListener('click', function() {
        const channelId = '<?php echo $supercoolvariable; ?>'; // Replace with actual channelId
        const button = document.querySelector('.yt-uix-subscription-button');
        const isSubscribed = button.classList.contains('yt-uix-button-subscribed-branded');

        handleSubscriptionToggle(channelId, isSubscribed);
    });
</script>




</ul>
</div>
<ul>
<li class="hid" id="parent-comment-loading">Loading comment...</li>
</ul>
</div>
<div id="comments-loading" class="hid" bis_skin_checked="1">Loading...</div>
</div>







        </div>
        <div id="watch7-sidebar" class="watch-sidebar" bis_skin_checked="1">
            
  <div id="watch7-sidebar-discussion" bis_skin_checked="1"></div>


          <div id="watch-channel-brand-div" class="" bis_skin_checked="1">
      <div id="watch-channel-brand-div-text" bis_skin_checked="1">
Advertisement
      </div>
      <div id="google_companion_ad_div" bis_skin_checked="1">
      </div>
    </div>


        <div class="watch-sidebar-section" bis_skin_checked="1">

    <div class="watch-sidebar-body" bis_skin_checked="1">
      <ul id="watch-related" class="video-list">
        
        
        
    <?php foreach ($random_videos as $video): ?>
        <!-- start related -->
    <li class="video-list-item related-list-item"><a href="watch.php?id=<?php echo $video['id']; ?>" class="related-video yt-uix-contextlink  spf-link yt-uix-sessionlink" data-sessionlink="ved=CBcQzRooEw&amp;ei=I3oUUvO0DM-0iAKV34H4BQ&amp;feature=related"><span class="ux-thumb-wrap contains-addto ">    <span class="video-thumb  yt-thumb yt-thumb-120">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <span class="yt-thumb-clip-inner">
            <img data-thumb="https://betacastusercontent.0ci.lol/vi/thumb/video-65f4fdea5bad71.39627908.jpg" alt="" src="<?php echo $video['thumbnail']; ?>" width="120" data-group-key="thumb-group-1">
            <span class="vertical-align"></span>
          </span>
        </span>
      </span>
    </span>
    </span>
<img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW_2.gif" alt="" title="">
<span dir="ltr" class="title" title="Elevator in an Ohio Burger King"><?php echo htmlspecialchars($video['title']); ?></span><span class="stat attribution">by <span class="yt-user-name  g-hovercard" dir="ltr" data-ytid="UCDJkdllLHD5dkh33xSEdK"><?php echo htmlspecialchars($video['username']); ?><span class="yt-user-name-icon-verified">
  </span></span></span><span class="stat view-count"><?php echo $video['views']; ?> views</span></a></li>
    <?php endforeach; ?>    <!-- start related -->
    </span>
    </span>


            <div id="watch-more-related" class="hid" bis_skin_checked="1">
  </div>
    </span>
</button>

      </ul>
    </div>   </div> 

        </div>
      </div>
    </div>

      <div style="visibility: hidden; height: 0px; padding: 0px; overflow: hidden;" bis_skin_checked="1">
      <img src="//web.archive.org/web/20130821082818im_/http://www.youtube-nocookie.com/gen_204?attributionpartner=Alloy" border="0" width="1" height="1">
  </div>

  </div>
</div>
<!-- end channel: -->
</div></div></div>  <div id="footer-container"><div id="footer"><div id="footer-main"><div id="footer-l0go"><a href="/" title="BetaCast home"><img height="30px" width="72px" id="logo1" src="images/betacast-logo.png" alt="BetaCast home"></a></div> 
 

</div><div id="footer-links"><ul id="footer-links-primary">  <li><a href="/about">About</a></li>
  <li><a href="/blog">Press &amp; Blogs</a></li>
  <li><a href="/copyright">Copyright</a></li>
  <li><a href="/creators">Creators &amp; Partners</a></li>
  <li><a href="/advertise">Advertising</a></li>
  <li><a href="/dev">Developers</a></li>
</ul><ul id="footer-links-secondary">  <li><a href="/tos">Terms</a></li>
  <li><a href="/policyandsafety">
Policy &amp; Safety
  </a></li>
  <li>  <span class="copyright" dir="ltr">© 2024 BetaCast</span>
</li>
</ul></div></div></div>


      <div class="yt-dialog hid" id="feed-privacy-lb">
    <div class="yt-dialog-base">
      <span class="yt-dialog-align"></span>
      <div class="yt-dialog-fg">
        <div class="yt-dialog-fg-content">
          <div class="yt-dialog-loading">
              <div class="yt-dialog-waiting-content">
    <div class="yt-spinner-img"></div><div class="yt-dialog-waiting-text">Loading...</div>
  </div>

          </div>
          <div class="yt-dialog-content">
              <div id="feed-privacy-dialog">
  </div>

          </div>
          <div class="yt-dialog-working">
              <div id="yt-dialog-working-overlay">
  </div>
  <div id="yt-dialog-working-bubble">
    <div class="yt-dialog-waiting-content">
      <div class="yt-spinner-img"></div><div class="yt-dialog-waiting-text">Working...</div>
    </div>
  </div>

          </div>
        </div>
      </div>
    </div>
  </div>



    <div id="shared-addto-watch-later-login" class="hid">
      <a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dplaylist%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="sign-in-link">Sign in</a> to add this to Watch Later

    </div>
  

  





</body></html>