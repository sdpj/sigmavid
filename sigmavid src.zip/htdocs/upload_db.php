<?php
// Start the session
session_start();

// Include the database connection file
include 'db.php';

// Set default timezone to CST
date_default_timezone_set('America/Chicago');

// CAPTCHA site key and secret key
$recaptchaSecret = '6Le_PBMqAAAAAP3gIfis7Qq8i1l4hAY_gHDOg2CM';

// Validate CAPTCHA
if (isset($_POST['g-recaptcha-response'])) {
    $recaptchaResponse = $_POST['g-recaptcha-response'];
    $remoteIp = $_SERVER['REMOTE_ADDR'];

    $recaptchaUrl = 'https://www.google.com/recaptcha/api/siteverify';
    $recaptchaData = [
        'secret' => $recaptchaSecret,
        'response' => $recaptchaResponse,
        'remoteip' => $remoteIp
    ];

    // cURL request to validate the CAPTCHA
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $recaptchaUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($recaptchaData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $recaptchaResponse = curl_exec($ch);
    curl_close($ch);

    $recaptchaResponseKeys = json_decode($recaptchaResponse, true);

    if (!$recaptchaResponseKeys['success']) {
        die(json_encode(["status" => "error", "message" => "CAPTCHA validation failed."]));
    }
} else {
    die(json_encode(["status" => "error", "message" => "CAPTCHA is required."]));
}

// Check if the user is logged in
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    die(json_encode(["status" => "error", "message" => "User is not logged in."]));
}

$user_id = intval($_SESSION['user_id']);

// Check the upload cooldown
$cooldownPeriod = 60 * 5; // 5 minutes in seconds
$now = time();
$lastUploadQuery = "SELECT last_upload FROM users WHERE id = $user_id";
$lastUploadResult = $conn->query($lastUploadQuery);

if ($lastUploadResult->num_rows > 0) {
    $lastUploadRow = $lastUploadResult->fetch_assoc();
    $lastUploadTime = strtotime($lastUploadRow['last_upload']);

    if ($now - $lastUploadTime < $cooldownPeriod) {
        $timeRemaining = $cooldownPeriod - ($now - $lastUploadTime);
        die(json_encode(["status" => "error", "message" => "Please wait " . round($timeRemaining / 60) . " minutes before uploading again."]));
    }
}

// Retrieve data from POST request
$title = isset($_POST['title']) ? $conn->real_escape_string($_POST['title']) : '';
$description = isset($_POST['description']) ? $conn->real_escape_string($_POST['description']) : '';
$category = isset($_POST['category']) ? $conn->real_escape_string($_POST['category']) : '';
$filename = isset($_POST['filename']) ? $conn->real_escape_string($_POST['filename']) : '';
$thumbnail = isset($_POST['thumbnail']) ? $conn->real_escape_string('uploads/' . $_POST['thumbnail']) : 'default_thumbnail.jpg';

// If no thumbnail was set, default to 'default_thumbnail.jpg'
if (empty($thumbnail)) {
    $thumbnail = 'default_thumbnail.jpg';
}

// Replace file extension with .mp4
$pathInfo = pathinfo($filename);
$filename = $pathInfo['filename'] . '.mp4';

// Define disallowed words
$disallowedWords = ['nigger', 'faggot', 'nazi', 'hitler', 'uttp', 'svtp', 'sigmavidtrollpolice', 'gore'];

// Function to ban a user
function banUser($conn, $username, $ip_address, $reason, $expires_at) {
    $conn->begin_transaction();
    
    try {
        $stmt = $conn->prepare("INSERT INTO bans (username, ip_address, is_ip_ban, reason, expires_at) VALUES (?, ?, 1, ?, ?)");
        if ($stmt === false) {
            throw new Exception('Prepare failed: ' . $conn->error);
        }
        $stmt->bind_param("ssss", $username, $ip_address, $reason, $expires_at);
        if (!$stmt->execute()) {
            throw new Exception('Execute failed: ' . $stmt->error);
        }

        $stmt = $conn->prepare("DELETE FROM users WHERE username = ?");
        if ($stmt === false) {
            throw new Exception('Prepare failed: ' . $conn->error);
        }
        $stmt->bind_param("s", $username);
        if (!$stmt->execute()) {
            throw new Exception('Execute failed: ' . $stmt->error);
        }

        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        die($e->getMessage());
    }
}

// Check for disallowed words in the title
foreach ($disallowedWords as $word) {
    if (stripos($title, $word) !== false) {
        // Get user information
        $usernameQuery = "SELECT username, ip_address FROM users WHERE id = $user_id";
        $usernameResult = $conn->query($usernameQuery);
        if ($usernameResult->num_rows > 0) {
            $user = $usernameResult->fetch_assoc();
            $username = $user['username'];
            $ip_address = $user['ip_address'];
            
            // Ban the user
            $banReason = "Use of disallowed words in upload";
            $expires_at = null; // Infinite ban

            if (banUser($conn, $username, $ip_address, $banReason, $expires_at)) {
                die(json_encode(["status" => "error", "message" => "You have been banned."]));
            } else {
                die(json_encode(["status" => "error", "message" => "Error banning user."]));
            }
        } else {
            die(json_encode(["status" => "error", "message" => "Error retrieving user information."]));
        }
    }
}

// Check if all required data is present
if (empty($title) || empty($filename) || $user_id == 0) {
    die(json_encode(["status" => "error", "message" => "Missing required data."]));
}

// Check if the video already exists
$checkVideoQuery = "SELECT COUNT(*) AS count FROM videos WHERE filename = '$filename' AND user_id = $user_id";
$checkVideoResult = $conn->query($checkVideoQuery);
$checkVideoRow = $checkVideoResult->fetch_assoc();

if ($checkVideoRow['count'] > 0) {
    die(json_encode(["status" => "error", "message" => "A video with this filename already exists."]));
}

// Insert video data into the database
$sql = "INSERT INTO videos (title, description, category, thumbnail, filename, user_id)
        VALUES ('$title', '$description', '$category', '$thumbnail', '$filename', $user_id)";

if ($conn->query($sql) === TRUE) {
    // Update last upload timestamp
    $updateLastUpload = "UPDATE users SET last_upload = NOW() WHERE id = $user_id";
    $conn->query($updateLastUpload);

    // Retrieve the generated thumbnail if available
    $thumbnailQuery = "SELECT thumbnail FROM videos WHERE filename = '$filename' AND user_id = $user_id";
    $result = $conn->query($thumbnailQuery);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $thumbnail = 'uploads/' . $row['thumbnail']; // Add 'uploads/' before the thumbnail path
        echo json_encode([
            "status" => "success",
            "message" => "New video uploaded successfully.",
            "thumbnail" => $thumbnail
        ]);
    } else {
        echo json_encode([
            "status" => "success",
            "message" => "New video uploaded successfully, but thumbnail not found."
        ]);
    }
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Error: " . $conn->error
    ]);
}

$conn->close();
?>
