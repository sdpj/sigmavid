<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $targetDir = __DIR__ . '/uploads/';
    $statusFileDir = __DIR__ . '/processing_status/';

    // Allowed MIME types and extensions
    $allowedMimeTypes = ['video/mp4', 'video/x-msvideo', 'video/quicktime', 'video/webm'];
    $allowedExtensions = ['mp4', 'avi', 'mov', 'webm'];

    // Read the filename and chunk information
    $filename = basename($_POST['filename']); // Use basename to strip out any path
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

    // Sanitize filename to prevent directory traversal
    $filename = preg_replace('/[^a-zA-Z0-9_-]+/', '_', $filename);

    $chunk = intval($_POST['chunk']);
    $totalChunks = intval($_POST['totalChunks']);
    $file = $_FILES['file'];
    $chunkId = $_POST['chunkId']; // Get the unique chunk ID sent with each chunk

    // Get MIME type
    $fileMimeType = mime_content_type($file['tmp_name']);

    // Check MIME type and extension
    if (!in_array($fileMimeType, $allowedMimeTypes) || !in_array($extension, $allowedExtensions)) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid file type. Only video files are allowed."]);
        exit;
    }

    // Check if a file with the same name already exists
    $finalFileName = $chunkId . '.' . $extension;
    $finalFile = $targetDir . $finalFileName;

    if (file_exists($finalFile)) {
        // File already exists
        http_response_code(400);
        echo json_encode(["error" => "A file with the same name already exists."]);
        exit;
    }

    // Prepare target file path
    $chunkFileName = $chunkId . '.part' . $chunk;
    $targetFile = $targetDir . $chunkFileName;

    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        // Check if all chunks are uploaded
        $chunks = [];
        for ($i = 0; $i < $totalChunks; $i++) {
            $chunks[] = $targetDir . $chunkId . '.part' . $i;
        }

        $allChunksUploaded = true;
        foreach ($chunks as $chunkPath) {
            if (!file_exists($chunkPath)) {
                $allChunksUploaded = false;
                break;
            }
        }

        if ($allChunksUploaded) {
            // Combine chunks
            $outputFile = fopen($finalFile, 'wb');
            foreach ($chunks as $chunkPath) {
                $inputFile = fopen($chunkPath, 'rb');
                stream_copy_to_stream($inputFile, $outputFile);
                fclose($inputFile);
                unlink($chunkPath); // Remove chunk after merging
            }
            fclose($outputFile);

            // Create status file and initialize processing status
            $statusFile = $statusFileDir . $chunkId . '.status';
            file_put_contents($statusFile, 'processing');

            // Send the file details to the Python server for processing
            $client = stream_socket_client("tcp://localhost:6969", $errno, $errorMessage);
            if ($client === false) {
                http_response_code(500);
                echo json_encode(["error" => "Failed to connect to the Python server."]);
                exit;
            }

            fwrite($client, "$finalFile,$finalFile");
            fclose($client);

            // Only return the filename after the upload is complete
            echo json_encode([
                "status" => "success",
                "newFileName" => $finalFileName
            ]);
        } else {
            echo json_encode(["status" => "success"]);
        }
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Failed to upload file."]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed."]);
}
?>
