<?php
    include 'db.php';

// SQL query
$sql = "SELECT ticker FROM settings WHERE id = 1";

// Execute the query
$result = $conn->query($sql);

// Check if the query returned a result
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $ticker = $row['ticker'];
} 

?>
