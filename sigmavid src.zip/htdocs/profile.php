<?php
session_start();
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

function handleUpload($file, $default, $target_dir) {
    if ($file['error'] === UPLOAD_ERR_OK) {
        // Generate a random file name using uniqid, time, and a random number
        $unique_id = uniqid() . time() . rand(1000, 9999);
        $imageFileType = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $new_filename = $unique_id . '.' . $imageFileType;
        $target_file = $target_dir . $new_filename;
        
        $check = getimagesize($file['tmp_name']);
        
        // Validate file type and size
        if ($check !== false && in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif']) && $file['size'] <= 5000000) {
            if (move_uploaded_file($file['tmp_name'], $target_file)) {
                return $target_file;
            }
        }
    }
    return $default;
}


// Check if profile picture update form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile_picture']) && isset($_FILES['profile_picture'])) {
    $target_dir = "uploads/";
    $profile_picture = handleUpload($_FILES['profile_picture'], $target_dir . 'default_pfp.jpg', $target_dir);

    // Update profile picture in database
    $stmt = $conn->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
    $stmt->bind_param("si", $profile_picture, $user_id);

    if ($stmt->execute()) {
        header("Location: profile.php");
        exit();
    } else {
        echo "Error updating profile picture: " . $stmt->error;
    }
    $stmt->close();
}

// Check if banner art update form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_banner_art']) && isset($_FILES['banner_art'])) {
    $target_dir = "uploads/";
    $banner_art = handleUpload($_FILES['banner_art'], $target_dir . 'default_banner.jpg', $target_dir);

    // Update banner art in database
    $stmt = $conn->prepare("UPDATE users SET banner_art = ? WHERE id = ?");
    $stmt->bind_param("si", $banner_art, $user_id);

    if ($stmt->execute()) {
        header("Location: profile.php");
        exit();
    } else {
        echo "Error updating banner art: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch current user data
$stmt = $conn->prepare("SELECT username, profile_picture, banner_art FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $profile_picture, $banner_art);
$stmt->fetch();
$stmt->close();

$conn->close();
?>



<?php
session_start(); // Start the session

include 'db.php';

// Function to get time ago string
function getTimeAgoString($video)
{
    if ($video['years_ago'] > 0) {
        return $video['years_ago'] . ' years ago';
    } elseif ($video['months_ago'] > 0) {
        return $video['months_ago'] . ' months ago';
    } elseif ($video['weeks_ago'] > 0) {
        return $video['weeks_ago'] . ' weeks ago';
    } elseif ($video['days_ago'] > 0) {
        return $video['days_ago'] . ' days ago';
    } elseif ($video['hours_ago'] > 0) {
        return $video['hours_ago'] . ' hours ago';
    } elseif ($video['minutes_ago'] > 0) {
        return $video['minutes_ago'] . ' minutes ago';
    } else {
        return $video['seconds_ago'] . ' seconds ago';
    }
}

// Fetch user details if logged in
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user = null;

function getSubscriberCount($userId, $conn) {
    $userId = mysqli_real_escape_string($conn, $userId);
    $query = "SELECT COUNT(*) AS subscriber_count FROM subscriptions WHERE user_id = '$userId'";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);
    return $data['subscriber_count'];
}

// Fetch subscriber count for the logged-in user if available
$subscriberCount = 0; // Default value

if ($user_id) {
    // Fetch user details from the database
    $stmt_user = $conn->prepare("SELECT id, username, profile_picture FROM users WHERE id = ?");
    $stmt_user->bind_param("i", $user_id);
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();
    $loggedInUserId = $_SESSION['user_id'];
    $subscriberCount = getSubscriberCount($loggedInUserId, $conn);
    
    if ($result_user->num_rows > 0) {
        $user = $result_user->fetch_assoc();
    }
    $stmt_user->close();
}

// Fetch featured videos with thumbnails, usernames, and upload time ago
$stmt_featured = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    WHERE v.is_featured = 1
    ORDER BY v.id DESC
    LIMIT 4
");
$stmt_featured->execute();
$result_featured = $stmt_featured->get_result();
$featured_videos = [];
while ($row = $result_featured->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $featured_videos[] = $row;
}
$stmt_featured->close();

// Fetch up to 6 most recent videos with thumbnails, usernames, and upload time ago, sorted by upload time
$stmt_recent = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    WHERE v.is_featured = 0
    ORDER BY v.uploaded_at DESC
    LIMIT 6
");
$stmt_recent->execute();
$result_recent = $stmt_recent->get_result();
$recent_videos = [];
while ($row = $result_recent->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $recent_videos[] = $row;
}
$stmt_recent->close();

function getRandomChannels($conn, $count = 3) {
    $stmt_random = $conn->prepare("
        SELECT id, username, profile_picture
        FROM users
        ORDER BY RAND()
        LIMIT $count
    ");
    $stmt_random->execute();
    $result_random = $stmt_random->get_result();
    $random_channels = [];
    while ($row = $result_random->fetch_assoc()) {
        $random_channels[] = $row;
    }
    $stmt_random->close();
    return $random_channels;
}

// Fetch up to 8 most popular videos with thumbnails, usernames, and upload time ago, sorted by views
$stmt_popular = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    ORDER BY v.views DESC
    LIMIT 8
");
$random_channels = getRandomChannels($conn, 3);
$stmt_popular->execute();
$result_popular = $stmt_popular->get_result();
$popular_videos = [];
while ($row = $result_popular->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $popular_videos[] = $row;
}
$stmt_popular->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en" data-cast-api-enabled="true">
   <head>
      <link id="css-2838365198" class="www-core" rel="stylesheet" href="css/main.css" data-loaded="true">
      <title>SigmaVid</title>
      <link rel="search" type="application/opensearchdescription+xml" href="https://www.youtube.com/opensearch?locale=en_US" title="SigmaVid Video Search">
      <link rel="shortcut icon" href="favicon-vfldLzJxy.ico" type="image/x-icon">
      <link rel="icon" href="images/favicon_32-vflWoMFGx.png" sizes="32x32">
      <link rel="alternate" media="handheld" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
      <link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
      <meta name="description" content="Share your videos with friends, family, and the world">
      <meta name="keywords" content="video, sharing, camera phone, video phone, free, upload">
      <meta property="og:image" content="images/youtube_logo_stacked-vfl225ZTx.png">
      <meta property="fb:app_id" content="87741124305">
      <link rel="publisher" href="https://plus.google.com/115229808208707341778">
      <script>if (window.ytcsi) {window.ytcsi.tick("cl", null, '');}</script>
   </head>
   <!-- machid: palZfX2ZGYUViS0hwbGFMVlBQendwdzI3bU9YYzVsVk1ZQkNyVGpZS1VZUWEtME9uZkR2WFZn -->
   <body dir="ltr" class="  ltr        site-left-aligned  hitchhiker-enabled    guide-enabled  guide-expanded  " id="body">
      <div id="body-container">
         <form name="logoutForm" method="POST" action="/logout"><input type="hidden" name="action_logout" value="1"></form>
<?php include 'header.php'; ?>
         <div id="alerts">
         </div>
         <div id="page-container">
            <div id="page" class="  home     branded-page-v2-masthead-ad-header  clearfix">
<?php include 'guide.php' ?>
<div id="player" class="  off-screen  ">
                  <div id="playlist" class="playlist">
                  </div>
                  <div id="player-unavailable" class="  hid  ">
                  </div>
                  <div id="player-api" class="player-width player-height off-screen-target watch-content player-api"></div>
                  <script>if (window.ytcsi) {window.ytcsi.tick("bf", null, '');}</script>
                  <script>var ytplayer = ytplayer || {};ytplayer.config = {"attrs": {"id": "movie_player"}, "params": {"bgcolor": "#000000", "allowfullscreen": "true", "allowscriptaccess": "always"}, "assets": {"html": "\/html5_player_template", "css": "\/\/s.ytimg.com\/yts\/cssbin\/www-player-vflzE0TL9.css", "js": "\/\/s.ytimg.com\/yts\/jsbin\/html5player-vfl66X2C5.js"}, "url_v8": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/cps.swf", "url_v9as2": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/cps.swf", "url": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/watch_as3.swf", "args": {"enablejsapi": 1, "hl": "", "fexp": "903802,936905,910207,916611,936912,936910,923305,936913,907231", "autoplay": "0", "cr": ""}, "sts": 16031, "min_version": "8.0.0", "html5": false};</script>
                  <div id="playlist-tray" class="playlist-tray">
                  </div>
                  <div class="clear"></div>
               </div>
               
<div id="content" class="content">

<h1 style="font-size:30px;">Profile</h1>
<form action="profile.php" method="post" enctype="multipart/form-data">
    <label for="profile_picture">Profile Picture:</label>
    <input type="file" id="profile_picture" name="profile_picture" accept="image/*"><br>
    <input type="submit" name="update_profile_picture" value="Update Profile Picture">
</form>

<form action="profile.php" method="post" enctype="multipart/form-data">
    <label for="banner_art">Banner Art:</label>
    <input type="file" id="banner_art" name="banner_art" accept="image/*"><br>
    <input type="submit" name="update_banner_art" value="Update Banner Art">
</form>


</div>

               
               
               
               
               
               
               
               
               
            </div>
         </div>
      </div>
      <div id="footer-container">
         <div id="footer">
            <div id="footer-main">
               <div id="footer-l0go"><a href="/" title="SigmaVid home"><img height="30px" width="72px" id="logo1" src="images/SigmaVid-logo.png" alt="SigmaVid home"></a></div>
            </div>
            <div id="footer-links">
               <ul id="footer-links-primary">
                  <li><a href="/about">About</a></li>
                  <li><a href="/blog">Press &amp; Blogs</a></li>
                  <li><a href="/copyright">Copyright</a></li>
                  <li><a href="/creators">Creators &amp; Partners</a></li>
                  <li><a href="/advertise">Advertising</a></li>
                  <li><a href="/dev">Developers</a></li>
               </ul>
               <ul id="footer-links-secondary">
                  <li><a href="/tos">Terms</a></li>
                  <li><a href="/policyandsafety">
                     Policy &amp; Safety
                     </a>
                  </li>
                  <li>  <span class="copyright" dir="ltr">© 2024 SigmaVid</span></li>
               </ul>
            </div>
         </div>
      </div>
      <div class="yt-dialog hid" id="feed-privacy-lb">
         <div class="yt-dialog-base">
            <span class="yt-dialog-align"></span>
            <div class="yt-dialog-fg">
               <div class="yt-dialog-fg-content">
                  <div class="yt-dialog-loading">
                     <div class="yt-dialog-waiting-content">
                        <div class="yt-spinner-img"></div>
                        <div class="yt-dialog-waiting-text">Loading...</div>
                     </div>
                  </div>
                  <div class="yt-dialog-content">
                     <div id="feed-privacy-dialog">
                     </div>
                  </div>
                  <div class="yt-dialog-working">
                     <div id="yt-dialog-working-overlay">
                     </div>
                     <div id="yt-dialog-working-bubble">
                        <div class="yt-dialog-waiting-content">
                           <div class="yt-spinner-img"></div>
                           <div class="yt-dialog-waiting-text">Working...</div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="shared-addto-watch-later-login" class="hid">
         <a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dplaylist%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="sign-in-link">Sign in</a> to add this to Watch Later
      </div>
      <div id="shared-addto-menu" style="display: none;" class="hid sign-in">
         <div class="addto-menu">
            <div id="addto-list-panel" class="menu-panel active-panel">
               <span class="addto-playlist-item yt-uix-button-menu-item yt-uix-tooltip sign-in" data-possible-tooltip="" data-tooltip-show-delay="750">
               <img class="playlist-status" src="images/pixel-vfl3z5WfW.gif" alt="" title=""><a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dplaylist%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="sign-in-link">Sign in</a> to add this to Watch Later
               </span>
            </div>
            <div id="addto-list-saving-panel" class="menu-panel">
               <div class="addto-loading loading-content">
                  <p class="yt-spinner">
                     <img class="yt-spinner-img" src="images/pixel-vfl3z5WfW.gif" alt="Loading icon" title="">
                     <span class="yt-spinner-message">
                     Loading playlists...
                     </span>
                  </p>
               </div>
            </div>
            <div id="addto-list-error-panel" class="menu-panel">
               <div class="panel-content">
                  <img src="images/pixel-vfl3z5WfW.gif">
                  <span class="error-details"></span>
                  <a class="show-menu-link">Back</a>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>







