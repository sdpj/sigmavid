<?php
$file = isset($_GET['file']) ? $_GET['file'] : '';
$statusFile = __DIR__ . '/uploads/' . $file . '.status';

if (file_exists($statusFile)) {
    $status = file_get_contents($statusFile);
    echo json_encode(["status" => $status]);
} else {
    echo json_encode(["status" => "processing"]);
}
?>
