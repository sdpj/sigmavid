<?php
session_start();
include 'db.php'; // Your database connection file

// Check if the user is an admin
$user_id = $_SESSION['user_id'];
$query = "SELECT role FROM users WHERE id = $user_id LIMIT 1";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

if ($row['role'] !== 'admin') {
    header('Location: index.php'); // Redirect to home page if not an admin
    exit;
}

// Fetch current maintenance mode status
$query = "SELECT maintenance_mode FROM settings LIMIT 1";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$maintenance_mode = $row['maintenance_mode'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = isset($_POST['maintenance_mode']) ? 1 : 0;

    // Update maintenance mode status in the database
    $update_query = "UPDATE settings SET maintenance_mode = $new_status";
    mysqli_query($conn, $update_query);

    header('Location: maintenance.php'); // Redirect to avoid form resubmission
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Maintenance Toggle</title>
</head>
<body>
    <h1>Maintenance Mode</h1>
    <form method="post">
        <label>
            <input type="checkbox" name="maintenance_mode" <?php if ($maintenance_mode) echo 'checked'; ?>> Enable Maintenance Mode
        </label>
        <button type="submit">Save</button>
    </form>
</body>
</html>
