<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($user_id, $db_username, $db_password);
    $stmt->fetch();

    if (password_verify($password, $db_password)) {
        $_SESSION['user_id'] = $user_id;
        header("Location: index.php");
    } else {
        echo "Login failed. Please check your username and password.";
    }

    $stmt->close();
}

$conn->close();
?>