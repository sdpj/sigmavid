<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en" data-cast-api-enabled="true">
   <head>
      <link id="css-2838365198" class="www-core" rel="stylesheet" href="css/main.css" data-loaded="true">
      <title>SigmaVid</title>
      <link rel="search" type="application/opensearchdescription+xml" href="https://www.youtube.com/opensearch?locale=en_US" title="SigmaVid Video Search">
      <link rel="shortcut icon" href="favicon-vfldLzJxy.ico" type="image/x-icon">
      <link rel="icon" href="images/favicon_32-vflWoMFGx.png" sizes="32x32">
      <link rel="alternate" media="handheld" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
      <link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
      <meta name="description" content="Share your videos with friends, family, and the world">
      <meta name="keywords" content="video, sharing, camera phone, video phone, free, upload">
      <meta property="og:image" content="images/youtube_logo_stacked-vfl225ZTx.png">
      <meta property="fb:app_id" content="87741124305">
      <link rel="publisher" href="https://plus.google.com/115229808208707341778">
      <script>if (window.ytcsi) {window.ytcsi.tick("cl", null, '');}</script>
   </head>
   <!-- machid: palZfX2ZGYUViS0hwbGFMVlBQendwdzI3bU9YYzVsVk1ZQkNyVGpZS1VZUWEtME9uZkR2WFZn -->
   <body dir="ltr" class="  ltr        site-left-aligned  hitchhiker-enabled    guide-enabled  guide-expanded  " id="body">
      <div id="body-container">
         <form name="logoutForm" method="POST" action="/logout"><input type="hidden" name="action_logout" value="1"></form>
<?php include 'header.php'; ?>
         <div id="alerts">
         </div>
         <div id="page-container">
            <div id="page" class="  home     branded-page-v2-masthead-ad-header  clearfix">
<?php include 'guide.php'; ?>
               <div id="player" class="  off-screen  ">
                  <div id="playlist" class="playlist">
                  </div>
                  <div id="player-unavailable" class="  hid  ">
                  </div>
                  <div id="player-api" class="player-width player-height off-screen-target watch-content player-api"></div>
                  <script>if (window.ytcsi) {window.ytcsi.tick("bf", null, '');}</script>
                  <script>var ytplayer = ytplayer || {};ytplayer.config = {"attrs": {"id": "movie_player"}, "params": {"bgcolor": "#000000", "allowfullscreen": "true", "allowscriptaccess": "always"}, "assets": {"html": "\/html5_player_template", "css": "\/\/s.ytimg.com\/yts\/cssbin\/www-player-vflzE0TL9.css", "js": "\/\/s.ytimg.com\/yts\/jsbin\/html5player-vfl66X2C5.js"}, "url_v8": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/cps.swf", "url_v9as2": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/cps.swf", "url": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/watch_as3.swf", "args": {"enablejsapi": 1, "hl": "", "fexp": "903802,936905,910207,916611,936912,936910,923305,936913,907231", "autoplay": "0", "cr": ""}, "sts": 16031, "min_version": "8.0.0", "html5": false};</script>
                  <div id="playlist-tray" class="playlist-tray">
                  </div>
                  <div class="clear"></div>
               </div>
               
               <!-- index.php -->
<?php
// Include database connection
include 'db.php';

// Initialize variables for search query and results
$search_query = "";
$videos = [];

// Process search query if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['search_query'])) {
    // Sanitize input to prevent SQL injection
    $search_query = mysqli_real_escape_string($conn, $_GET['search_query']);

    // Perform search query
    $sql = "SELECT * FROM videos WHERE title LIKE '%$search_query%' OR description LIKE '%$search_query%'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch all rows into an associative array
        while ($row = $result->fetch_assoc()) {
            $videos[] = $row;
        }
    } else {
        echo "No videos found matching your search.";
    }
}

function getTimeAgoString($uploaded_at)
{
    try {
        $now = new DateTime();
        $uploadedDate = new DateTime($uploaded_at);
        $interval = $now->diff($uploadedDate);

        if ($interval->y > 0) {
            return $interval->y . ' years ago';
        } elseif ($interval->m > 0) {
            return $interval->m . ' months ago';
        } elseif ($interval->d > 0) {
            return $interval->d . ' days ago';
        } elseif ($interval->h > 0) {
            return $interval->h . ' hours ago';
        } elseif ($interval->i > 0) {
            return $interval->i . ' minutes ago';
        } else {
            return $interval->s . ' seconds ago';
        }
    } catch (Exception $e) {
        // Log or display error message
        return 'Error calculating time ago';
    }
}


// Close MySQL connection
$conn->close();
?>
<div id="content" class="content">

    <?php if (!empty($videos)): ?>
        <h3>Search Results</h3>
        <?php foreach ($videos as $video): ?>

            
         <li style="height:110px;  list-style-type: none;" class="yt-lockup clearfix yt-uix-tile result-item-padding yt-lockup-video yt-lockup-tile context-data-item" data-context-item-views="1390 views" data-context-item-time="" data-context-item-title="bora toma uma" data-context-item-user="dreckin1" data-context-item-id="PaCGHPGQC9Q" data-context-item-type="video">
	    <div class="yt-lockup-thumbnail" bis_skin_checked="1">
		<a href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto " data-sessionlink="ei=KN8qUvqxI-OgkgKarYGYDw&amp;ved=CAUQwBs">    <span class="video-thumb  yt-thumb yt-thumb-185">
	      
		  <span class="yt-thumb-default">
		<span class="yt-thumb-clip">
		  <span class="yt-thumb-clip-inner">
		    <img src="<?php echo htmlspecialchars($video['thumbnail']); ?>" alt="Thumbnail" width="185">
		    <span class="vertical-align"></span>
		  </span>
		</span>

	      </span>
	    </span>

	  <button type="button" title="Watch Later" class="addto-button video-actions spf-nolink addto-watch-later-button-sign-in yt-uix-button yt-uix-button-default yt-uix-button-size-small yt-uix-tooltip" onclick=";return false;" data-video-ids="PaCGHPGQC9Q" data-button-menu-id="shared-addto-watch-later-login" role="button"><span class="yt-uix-button-content">  <img src="//web.archive.org/web/20130907080912im_/http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="Watch Later">
	 </span><img class="yt-uix-button-arrow" src="https://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="" title=""></button>
	</a>

	    </div>
	    <div class="yt-lockup-content" bis_skin_checked="1">
		    <h3 class="yt-lockup-title">
	    <a class="yt-uix-sessionlink yt-uix-tile-link yt-uix-contextlink yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" title="bora toma uma" data-sessionlink="ei=KN8qUvqxI-OgkgKarYGYDw&amp;ved=CAQQvxs" href="/watch?id=<?php echo htmlspecialchars($video['id']); ?>"><span class="yt-ui-ellipsis-wrapper" data-original-html="bora toma uma	    "><?php echo htmlspecialchars($video['title']); ?>	    </span></a>
				<div class="video-details">
                                          <div class="video-meta">
                                             <span style="font-weight:normal;" class="video-views"><?= htmlspecialchars($video['views']) ?> views •︎ </span>
											<span style="font-weight:normal;" class="video-time-ago"><?= htmlspecialchars(getTimeAgoString($video['uploaded_at'])) ?></span>
                                          </div>
                                          <div style="font-weight:normal;" class="video-description">
                                             <?= htmlspecialchars($video['description']) ?>
                                          </div>
                                          <div style="font-weight:normal;" class="video-uploader">
                                             <a href="channel.php?user_id=<?= htmlspecialchars($video['user_id']) ?>"><?= htmlspecialchars($video['username']) ?></a>
										  </div>
                                       </div>
	  </h3>



	  <div class="yt-lockup-meta" bis_skin_checked="1">
	    <ul class="yt-lockup-meta-info">
	  </div>


	      <div class="yt-lockup-description yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" bis_skin_checked="1"><span class="yt-ui-ellipsis-wrapper" data-original-html="	    ">	    </span></div>


	  

	  


	    </div>
	    
	  </li>
        <?php endforeach; ?>
    <?php endif; ?>

</div>
              
               
               
               
               
               
               
               
               
               
               
            </div>
         </div>
      </div>
      <?php include 'footer.php' ?>
      <div class="yt-dialog hid" id="feed-privacy-lb">
         <div class="yt-dialog-base">
            <span class="yt-dialog-align"></span>
            <div class="yt-dialog-fg">
               <div class="yt-dialog-fg-content">
                  <div class="yt-dialog-loading">
                     <div class="yt-dialog-waiting-content">
                        <div class="yt-spinner-img"></div>
                        <div class="yt-dialog-waiting-text">Loading...</div>
                     </div>
                  </div>
                  <div class="yt-dialog-content">
                     <div id="feed-privacy-dialog">
                     </div>
                  </div>
                  <div class="yt-dialog-working">
                     <div id="yt-dialog-working-overlay">
                     </div>
                     <div id="yt-dialog-working-bubble">
                        <div class="yt-dialog-waiting-content">
                           <div class="yt-spinner-img"></div>
                           <div class="yt-dialog-waiting-text">Working...</div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="shared-addto-watch-later-login" class="hid">
         <a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dplaylist%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="sign-in-link">Sign in</a> to add this to Watch Later
      </div>
      <div id="shared-addto-menu" style="display: none;" class="hid sign-in">
         <div class="addto-menu">
            <div id="addto-list-panel" class="menu-panel active-panel">
               <span class="addto-playlist-item yt-uix-button-menu-item yt-uix-tooltip sign-in" data-possible-tooltip="" data-tooltip-show-delay="750">
               <img class="playlist-status" src="images/pixel-vfl3z5WfW.gif" alt="" title=""><a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dplaylist%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="sign-in-link">Sign in</a> to add this to Watch Later
               </span>
            </div>
            <div id="addto-list-saving-panel" class="menu-panel">
               <div class="addto-loading loading-content">
                  <p class="yt-spinner">
                     <img class="yt-spinner-img" src="images/pixel-vfl3z5WfW.gif" alt="Loading icon" title="">
                     <span class="yt-spinner-message">
                     Loading playlists...
                     </span>
                  </p>
               </div>
            </div>
            <div id="addto-list-error-panel" class="menu-panel">
               <div class="panel-content">
                  <img src="images/pixel-vfl3z5WfW.gif">
                  <span class="error-details"></span>
                  <a class="show-menu-link">Back</a>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>



