<?php
include 'db.php'; // Your database connection file

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}



// Function to check if the user is an admin
function isAdmin($conn, $user_id) {
    $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($role);
    $stmt->fetch();
    $stmt->close();
    return $role === 'admin';
}

// Function to get user ID from username
function getUserIdByUsername($conn, $username) {
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($user_id);
    $stmt->fetch();
    $stmt->close();
    return $user_id;
}

// Function to get IP address from username
function getIPByUsername($conn, $username) {
    $stmt = $conn->prepare("SELECT ip_address FROM users WHERE username = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($ip_address);
    $stmt->fetch();
    $stmt->close();
    return $ip_address;
}

// Function to remove a user from the database
function removeUser($conn, $username) {
    $stmt = $conn->prepare("DELETE FROM users WHERE username = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("s", $username);
    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }
    return $stmt->affected_rows > 0;
}

// Function to ban a user
function banUser($conn, $username, $ip_address, $reason, $expires_at) {
    // Start a transaction
    $conn->begin_transaction();
    
    try {
        // Insert ban record
        $stmt = $conn->prepare("INSERT INTO bans (username, ip_address, is_ip_ban, reason, expires_at) VALUES (?, ?, 1, ?, ?)");
        if ($stmt === false) {
            throw new Exception('Prepare failed: ' . $conn->error);
        }
        $stmt->bind_param("ssss", $username, $ip_address, $reason, $expires_at);
        if (!$stmt->execute()) {
            throw new Exception('Execute failed: ' . $stmt->error);
        }

        // Remove user from users table
        if (!removeUser($conn, $username)) {
            throw new Exception('Failed to remove user.');
        }

        // Commit transaction
        $conn->commit();
        return true;
    } catch (Exception $e) {
        // Rollback transaction in case of error
        $conn->rollback();
        die($e->getMessage());
    }
}


// Function to ban an IP
function banIP($conn, $ip_address, $reason, $expires_at) {
    $stmt = $conn->prepare("INSERT INTO bans (username, ip_address, is_ip_ban, reason, expires_at) VALUES (NULL, ?, 1, ?, ?)");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("sss", $ip_address, $reason, $expires_at);
    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }
    return $stmt->affected_rows > 0;
}

// Function to fetch banned users and IPs
function fetchBans($conn) {
    $result = $conn->query("SELECT * FROM bans WHERE expires_at > NOW() OR expires_at IS NULL");
    if ($result === false) {
        die('Query failed: ' . $conn->error);
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Check if user is logged in and has admin role
if (!isset($_SESSION['user_id']) || !isAdmin($conn, $_SESSION['user_id'])) {
    die('Access denied.');
}

// Check if form is submitted for banning
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['ban_type'])) {
        $ban_type = $_POST['ban_type'];
        $reason = $_POST['reason'];
        $expires_at = isset($_POST['expires_at']) ? $_POST['expires_at'] : null;

        if (isset($_POST['infinite_ban']) && $_POST['infinite_ban'] === 'on') {
            $expires_at = null; // Use NULL for infinite ban
        }

        if ($ban_type === 'user') {
            $username = $_POST['username'];
            if (!empty($username)) {
                $user_id = getUserIdByUsername($conn, $username);
                $ip_address = getIPByUsername($conn, $username);
                if ($user_id) {
                    if (banUser($conn, $username, $ip_address, $reason, $expires_at)) {
                        if (removeUser($conn, $username)) {
                            echo "User '$username' banned and their information removed successfully.";
                        } else {
                            echo "User banned, but failed to remove their information.";
                        }
                    } else {
                        echo "Failed to ban user.";
                    }
                } else {
                    echo "User ID for the username not found.";
                }
            } else {
                echo "Username is required.";
            }
        } elseif ($ban_type === 'ip') {
            $ip_address = $_POST['ip_address'];
            if (banIP($conn, $ip_address, $reason, $expires_at)) {
                echo "IP address banned successfully.";
            } else {
                echo "Failed to ban IP address.";
            }
        }
    }
}

// Fetch existing bans
$bans = fetchBans($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ban Management</title>
</head>
<body>
    <h1>Ban Management</h1>

    <h2>Ban User or IP</h2>
    <form method="POST" action="ban_user.php">
        <label for="ban_type">Ban Type:</label>
        <select id="ban_type" name="ban_type" required>
            <option value="user">User</option>
            <option value="ip">IP</option>
        </select><br><br>

        <div id="user_ban">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username"><br><br>
        </div>

        <div id="ip_ban" style="display: none;">
            <label for="ip_address">IP Address:</label>
            <input type="text" id="ip_address" name="ip_address"><br><br>
        </div>

        <label for="reason">Reason:</label>
        <input type="text" id="reason" name="reason" required><br><br>

        <label for="expires_at">Expires At:</label>
        <input type="datetime-local" id="expires_at" name="expires_at"><br><br>

        <label for="infinite_ban">Infinite Ban:</label>
        <input type="checkbox" id="infinite_ban" name="infinite_ban"><br><br>

        <input type="submit" value="Ban">
    </form>

    <h2>Currently Banned Users and IPs</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>IP Address</th>
            <th>Reason</th>
            <th>Issued At</th>
            <th>Expires At</th>
        </tr>
        <?php foreach ($bans as $ban): ?>
            <tr>
                <td><?php echo htmlspecialchars($ban['id']); ?></td>
                <td><?php echo htmlspecialchars($ban['username']); ?></td>
                <td><?php echo htmlspecialchars($ban['ip_address']); ?></td>
                <td><?php echo htmlspecialchars($ban['reason']); ?></td>
                <td><?php echo htmlspecialchars($ban['issued_at']); ?></td>
                <td><?php echo htmlspecialchars($ban['expires_at']) ?: 'Never'; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <script>
        document.getElementById('ban_type').addEventListener('change', function() {
            var banType = this.value;
            if (banType === 'user') {
                document.getElementById('user_ban').style.display = 'block';
                document.getElementById('ip_ban').style.display = 'none';
            } else if (banType === 'ip') {
                document.getElementById('user_ban').style.display = 'none';
                document.getElementById('ip_ban').style.display = 'block';
            }
        });

        document.getElementById('infinite_ban').addEventListener('change', function() {
            var expiresAtField = document.getElementById('expires_at');
            if (this.checked) {
                expiresAtField.disabled = true;
                expiresAtField.value = ''; // Clear the date if infinite ban is checked
            } else {
                expiresAtField.disabled = false;
            }
        });
    </script>
</body>
</html>
