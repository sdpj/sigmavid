<?php
session_start(); // Start the session

include 'db.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']); // Trim whitespace from the username
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $profile_picture = 'default_pfp.jpg';
    $banner_art = 'default_banner.jpg';

    // Verify reCAPTCHA
    $recaptcha_secret = '6Le_PBMqAAAAAP3gIfis7Qq8i1l4hAY_gHDOg2CM';
    $recaptcha_response = $_POST['g-recaptcha-response'];
    $recaptcha_verify_url = 'https://www.google.com/recaptcha/api/siteverify';

    $response = file_get_contents($recaptcha_verify_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response);
    $response_keys = json_decode($response, true);

    if (intval($response_keys["success"]) !== 1) {
        $error = 'Please complete the reCAPTCHA.';
    } elseif (empty($username) || ctype_space($username)) {
        // Check if the username is empty or only whitespace
        $error = 'Username cannot be blank or just whitespace.';
    } else {
        // Check if the user is banned
        $ban_check_stmt = $conn->prepare("SELECT COUNT(*) FROM bans WHERE username = ?");
        $ban_check_stmt->bind_param("s", $username);
        $ban_check_stmt->execute();
        $ban_check_stmt->bind_result($ban_count);
        $ban_check_stmt->fetch();
        $ban_check_stmt->close();

        if ($ban_count > 0) {
            $error = "There was an error creating your account.";
        } else {
            // Check if username already exists
            $check_stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
            $check_stmt->bind_param("s", $username);
            $check_stmt->execute();
            $check_stmt->bind_result($count);
            $check_stmt->fetch();
            $check_stmt->close();

            if ($count > 0) {
                $error = "Username already taken.";
            } else {
                $stmt = $conn->prepare("INSERT INTO users (username, password, email, profile_picture, banner_art) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssss", $username, $password, $email, $profile_picture, $banner_art);

                if ($stmt->execute()) {
                    header("Location: login.php");
                } else {
                    $error = "Error: " . $stmt->error;
                }

                $stmt->close();
            }
        }
    }
}

$conn->close();

include 'all.php';
?>






<!DOCTYPE html><html lang="en"><head>
<link rel="stylesheet" type="text/css" href="css/banner-styles.css">

  <meta charset="utf-8">
  <title>Sign Up - SigmaVid</title>
  <link rel="icon" type="image/ico" href="favicon.ico">
  
  
            <script src="https://www.google.com/recaptcha/api.js" async defer></script>

<style type="text/css">
  html, body, div, h1, h2, h3, h4, h5, h6, p, img, dl,
  dt, dd, ol, ul, li, table, tr, td, form, object, embed,
  article, aside, canvas, command, details, fieldset,
  figcaption, figure, footer, group, header, hgroup, legend,
  mark, menu, meter, nav, output, progress, section, summary,
  time, audio, video {
  margin: 0;
  padding: 0;
  border: 0;
  }
  article, aside, details, figcaption, figure, footer,
  header, hgroup, menu, nav, section {
  display: block;
  }
  html {
  font: 81.25% arial, helvetica, sans-serif;
  background: #fff;
  color: #333;
  line-height: 1;
  direction: ltr;
  }
  a {
  color: #15c;
  text-decoration: none;
  }
  a:active {
  color: #d14836;
  }
  a:hover {
  text-decoration: underline;
  }
  h1, h2, h3, h4, h5, h6 {
  color: #222;
  font-size: 1.54em;
  font-weight: normal;
  line-height: 24px;
  margin: 0 0 .46em;
  }
  p {
  line-height: 17px;
  margin: 0 0 1em;
  }
  ol, ul {
  list-style: none;
  line-height: 17px;
  margin: 0 0 1em;
  }
  li {
  margin: 0 0 .5em;
  }
  table {
  border-collapse: collapse;
  border-spacing: 0;
  }
  strong {
  color: #222;
  }
</style>
<style type="text/css">
  html, body {
  position: absolute;
  height: 100%;
  min-width: 100%;
  }
  .wrapper {
  position: relative;
  min-height: 100%;
  }
  .wrapper + style + iframe {
  display: none;
  }
  .content {
  padding: 0 44px;
  }
  .topbar {
  text-align: right;
  padding-top: .5em;
  padding-bottom: .5em;
  }
  .nugg3t-header-bar {
  height: 71px;
  background: #f1f1f1;
  border-bottom: 1px solid #e5e5e5;
  overflow: hidden;
  }
  .header .logo {
  margin: 17px 0 0;
  float: left;
  }
  .header .signin,
  .header .signup {
  margin: 28px 0 0;
  float: right;
  font-weight: bold;
  }
  .header .signin-button,
  .header .signup-button {
  margin: 22px 0 0;
  float: right;
  }
  .header .signin-button a {
  font-size: 13px;
  font-weight: normal;
  }
  .header .signup-button a {
  position: relative;
  top: -1px;
  margin: 0 0 0 1em;
  }
  .main {
  margin: 0 auto;
  width: 650px;
  padding-top: 23px;
  padding-bottom: 100px;
  }
  .main h1:first-child {
  margin: 0 0 .92em;
  }
  .nugg3t-footer-bar {
  position: absolute;
  bottom: 0;
  height: 35px;
  width: 100%;
  border-top: 1px solid #ebebeb;
  overflow: hidden;
  }
  .footer {
  padding-top: 9px;
  font-size: .85em;
  white-space: nowrap;
  line-height: 0;
  }
  .footer ul {
  color: #999;
  float: left;
  max-width: 80%;
  }
  .footer ul li {
  display: inline;
  padding: 0 1.5em 0 0;
  }
  .footer a {
  color: #333;
  }
  .footer .lang-chooser-wrap {
  float: right;
  max-width: 20%;
  }
  .footer .lang-chooser-wrap img {
  vertical-align: middle;
  }
  .footer .attribution {
  float: right;
  }
  .footer .attribution span {
  vertical-align: text-top;
  }
  .redtext {
  color: #dd4b39;
  }
  .greytext {
  color: #555;
  }
  .secondary {
  font-size: 11px;
  color: #666;
  }
  .source {
  color: #093;
  }
  .hidden {
  display: none;
  }
  .announce-bar {
  position: absolute;
  bottom: 35px;
  height: 33px;
  z-index: 2;
  width: 100%;
  background: #f9edbe;
  border-top: 1px solid #efe1ac;
  border-bottom: 1px solid #efe1ac;
  overflow: hidden;
  }
  .announce-bar .message {
  font-size: .85em;
  line-height: 33px;
  margin: 0;
  }
  .announce-bar .message .separated {
  margin-left: 1.5em;
  }
  .announce-bar-ac {
  background: #eee;
  border-top: 1px solid #e5e5e5;
  border-bottom: 1px solid #e5e5e5;
  }
  .clearfix:after {
  visibility: hidden;
  display: block;
  font-size: 0;
  content: '.';
  clear: both;
  height: 0;
  }
  * html .clearfix {
  zoom: 1;
  }
  *:first-child+html .clearfix {
  zoom: 1;
  }
  pre {
  font-family: monospace;
  position: absolute;
  left: 0;
  margin: 0;
  padding: 1.5em;
  font-size: 13px;
  background: #f1f1f1;
  border-top: 1px solid #e5e5e5;
  direction: ltr;
  }
</style>
<style type="text/css">
  button, input, select, textarea {
  font-family: inherit;
  font-size: inherit;
  }
  button::-moz-focus-inner,
  input::-moz-focus-inner {
  border: 0;
  }
  input[type=email],
  input[type=number],
  input[type=password],
  input[type=tel],
  input[type=text],
  input[type=url] {
  -webkit-appearance: none;
  appearance: none;
  display: inline-block;
  height: 29px;
  margin: 0;
  padding: 0 8px;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-border-radius: 1px;
  -moz-border-radius: 1px;
  border-radius: 1px;
  }
  input[type=email]:hover,
  input[type=number]:hover,
  input[type=password]:hover,
  input[type=tel]:hover,
  input[type=text]:hover,
  input[type=url]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  input[type=email]:focus,
  input[type=number]:focus,
  input[type=password]:focus,
  input[type=tel]:focus,
  input[type=text]:focus,
  input[type=url]:focus {
  outline: none;
  border: 1px solid #4d90fe;
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  input[type=email][disabled=disabled],
  input[type=number][disabled=disabled],
  input[type=password][disabled=disabled],
  input[type=tel][disabled=disabled],
  input[type=text][disabled=disabled],
  input[type=url][disabled=disabled] {
  border: 1px solid #e5e5e5;
  background: #f1f1f1;
  }
  input[type=email][disabled=disabled]:hover,
  input[type=number][disabled=disabled]:hover,
  input[type=password][disabled=disabled]:hover,
  input[type=tel][disabled=disabled]:hover,
  input[type=text][disabled=disabled]:hover,
  input[type=url][disabled=disabled]:hover {
  -webkit-box-shadow: none;
  -moz-box-shadow: none;
  box-shadow: none;
  }
  input[type=email][readonly=readonly],
  input[type=number][readonly=readonly],
  input[type=password][readonly=readonly],
  input[type=text][readonly=readonly],
  input[type=url][readonly=readonly] {
  border: 1px solid #d9d9d9;
  }
  input[type=email][readonly=readonly]:hover,
  input[type=number][readonly=readonly]:hover,
  input[type=password][readonly=readonly]:hover,
  input[type=text][readonly=readonly]:hover,
  input[type=url][readonly=readonly]:hover,
  input[type=email][readonly=readonly]:focus,
  input[type=number][readonly=readonly]:focus,
  input[type=password][readonly=readonly]:focus,
  input[type=text][readonly=readonly]:focus,
  input[type=url][readonly=readonly]:focus {
  -webkit-box-shadow: none;
  -moz-box-shadow: none;
  box-shadow: none;
  }
  input[type=checkbox].form-error,
  input[type=email].form-error,
  input[type=number].form-error,
  input[type=password].form-error,
  input[type=text].form-error,
  input[type=tel].form-error,
  input[type=url].form-error {
  border: 1px solid #dd4b39;
  }
  input[type=checkbox],
  input[type=radio] {
  -webkit-appearance: none;
  appearance: none;
  width: 13px;
  height: 13px;
  margin: 0;
  cursor: pointer;
  vertical-align: bottom;
  background: #fff;
  border: 1px solid #dcdcdc;
  -webkit-border-radius: 1px;
  -moz-border-radius: 1px;
  border-radius: 1px;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  position: relative;
  }
  input[type=checkbox]:active,
  input[type=radio]:active {
  border-color: #c6c6c6;
  background: #ebebeb;
  }
  input[type=checkbox]:hover {
  border-color: #c6c6c6;
  -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,0.1);
  -moz-box-shadow: inset 0 1px 1px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 1px rgba(0,0,0,0.1);
  }
  input[type=radio] {
  -webkit-border-radius: 1em;
  -moz-border-radius: 1em;
  border-radius: 1em;
  width: 15px;
  height: 15px;
  }
  input[type=checkbox]:checked,
  input[type=radio]:checked {
  background: #fff;
  }
  input[type=radio]:checked::after {
  content: '';
  display: block;
  position: relative;
  top: 3px;
  left: 3px;
  width: 7px;
  height: 7px;
  background: #666;
  -webkit-border-radius: 1em;
  -moz-border-radius: 1em;
  border-radius: 1em;
  }
  input[type=checkbox]:checked::after {
  content: url(images/checkmark.png);
  display: block;
  position: absolute;
  top: -6px;
  left: -5px;
  }
  input[type=checkbox]:focus {
  outline: none;
  border-color:#4d90fe;
  }
  .gaia-country-menu-item-flag, .gaia-country-menu-item-noflag {
  width: 16px;
  height: 11px;
  margin-right: 1em;
  }
  .gaia-country-menu-item-flag {
  background: no-repeat url(images/flags4.png) 0 0;
  overflow: hidden;
  }
  .g-button {
  display: inline-block;
  min-width: 46px;
  text-align: center;
  color: #444;
  font-size: 11px;
  font-weight: bold;
  height: 27px;
  padding: 0 8px;
  line-height: 27px;
  -webkit-border-radius: 2px;
  -moz-border-radius: 2px;
  border-radius: 2px;
  -webkit-transition: all 0.218s;
  -moz-transition: all 0.218s;
  -ms-transition: all 0.218s;
  -o-transition: all 0.218s;
  transition: all 0.218s;
  border: 1px solid #dcdcdc;
  background-color: #f5f5f5;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#f1f1f1));
  background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -o-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: linear-gradient(top,#f5f5f5,#f1f1f1);
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
  cursor: default;
  }
  *+html .g-button {
  min-width: 70px;
  }
  button.g-button,
  input[type=submit].g-button {
  height: 29px;
  line-height: 29px;
  vertical-align: bottom;
  margin: 0;
  }
  *+html button.g-button,
  *+html input[type=submit].g-button {
  overflow: visible;
  }
  .g-button:hover {
  border: 1px solid #c6c6c6;
  color: #333;
  text-decoration: none;
  -webkit-transition: all 0.0s;
  -moz-transition: all 0.0s;
  -ms-transition: all 0.0s;
  -o-transition: all 0.0s;
  transition: all 0.0s;
  background-color: #f8f8f8;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#f8f8f8),to(#f1f1f1));
  background-image: -webkit-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -o-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: linear-gradient(top,#f8f8f8,#f1f1f1);
  -webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  -moz-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  }
  .g-button:active {
  background-color: #f6f6f6;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#f6f6f6),to(#f1f1f1));
  background-image: -webkit-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -o-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: linear-gradient(top,#f6f6f6,#f1f1f1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  .g-button:visited {
  color: #666;
  }
  .g-button-submit {
  border: 1px solid #3079ed;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #4d90fe;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#4d90fe),to(#4787ed));
  background-image: -webkit-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -moz-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -ms-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -o-linear-gradient(top,#4d90fe,#4787ed);
  background-image: linear-gradient(top,#4d90fe,#4787ed);
  }
  .g-button-submit:hover {
  border: 1px solid #2f5bb7;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#4d90fe),to(#357ae8));
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);
  }
  .g-button-submit:active {
  background-color: #357ae8;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#4d90fe),to(#357ae8));
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);
  -webkit-box-shadow: inset 0 1px 2px rgb	a(0,0,0,0.3);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  .g-button-share {
  border: 1px solid #29691d;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #3d9400;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#3d9400),to(#398a00));
  background-image: -webkit-linear-gradient(top,#3d9400,#398a00);
  background-image: -moz-linear-gradient(top,#3d9400,#398a00);
  background-image: -ms-linear-gradient(top,#3d9400,#398a00);
  background-image: -o-linear-gradient(top,#3d9400,#398a00);
  background-image: linear-gradient(top,#3d9400,#398a00);
  }
  .g-button-share:hover {
  border: 1px solid #2d6200;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #368200;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#3d9400),to(#368200));
  background-image: -webkit-linear-gradient(top,#3d9400,#368200);
  background-image: -moz-linear-gradient(top,#3d9400,#368200);
  background-image: -ms-linear-gradient(top,#3d9400,#368200);
  background-image: -o-linear-gradient(top,#3d9400,#368200);
  background-image: linear-gradient(top,#3d9400,#368200);
  }
  .g-button-share:active {
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  .g-button-red {
  border: 1px solid transparent;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  text-transform: uppercase;
  background-color: #d14836;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#dd4b39),to(#d14836));
  background-image: -webkit-linear-gradient(top,#dd4b39,#d14836);
  background-image: -moz-linear-gradient(top,#dd4b39,#d14836);
  background-image: -ms-linear-gradient(top,#dd4b39,#d14836);
  background-image: -o-linear-gradient(top,#dd4b39,#d14836);
  background-image: linear-gradient(top,#dd4b39,#d14836);
  }
  .g-button-red:hover {
  border: 1px solid #b0281a;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #c53727;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#dd4b39),to(#c53727));
  background-image: -webkit-linear-gradient(top,#dd4b39,#c53727);
  background-image: -moz-linear-gradient(top,#dd4b39,#c53727);
  background-image: -ms-linear-gradient(top,#dd4b39,#c53727);
  background-image: -o-linear-gradient(top,#dd4b39,#c53727);
  background-image: linear-gradient(top,#dd4b39,#c53727);
  -webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.2);
  -moz-box-shadow: 0 1px 1px rgba(0,0,0,0.2);
  -ms-box-shadow: 0 1px 1px rgba(0,0,0,0.2);
  -o-box-shadow: 0 1px 1px rgba(0,0,0,0.2);
  box-shadow: 0 1px 1px rgba(0,0,0,0.2);
  }
  .g-button-red:active {
  border: 1px solid #992a1b;
  background-color: #b0281a;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#dd4b39),to(#b0281a));
  background-image: -webkit-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -moz-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -ms-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -o-linear-gradient(top,#dd4b39,#b0281a);
  background-image: linear-gradient(top,#dd4b39,#b0281a);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  color: #fff
  }
  .g-button-white {
  border: 1px solid #dcdcdc;
  color: #666;
  background: #fff;
  }
  .g-button-white:hover {
  border: 1px solid #c6c6c6;
  color: #333;
  background: #fff;
  -webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  -moz-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  }
  .g-button-white:active {
  background: #fff;
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  .g-button-red:visited,
  .g-button-share:visited,
  .g-button-submit:visited {
  color: #fff;
  }
  .g-button-submit:focus,
  .g-button-share:focus,
  .g-button-red:focus {
  -webkit-box-shadow: inset 0 0 0 1px #fff;
  -moz-box-shadow: inset 0 0 0 1px #fff;
  box-shadow: inset 0 0 0 1px #fff;
  }
  .g-button-share:focus {
  border-color: #29691d;
  }
  .g-button-red:focus {
  border-color: #d14836;
  }
  .g-button-submit:focus:hover,
  .g-button-share:focus:hover,
  .g-button-red:focus:hover {
  -webkit-box-shadow: inset 0 0 0 1px #fff, 0 1px 1px rgba(0,0,0,0.1);
  -moz-box-shadow: inset 0 0 0 1px #fff, 0 1px 1px rgba(0,0,0,0.1);
  box-shadow: inset 0 0 0 1px #fff, 0 1px 1px rgba(0,0,0,0.1);
  }
  .g-button.selected {
  background-color: #eee;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#eee),to(#e0e0e0));
  background-image: -webkit-linear-gradient(top,#eee,#e0e0e0);
  background-image: -moz-linear-gradient(top,#eee,#e0e0e0);
  background-image: -ms-linear-gradient(top,#eee,#e0e0e0);
  background-image: -o-linear-gradient(top,#eee,#e0e0e0);
  background-image: linear-gradient(top,#eee,#e0e0e0);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  border: 1px solid #ccc;
  color: #333;
  }
  .g-button img {
  display: inline-block;
  margin: -3px 0 0;
  opacity: .55;
  filter: alpha(opacity=55);
  vertical-align: middle;
  pointer-events: none;
  }
  *+html .g-button img {
  margin: 4px 0 0;
  }
  .g-button:hover img {
  opacity: .72;
  filter: alpha(opacity=72);
  }
  .g-button:active img {
  opacity: 1;
  filter: alpha(opacity=100);
  }
  .g-button.disabled img {
  opacity: .5;
  filter: alpha(opacity=50);
  }
  .g-button.disabled,
  .g-button.disabled:hover,
  .g-button.disabled:active,
  .g-button-submit.disabled,
  .g-button-submit.disabled:hover,
  .g-button-submit.disabled:active,
  .g-button-share.disabled,
  .g-button-share.disabled:hover,
  .g-button-share.disabled:active,
  .g-button-red.disabled,
  .g-button-red.disabled:hover,
  .g-button-red.disabled:active,
  input[type=submit][disabled].g-button {
  background-color: none;
  opacity: .5;
  filter: alpha(opacity=50);
  cursor: default;
  pointer-events: none;
  }
  .goog-menu {
  -webkit-box-shadow: 0 2px 4px rgba(0,0,0,0.2);
  -moz-box-shadow: 0 2px 4px rgba(0,0,0,0.2);
  box-shadow: 0 2px 4px rgba(0,0,0,0.2);
  -webkit-transition: opacity 0.218s;
  -moz-transition: opacity 0.218s;
  -ms-transition: opacity 0.218s;
  -o-transition: opacity 0.218s;
  transition: opacity 0.218s;
  background: #fff;
  border: 1px solid #ccc;
  border: 1px solid rgba(0,0,0,.2);
  cursor: default;
  font-size: 13px;
  margin: 0;
  outline: none;
  padding: 0 0 6px;
  position: absolute;
  z-index: 1000;
  overflow: auto;
  }
  .goog-menuitem,
  .goog-tristatemenuitem,
  .goog-filterobsmenuitem {
  position: relative;
  color: #333;
  cursor: pointer;
  list-style: none;
  margin: 0;
  padding: 6px 7em 6px 30px;
  white-space: nowrap;
  }
  .goog-menuitem-highlight,
  .goog-menuitem-hover {
  background-color: #eee;
  border-color: #eee;
  border-style: dotted;
  border-width: 1px 0;
  padding-top: 5px;
  padding-bottom: 5px;
  }
  .goog-menuitem-highlight .goog-menuitem-content,
  .goog-menuitem-hover .goog-menuitem-content {
  color: #333;
  }
  .goog-menuseparator {
  border-top: 1px solid #ebebeb;
  margin-top: 9px;
  margin-bottom: 10px;
  }
  .goog-inline-block {
  position: relative;
  display: -moz-inline-box;
  display: inline-block;
  }
  * html .goog-inline-block {
  display: inline;
  }
  *:first-child+html .goog-inline-block {
  display: inline;
  }
  .dropdown-block {
  display: block;
  }
  .goog-flat-menu-button {
  -webkit-border-radius: 2px;
  -moz-border-radius: 2px;
  border-radius: 2px;
  background-color: #f5f5f5;
  background-image: -webkit-gradient(linear,left top,left bottom,from(#f5f5f5),to(#f1f1f1));
  background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -o-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: linear-gradient(top,#f5f5f5,#f1f1f1);
  border: 1px solid #dcdcdc;
  color: #444;
  font-size: 11px;
  font-weight: bold;
  line-height: 27px;
  list-style: none;
  margin: 0 2px;
  min-width: 46px;
  outline: none;
  padding: 0 18px 0 6px;
  text-decoration: none;
  vertical-align: middle;
  }
  .goog-flat-menu-button-disabled {
  background-color: #fff;
  border-color: #f3f3f3;
  color: #b8b8b8;
  cursor: default;
  }
  .goog-flat-menu-button.goog-flat-menu-button-hover {
  background-color: #f8f8f8;
  background-image: -webkit-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -o-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: linear-gradient(top,#f8f8f8,#f1f1f1);
  -webkit-box-shadow: 0 1px 1px rgba(0,0,0,.1);
  -moz-box-shadow: 0 1px 1px rgba(0,0,0,.1);
  box-shadow: 0 1px 1px rgba(0,0,0,.1);
  border-color: #c6c6c6;
  color: #333;
  }
  .goog-flat-menu-button.goog-flat-menu-button-focused {
  border-color: #4d90fe;
  }
  .form-error .goog-flat-menu-button {
  border: 1px solid #dd4b39;
  }
  .form-error .goog-flat-menu-button-focused {
  border-color: #4d90fe;
  }
  .goog-flat-menu-button.goog-flat-menu-button-open,
  .goog-flat-menu-button.goog-flat-menu-button-active {
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,.1);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,.1);
  background-color: #eee;
  background-image: -webkit-linear-gradient(top,#eee,#e0e0e0);
  background-image: -moz-linear-gradient(top,#eee,#e0e0e0);
  background-image: -ms-linear-gradient(top,#eee,#e0e0e0);
  background-image: -o-linear-gradient(top,#eee,#e0e0e0);
  background-image: linear-gradient(top,#eee,#e0e0e0);
  border: 1px solid #ccc;
  color: #333;
  z-index: 2;
  }
  .goog-flat-menu-button-caption {
  cursor: default;
  vertical-align: top;
  white-space: nowrap;
  }
  .goog-flat-menu-button-dropdown {
  border-color: #777 transparent;
  border-style: solid;
  border-width: 4px 4px 0;
  height: 0;
  width: 0;
  position: absolute;
  right: 5px;
  top: 12px;
  }
  .jfk-select .goog-flat-menu-button-dropdown {
  background: url(images/grey-disclosure-arrow-up-down.png) center no-repeat;
  border: none;
  height: 11px;
  margin-top: -4px;
  width: 7px;
  }
  .goog-menu-nocheckbox .goog-menuitem,
  .goog-menu-noicon .goog-menuitem {
  padding-left: 16px;
  vertical-align: middle;
  }
  body ::-webkit-scrollbar {
  height: 16px;
  width: 16px;
  overflow: visible;
  }
  body ::-webkit-scrollbar-button {
  height: 0;
  width: 0;
  }
  body ::-webkit-scrollbar-track {
  background-clip: padding-box;
  border: solid transparent;
  border-width: 0 0 0 7px;
  }
  body ::-webkit-scrollbar-track:horizontal {
  border-width: 7px 0 0;
  }
  body ::-webkit-scrollbar-track:hover {
  background-color: rgba(0,0,0,.05);
  -webkit-box-shadow: inset 1px 0 0 rgba(0,0,0,.1);
  box-shadow: inset 1px 0 0 rgba(0,0,0,.1);
  }
  body ::-webkit-scrollbar-track:horizontal:hover {
  -webkit-box-shadow: inset 0 1px 0 rgba(0,0,0,.1);
  box-shadow: inset 0 1px 0 rgba(0,0,0,.1);
  }
  body ::-webkit-scrollbar-track:active {
  background-color: rgba(0,0,0,.05);
  -webkit-box-shadow: inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07);
  box-shadow: inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07);
  }
  body ::-webkit-scrollbar-track:horizontal:active {
  -webkit-box-shadow: inset 0 1px 0 rgba(0,0,0,.14),inset 0 -1px 0 rgba(0,0,0,.07);
  box-shadow: inset 0 1px 0 rgba(0,0,0,.14),inset 0 -1px 0 rgba(0,0,0,.07);
  }
  .jfk-scrollbar-dark::-webkit-scrollbar-track:hover {
  background-color: rgba(255,255,255,.1);
  -webkit-box-shadow: inset 1px 0 0 rgba(255,255,255,.2);
  box-shadow: inset 1px 0 0 rgba(255,255,255,.2);
  }
  .jfk-scrollbar-dark::-webkit-scrollbar-track:horizontal:hover {
  -webkit-box-shadow: inset 0 1px 0 rgba(255,255,255,.2);
  box-shadow: inset 0 1px 0 rgba(255,255,255,.2);
  }
  .jfk-scrollbar-dark::-webkit-scrollbar-track:active {
  background-color: rgba(255,255,255,.1);
  -webkit-box-shadow: inset 1px 0 0 rgba(255,255,255,.25),inset -1px 0 0 rgba(255,255,255,.15);
  box-shadow: inset 1px 0 0 rgba(255,255,255,.25),inset -1px 0 0 rgba(255,255,255,.15);
  }
  .jfk-scrollbar-dark::-webkit-scrollbar-track:horizontal:active {
  -webkit-box-shadow: inset 0 1px 0 rgba(255,255,255,.25),inset 0 -1px 0 rgba(255,255,255,.15);
  box-shadow: inset 0 1px 0 rgba(255,255,255,.25),inset 0 -1px 0 rgba(255,255,255,.15);
  }
  body ::-webkit-scrollbar-thumb {
  background-color: rgba(0,0,0,.2);
  background-clip: padding-box;
  border: solid transparent;
  border-width: 0 0 0 7px;
  min-height: 28px;
  padding: 100px 0 0;
  -webkit-box-shadow: inset 1px 1px 0 rgba(0,0,0,.1),inset 0 -1px 0 rgba(0,0,0,.07);
  box-shadow: inset 1px 1px 0 rgba(0,0,0,.1),inset 0 -1px 0 rgba(0,0,0,.07);
  }
  body ::-webkit-scrollbar-thumb:horizontal {
  border-width: 7px 0 0;
  padding: 0 0 0 100px;
  -webkit-box-shadow: inset 1px 1px 0 rgba(0,0,0,.1),inset -1px 0 0 rgba(0,0,0,.07);
  box-shadow: inset 1px 1px 0 rgba(0,0,0,.1),inset -1px 0 0 rgba(0,0,0,.07);
  }
  body ::-webkit-scrollbar-thumb:hover {
  background-color: rgba(0,0,0,.4);
  -webkit-box-shadow: inset 1px 1px 1px rgba(0,0,0,.25);
  box-shadow: inset 1px 1px 1px rgba(0,0,0,.25);
  }
  body ::-webkit-scrollbar-thumb:active {
  background-color: rgba(0,0,0,.5);
  -webkit-box-shadow: inset 1px 1px 3px rgba(0,0,0,.35);
  box-shadow: inset 1px 1px 3px rgba(0,0,0,.35);
  }
  .jfk-scrollbar-dark::-webkit-scrollbar-thumb {
  background-color: rgba(255,255,255,.3);
  -webkit-box-shadow: inset 1px 1px 0 rgba(255,255,255,.15),inset 0 -1px 0 rgba(255,255,255,.1);
  box-shadow: inset 1px 1px 0 rgba(255,255,255,.15),inset 0 -1px 0 rgba(255,255,255,.1);
  }
  .jfk-scrollbar-dark::-webkit-scrollbar-thumb:horizontal {
  -webkit-box-shadow: inset 1px 1px 0 rgba(255,255,255,.15),inset -1px 0 0 rgba(255,255,255,.1);
  box-shadow: inset 1px 1px 0 rgba(255,255,255,.15),inset -1px 0 0 rgba(255,255,255,.1);
  }
  .jfk-scrollbar-dark::-webkit-scrollbar-thumb:hover {
  background-color: rgba(255,255,255,.6);
  -webkit-box-shadow: inset 1px 1px 1px rgba(255,255,255,.37);
  box-shadow: inset 1px 1px 1px rgba(255,255,255,.37);
  }
  .jfk-scrollbar-dark::-webkit-scrollbar-thumb:active {
  background-color: rgba(255,255,255,.75);
  -webkit-box-shadow: inset 1px 1px 3px rgba(255,255,255,.5);
  box-shadow: inset 1px 1px 3px rgba(255,255,255,.5);
  }
  .jfk-scrollbar-borderless::-webkit-scrollbar-track {
  border-width: 0 1px 0 6px
  }
  .jfk-scrollbar-borderless::-webkit-scrollbar-track:horizontal {
  border-width: 6px 0 1px
  }
  .jfk-scrollbar-borderless::-webkit-scrollbar-track:hover {
  background-color: rgba(0,0,0,.035);
  -webkit-box-shadow: inset 1px 1px 0 rgba(0,0,0,.14),inset -1px -1px 0 rgba(0,0,0,.07);
  box-shadow: inset 1px 1px 0 rgba(0,0,0,.14),inset -1px -1px 0 rgba(0,0,0,.07);
  }
  .jfk-scrollbar-borderless.jfk-scrollbar-dark::-webkit-scrollbar-track:hover {
  background-color: rgba(255,255,255,.07);
  -webkit-box-shadow: inset 1px 1px 0 rgba(255,255,255,.25),inset -1px -1px 0 rgba(255,255,255,.15);
  box-shadow: inset 1px 1px 0 rgba(255,255,255,.25),inset -1px -1px 0 rgba(255,255,255,.15);
  }
  .jfk-scrollbar-borderless::-webkit-scrollbar-thumb {
  border-width: 0 1px 0 6px;
  }
  .jfk-scrollbar-borderless::-webkit-scrollbar-thumb:horizontal {
  border-width: 6px 0 1px;
  }
  body ::-webkit-scrollbar-corner {
  background: transparent;
  }
  body::-webkit-scrollbar-track-piece {
  background-clip: padding-box;
  background-color: #f1f1f1;
  border: solid #fff;
  border-width: 0 0 0 3px;
  -webkit-box-shadow: inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07);
  box-shadow: inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07);
  }
  body::-webkit-scrollbar-track-piece:horizontal {
  border-width: 3px 0 0;
  -webkit-box-shadow: inset 0 1px 0 rgba(0,0,0,.14),inset 0 -1px 0 rgba(0,0,0,.07);
  box-shadow: inset 0 1px 0 rgba(0,0,0,.14),inset 0 -1px 0 rgba(0,0,0,.07);
  }
  body::-webkit-scrollbar-thumb {
  border-width: 1px 1px 1px 5px;
  }
  body::-webkit-scrollbar-thumb:horizontal {
  border-width: 5px 1px 1px;
  }
  body::-webkit-scrollbar-corner {
  background-clip: padding-box;
  background-color: #f1f1f1;
  border: solid #fff;
  border-width: 3px 0 0 3px;
  -webkit-box-shadow: inset 1px 1px 0 rgba(0,0,0,.14);
  box-shadow: inset 1px 1px 0 rgba(0,0,0,.14);
  }
  .jfk-scrollbar::-webkit-scrollbar {
  height: 16px;
  overflow: visible;
  width: 16px;
  }
  .jfk-scrollbar::-webkit-scrollbar-button {
  height: 0;
  width: 0;
  }
  .jfk-scrollbar::-webkit-scrollbar-track {
  background-clip: padding-box;
  border: solid transparent;
  border-width: 0 0 0 7px;
  }
  .jfk-scrollbar::-webkit-scrollbar-track:horizontal {
  border-width: 7px 0 0;
  }
  .jfk-scrollbar::-webkit-scrollbar-track:hover {
  background-color: rgba(0,0,0,.05);
  -webkit-box-shadow: inset 1px 0 0 rgba(0,0,0,.1);
  box-shadow: inset 1px 0 0 rgba(0,0,0,.1);
  }
  .jfk-scrollbar::-webkit-scrollbar-track:horizontal:hover {
  -webkit-box-shadow: inset 0 1px 0 rgba(0,0,0,.1);
  box-shadow: inset 0 1px 0 rgba(0,0,0,.1);
  }
  .jfk-scrollbar::-webkit-scrollbar-track:active {
  background-color: rgba(0,0,0,.05);
  -webkit-box-shadow: inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07);
  box-shadow: inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07);
  }
  .jfk-scrollbar::-webkit-scrollbar-track:horizontal:active {
  -webkit-box-shadow: inset 0 1px 0 rgba(0,0,0,.14),inset 0 -1px 0 rgba(0,0,0,.07);
  box-shadow: inset 0 1px 0 rgba(0,0,0,.14),inset 0 -1px 0 rgba(0,0,0,.07);
  }
  .jfk-scrollbar-dark.jfk-scrollbar::-webkit-scrollbar-track:hover {
  background-color: rgba(255,255,255,.1);
  -webkit-box-shadow: inset 1px 0 0 rgba(255,255,255,.2);
  box-shadow: inset 1px 0 0 rgba(255,255,255,.2);
  }
  .jfk-scrollbar-dark.jfk-scrollbar::-webkit-scrollbar-track:horizontal:hover {
  -webkit-box-shadow: inset 0 1px 0 rgba(255,255,255,.2);
  box-shadow: inset 0 1px 0 rgba(255,255,255,.2);
  }
  .jfk-scrollbar-dark.jfk-scrollbar::-webkit-scrollbar-track:active {
  background-color: rgba(255,255,255,.1);
  -webkit-box-shadow: inset 1px 0 0 rgba(255,255,255,.25),inset -1px 0 0 rgba(255,255,255,.15);
  box-shadow: inset 1px 0 0 rgba(255,255,255,.25),inset -1px 0 0 rgba(255,255,255,.15);
  }
  .jfk-scrollbar-dark.jfk-scrollbar::-webkit-scrollbar-track:horizontal:active {
  -webkit-box-shadow: inset 0 1px 0 rgba(255,255,255,.25),inset 0 -1px 0 rgba(255,255,255,.15);
  box-shadow: inset 0 1px 0 rgba(255,255,255,.25),inset 0 -1px 0 rgba(255,255,255,.15);
  }
  .jfk-scrollbar::-webkit-scrollbar-thumb {
  background-color: rgba(0,0,0,.2);
  background-clip: padding-box;
  border: solid transparent;
  border-width: 0 0 0 7px;
  min-height: 28px;
  padding: 100px 0 0;
  -webkit-box-shadow: inset 1px 1px 0 rgba(0,0,0,.1),inset 0 -1px 0 rgba(0,0,0,.07);
  box-shadow: inset 1px 1px 0 rgba(0,0,0,.1),inset 0 -1px 0 rgba(0,0,0,.07);
  }
  .jfk-scrollbar::-webkit-scrollbar-thumb:horizontal {
  border-width: 7px 0 0;
  padding: 0 0 0 100px;
  -webkit-box-shadow: inset 1px 1px 0 rgba(0,0,0,.1),inset -1px 0 0 rgba(0,0,0,.07);
  box-shadow: inset 1px 1px 0 rgba(0,0,0,.1),inset -1px 0 0 rgba(0,0,0,.07);
  }
  .jfk-scrollbar::-webkit-scrollbar-thumb:hover {
  background-color: rgba(0,0,0,.4);
  -webkit-box-shadow: inset 1px 1px 1px rgba(0,0,0,.25);
  box-shadow: inset 1px 1px 1px rgba(0,0,0,.25);
  }
  .jfk-scrollbar::-webkit-scrollbar-thumb:active {
  background-color: rgba(0,0,0,0.5);
  -webkit-box-shadow: inset 1px 1px 3px rgba(0,0,0,0.35);
  box-shadow: inset 1px 1px 3px rgba(0,0,0,0.35);
  }
  .jfk-scrollbar-dark.jfk-scrollbar::-webkit-scrollbar-thumb {
  background-color: rgba(255,255,255,.3);
  -webkit-box-shadow: inset 1px 1px 0 rgba(255,255,255,.15),inset 0 -1px 0 rgba(255,255,255,.1);
  box-shadow: inset 1px 1px 0 rgba(255,255,255,.15),inset 0 -1px 0 rgba(255,255,255,.1);
  }
  .jfk-scrollbar-dark.jfk-scrollbar::-webkit-scrollbar-thumb:horizontal {
  -webkit-box-shadow: inset 1px 1px 0 rgba(255,255,255,.15),inset -1px 0 0 rgba(255,255,255,.1);
  box-shadow: inset 1px 1px 0 rgba(255,255,255,.15),inset -1px 0 0 rgba(255,255,255,.1);
  }
  .jfk-scrollbar-dark.jfk-scrollbar::-webkit-scrollbar-thumb:hover {
  background-color: rgba(255,255,255,.6);
  -webkit-box-shadow: inset 1px 1px 1px rgba(255,255,255,.37);
  box-shadow: inset 1px 1px 1px rgba(255,255,255,.37);
  }
  .jfk-scrollbar-dark.jfk-scrollbar::-webkit-scrollbar-thumb:active {
  background-color: rgba(255,255,255,.75);
  -webkit-box-shadow: inset 1px 1px 3px rgba(255,255,255,.5);
  box-shadow: inset 1px 1px 3px rgba(255,255,255,.5);
  }
  .jfk-scrollbar-borderless.jfk-scrollbar::-webkit-scrollbar-track {
  border-width: 0 1px 0 6px;
  }
  .jfk-scrollbar-borderless.jfk-scrollbar::-webkit-scrollbar-track:horizontal {
  border-width: 6px 0 1px;
  }
  .jfk-scrollbar-borderless.jfk-scrollbar::-webkit-scrollbar-track:hover {
  background-color: rgba(0,0,0,.035);
  -webkit-box-shadow: inset 1px 1px 0 rgba(0,0,0,.14),inset -1px -1px 0 rgba(0,0,0,.07);
  box-shadow: inset 1px 1px 0 rgba(0,0,0,.14),inset -1px -1px 0 rgba(0,0,0,.07);
  }
  .jfk-scrollbar-borderless.jfk-scrollbar-dark.jfk-scrollbar::-webkit-scrollbar-track:hover {
  background-color: rgba(255,255,255,.07);
  -webkit-box-shadow: inset 1px 1px 0 rgba(255,255,255,.25),inset -1px -1px 0 rgba(255,255,255,.15);
  box-shadow: inset 1px 1px 0 rgba(255,255,255,.25),inset -1px -1px 0 rgba(255,255,255,.15);
  }
  .jfk-scrollbar-borderless.jfk-scrollbar::-webkit-scrollbar-thumb {
  border-width: 0 1px 0 6px;
  }
  .jfk-scrollbar-borderless.jfk-scrollbar::-webkit-scrollbar-thumb:horizontal {
  border-width: 6px 0 1px;
  }
  .jfk-scrollbar::-webkit-scrollbar-corner {
  background: transparent;
  }
  body.jfk-scrollbar::-webkit-scrollbar-track-piece {
  background-clip: padding-box;
  background-color: #f1f1f1;
  border: solid #fff;
  border-width: 0 0 0 3px;
  -webkit-box-shadow: inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07);
  box-shadow: inset 1px 0 0 rgba(0,0,0,.14),inset -1px 0 0 rgba(0,0,0,.07);
  }
  body.jfk-scrollbar::-webkit-scrollbar-track-piece:horizontal {
  border-width: 3px 0 0;
  -webkit-box-shadow: inset 0 1px 0 rgba(0,0,0,.14),inset 0 -1px 0 rgba(0,0,0,.07);
  box-shadow: inset 0 1px 0 rgba(0,0,0,.14),inset 0 -1px 0 rgba(0,0,0,.07);
  }
  body.jfk-scrollbar::-webkit-scrollbar-thumb {
  border-width: 1px 1px 1px 5px;
  }
  body.jfk-scrollbar::-webkit-scrollbar-thumb:horizontal {
  border-width: 5px 1px 1px;
  }
  body.jfk-scrollbar::-webkit-scrollbar-corner {
  background-clip: padding-box;
  background-color: #f1f1f1;
  border: solid #fff;
  border-width: 3px 0 0 3px;
  -webkit-box-shadow: inset 1px 1px 0 rgba(0,0,0,.14);
  box-shadow: inset 1px 1px 0 rgba(0,0,0,.14);
  }
  .errormsg {
  margin: .5em 0 0;
  display: block;
  color: #dd4b39;
  line-height: 17px;
  }
  .help-link {
  background: #dd4b39;
  padding: 0 5px;
  color: #fff;
  font-weight: bold;
  display: inline-block;
  -webkit-border-radius: 1em;
  -moz-border-radius: 1em;
  border-radius: 1em;
  text-decoration: none;
  position: relative;
  top: 0px;
  }
  .help-link:visited {
  color: #fff;
  }
  .help-link:hover {
  color: #fff;
  background: #c03523;
  text-decoration: none;
  }
  .help-link:active {
  opacity: 1;
  background: #ae2817;
  }
</style>
<style type="text/css">
  .main {
  width: auto;
  max-width: 1000px;
  min-width: 780px;
  }
  .product-info {
  margin: 0 385px 0 0;
  }
  .product-info h3 {
  font-size: 1.23em;
  font-weight: normal;
  }
  .product-info a:visited {
  color: #61c;
  }
  .product-info .g-button:visited {
  color: #666;
  }
  .sign-in {
  width: 335px;
  float: right;
  }
  .signin-box,
  .accountchooser-box {
  margin: 12px 0 0;
  padding: 20px 25px 15px;
  background: #f1f1f1;
  border: 1px solid #e5e5e5;
  }
  .product-headers {
  margin: 0 0 1.5em;
  }
  .product-headers h1 {
  font-size: 25px;
  margin: 0 !important;
  }
  .product-headers h2 {
  font-size: 16px;
  margin: .4em 0 0;
  }
  .features {
  overflow: hidden;
  margin: 2em 0 0;
  }
  .features li {
  margin: 3px 0 2em;
  }
  .features img {
  float: left;
  margin: -3px 0 0;
  }
  .features p {
  margin: 0 0 0 68px;
  }
  .features .title {
  font-size: 16px;
  margin-bottom: .3em;
  }
  .features.no-icon p {
  margin: 0;
  }
  .features .small-title {
  font-size: 1em;
  font-weight: bold;
  }
  .notification-bar {
  background: #f9edbe;
  padding: 8px;
  }
</style>
<style type="text/css">
  .signin-box h2 {
  font-size: 16px;
  line-height: 17px;
  height: 16px;
  margin: 0 0 1.2em;
  position: relative;
  }
  .signin-box h2 strong {
  display: inline-block;
  position: absolute;
  right: 0;
  top: 1px;
  height: 19px;
  width: 52px;
  background: transparent url(images/dontsueme2.png) no-repeat;
  }
  @media only screen and (-webkit-device-pixel-ratio: 2){
  .signin-box h2 strong {
  background: transparent url(images/nugg3t-signin-flat_2x.png) no-repeat;
  background-size: 52px 19px;
  }
  }
  .signin-box div {
  margin: 0 0 1.5em;
  }
  .signin-box label {
  display: block;
  }
  .signin-box input[type=email],
  .signin-box input[type=text],
  .signin-box input[type=password] {
  width: 100%;
  height: 32px;
  font-size: 15px;
  direction: ltr;
  }
  .signin-box .email-label,
  .signin-box .passwd-label {
  font-weight: bold;
  margin: 0 0 .5em;
  display: block;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
  }
  .signin-box .reauth {
  display: inline-block;
  font-size: 15px;
  height: 29px;
  line-height: 29px;
  margin: 0;
  }
  .signin-box label.remember {
  display: inline-block;
  vertical-align: top;
  margin: 9px 0 0;
  }
  .signin-box .remember-label {
  font-weight: normal;
  color: #666;
  line-height: 0;
  padding: 0 0 0 .4em;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
  }
  .signin-box input[type=submit] {
  margin: 0 1.5em 1.2em 0;
  height: 32px;
  font-size: 13px;
  }
  .signin-box ul {
  margin: 0;
  }
  .signin-box .training-msg {
  padding: .5em 8px;
  background: #f9edbe;
  }
  .signin-box .training-msg p {
  margin: 0 0 .5em;
  }
</style>
  <style type="text/css">
.SigmaVid .product-headers h1 {
  text-indent: -9999em;
  width: 95px;
  height: 44px;
  background: #fff url(images/SigmaVid_logo.png) no-repeat 0 0;
}
.SigmaVid .features p {
  margin-left: 74px;
}
.SigmaVid .features li {
  min-height: 56px;
}
.SigmaVid .promo {
  border: 1px solid #ebebeb;
  padding: 10px 10px 0 10px;
  min-height: 70px;
}
.SigmaVid .promo img {
  float: left;
  margin-left: 5px;
  margin-right: 15px;
  margin-bottom: 15px;
}
.SigmaVid .promo h3 {
  font-size: 16px;
  margin-bottom: .3em;
}
.SigmaVid .promo p {
  margin-bottom: 10px;
}
.email-label span {
  color: #666;
  font-weight: normal;
}
</style>
  </head>
  
  <body>

  <div class="wrapper">
  <link rel="stylesheet" href="css/main.css">

    <?php include 'ticker.php'; ?>

<?php if ($ticker): ?>
	<div id="ticker" class="ytg-base "><div id="ticker-inner"><div style="margin-left:50px;" class="ytg-wide"><button onclick="yt.net.cookies.set('HideTicker', 1, 604800);" class="yt-uix-close" data-close-parent-id="ticker"><img alt="Close" src="//web.archive.org/web/20130301230851im_/http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif"></button><img class="ticker-icon" src="//web.archive.org/web/20130301230851im_/http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt=""><div class="ticker-content"><?php echo $ticker; ?></div></div></div></div>
<?php endif; ?>
  <div class="nugg3t-header-bar">
  <div class="header content clearfix">
  <img class="logo" src="images/dontsueme1.png" alt="nugg3t">
  <span class="signup-button">
  Already have an account?
  <a id="link-signup" class="g-button g-button-red" href="/login">
  Log in
  </a>
  </span>
  </div>
  </div>
  <div class="main content clearfix">
  <div class="sign-in">
<div class="signin-box">
  <h2>Sign up <strong></strong></h2>
  <form novalidate="" id="gaia_loginform" action="signup.php" method="post">
  <input type="hidden" name="service" id="service" value="SigmaVid">
  <input type="hidden" name="dsh" id="dsh" value="-7426504780160915373">
  <input type="hidden" name="GALX" value="g4ul70eJ6LU">
<input type="hidden" name="timeStmp" id="timeStmp" value="">
<input type="hidden" name="secTok" id="secTok" value="">
<input type="hidden" id="_utf8" name="_utf8" value="☃">
  <input type="hidden" name="bgresponse" id="bgresponse" value="js_disabled">
<div class="email-div">
  <label for="Username"><strong class="email-label">Username</strong></label>
  <input type="text" spellcheck="false" name="username" id="Username" value="">
</div>
<div class="email-div">
  <label for="Email"><strong class="email-label">Email</strong></label>
  <input type="email" spellcheck="false" name="email" id="Email" value="">
</div>
<div class="passwd-div">
  <label for="Passwd"><strong class="passwd-label">Password</strong></label>
  <input type="password" name="password" id="Passwd">
</div>
<div class="passwd-div">
  <label for="Verification"><strong class="passwd-label">Verification</strong></label>
  <div class="g-recaptcha" data-sitekey="6Le_PBMqAAAAANAtepZMGwnqmj5W_4aRCfinfmFO"></div><br>
</div>
  <?php if(isset($error)): ?>
  <p style="color:red;margin-bottom:15px;"><?php echo $error; ?></p>
  <?php endif; ?>

  <input type="submit" class="g-button g-button-submit" name="signIn" id="signIn" value="Sign up">
  <label class="remember" onclick="">
  </label>
  <input type="hidden" name="rmShown" value="1">
  </form>
  <ul>
  <li>
  <!--<a id="link-forgot-passwd" href="http://web.archive.org/web/20131012035920/http://www.SigmaVid.com/account_recovery" target="_top">
  Can't access your account?
  </a>-->
  </li>
  </ul>
</div>
  </div>
  <div class="product-info SigmaVid">
<div class="product-headers">
  <img src="images/sigmavid.png" width="95" height="44">
  <h2>Sign up now, join the least gay video platform!</h2>
</div>
  <ul class="features">
  <li>
  <img alt="" src="images/ytwarn.png">
  <p class="title">
  THIS WEBSITE IS NOT AFFILIATED WITH GOOGLE!
  </p>
  <p>
  If you are on this page because you think this is Google, please visit <a href="https://google.com">google.com</a>
  </p>
  </li>
  <li>
  <img alt="" src="images/ytfav.png">
  <p class="title">
  Keep up with your favorite channels
  </p>
  <p>
  Save videos to watch later, watch recommendations just for you, or subscribe to get updates from your favorite channels.
  </p>
  </li>
  <li>
  <img alt="" src="images/ytonzgo.png">
  <p class="title">
  Watch everywhere
  </p>
  <p>
  Take your picks with you wherever you go — watch on your smartphone, tablet, or smart TV.
  </p>
  </li>
  <li>
  <img alt="" src="images/ytwfrnz.png">
  <p class="title">
  Share with your friends
  </p>
  <p>
  See videos shared by your friends across all your social networks — all in one place.
  </p>
  </li>
</ul>
  </div>
  </div>
<div class="nugg3t-footer-bar">
  <div class="footer content clearfix">
  <ul>
  <li>© 2013 nugg3t</li>
  <li><a href="http://web.archive.org/web/20131012035920/https://accounts.nugg3t.com/TOS?hl=en" target="_blank">Terms of Service</a></li>
  <li><a href="http://web.archive.org/web/20131012035920/http://www.nugg3t.com/intl/en/privacy/" target="_blank">Privacy Policy</a></li>
  <li><a href="http://web.archive.org/web/20131012035920/http://www.nugg3t.com/support/accounts?hl=en" target="_blank">Help</a></li>
  </ul>
  <span id="lang-chooser-wrap" class="lang-chooser-wrap" style="">
  <img src="images/universal_language_settings-21.png">
  <select id="lang-chooser" class="lang-chooser">
  <option value="af">
  ‪Afrikaans‬
  </option>
  <option value="in">
  ‪Bahasa Indonesia‬
  </option>
  <option value="ms">
  ‪Bahasa Melayu‬
  </option>
  <option value="ca">
  ‪catal�&nbsp;‬
  </option>
  <option value="cs">
  ‪čeština‬
  </option>
  <option value="da">
  ‪dansk‬
  </option>
  <option value="de">
  ‪Deutsch‬
  </option>
  <option value="et">
  ‪eesti‬
  </option>
  <option value="en-GB">
  ‪English (United Kingdom)‬
  </option>
  <option value="en" selected="selected">
  ‪English (United States)‬
  </option>
  <option value="es">
  ‪español (España)‬
  </option>
  <option value="es-419">
  ‪español (Latinoamérica)‬
  </option>
  <option value="eu">
  ‪euskara‬
  </option>
  <option value="fil">
  ‪Filipino‬
  </option>
  <option value="fr-CA">
  ‪français (Canada)‬
  </option>
  <option value="fr">
  ‪français (France)‬
  </option>
  <option value="gl">
  ‪galego‬
  </option>
  <option value="hr">
  ‪hrvatski‬
  </option>
  <option value="zu">
  ‪isiZulu‬
  </option>
  <option value="is">
  ‪íslenska‬
  </option>
  <option value="it">
  ‪italiano‬
  </option>
  <option value="sw">
  ‪Kiswahili‬
  </option>
  <option value="lv">
  ‪latviešu‬
  </option>
  <option value="lt">
  ‪lietuvių‬
  </option>
  <option value="hu">
  ‪magyar‬
  </option>
  <option value="nl">
  ‪Nederlands‬
  </option>
  <option value="no">
  ‪norsk‬
  </option>
  <option value="pl">
  ‪polski‬
  </option>
  <option value="pt">
  ‪português‬
  </option>
  <option value="pt-BR">
  ‪português (Brasil)‬
  </option>
  <option value="pt-PT">
  ‪português (Portugal)‬
  </option>
  <option value="ro">
  ‪română‬
  </option>
  <option value="sk">
  ‪slovenčina‬
  </option>
  <option value="sl">
  ‪slovenščina‬
  </option>
  <option value="fi">
  ‪suomi‬
  </option>
  <option value="sv">
  ‪svenska‬
  </option>
  <option value="vi">
  ‪Tiếng Việt‬
  </option>
  <option value="tr">
  ‪Türkçe‬
  </option>
  <option value="el">
  ‪Ελληνικά‬
  </option>
  <option value="bg">
  ‪български‬
  </option>
  <option value="ru">
  ‪русский‬
  </option>
  <option value="sr">
  ‪Српски‬
  </option>
  <option value="uk">
  ‪українська‬
  </option>
  <option value="iw">
  ‫עברית‬‎
  </option>
  <option value="ur">
  ‫اردو‬‎
  </option>
  <option value="ar">
  ‫العربية‬‎
  </option>
  <option value="fa">
  ‫فارسی‬‎
  </option>
  <option value="am">
  ‪�&nbsp;ማርኛ‬
  </option>
  <option value="mr">
  ‪मरा�&nbsp;ी‬
  </option>
  <option value="hi">
  ‪हिन्दी‬
  </option>
  <option value="bn">
  ‪বাংলা‬
  </option>
  <option value="gu">
  ‪ગુજરાતી‬
  </option>
  <option value="ta">
  ‪தமிழ்‬
  </option>
  <option value="te">
  ‪తెలుగు‬
  </option>
  <option value="kn">
  ‪ಕನ್ನಡ‬
  </option>
  <option value="ml">
  ‪മലയാളം‬
  </option>
  <option value="th">
  ‪ไทย‬
  </option>
  <option value="ko">
  ‪한국어‬
  </option>
  <option value="zh-HK">
  ‪中文（香港）‬
  </option>
  <option value="ja">
  ‪日本語‬
  </option>
  <option value="zh-CN">
  ‪简体中文‬
  </option>
  <option value="zh-TW">
  ‪繁體中文‬
  </option>
  </select>
  </span>
  </div>
</div>
  <script type="text/javascript">/* Anti-spam. Want to say hello? Contact (base64) Ym90Z3VhcmQtY29udGFjdEBnb29nbGUuY29tCg== */(function(){eval('var g,h=true,l=null,p=false,q=this,u="",v=void 0,w=Array.prototype,aa=Date.now||function(){return+new Date},x=function(a){return(a=q.document)?a.documentMode:v},y=function(a,b,c,d,e){c=a.split("."),d=q,c[0]in d||!d.execScript||d.execScript("var "+c[0]);for(;c.length&&(e=c.shift());)c.length||b===v?d=d[e]?d[e]:d[e]={}:d[e]=b},ba=w.indexOf?function(a,b,c){return w.indexOf.call(a,b,c)}:function(a,b,c){if(c=c==l?0:0>c?Math.max(0,a.length+c):c,"string"==typeof a)return"string"==typeof b&&1==b.length?a.indexOf(b,c):-1;for(;c<a.length;c++)if(c in a&&a[c]===b)return c;return-1},z=function(a,b,c){if(b=typeof a,"object"==b)if(a){if(a instanceof Array)return"array";if(a instanceof Object)return b;if(c=Object.prototype.toString.call(a),"[object Window]"==c)return"object";if("[object Array]"==c||"number"==typeof a.length&&"undefined"!=typeof a.splice&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("splice"))return"array";if("[object Function]"==c||"undefined"!=typeof a.call&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("call"))return"function"}else return"null";else if("function"==b&&"undefined"==typeof a.call)return"object";return b},A=/\\b(?:MSIE|rv)[: ]([^\\);]+)(\\)|;)/.exec(q.navigator?q.navigator.userAgent:l),u=A?A[1]:"",B=x(),ca=B>parseFloat(u)?String(B):u,da={},ea=q.document,C=function(a,b,c,d,e,f,k,m,n,t,r,s){if(!(b=da[a])){for(b=0,c=String(ca).replace(/^[\\s\\xa0]+|[\\s\\xa0]+$/g,"").split("."),d=String(a).replace(/^[\\s\\xa0]+|[\\s\\xa0]+$/g,"").split("."),e=Math.max(c.length,d.length),f=0;0==b&&f<e;f++){k=c[f]||"",m=d[f]||"",n=RegExp("(\\\\d*)(\\\\D*)","g"),t=RegExp("(\\\\d*)(\\\\D*)","g");do{if(r=n.exec(k)||["","",""],s=t.exec(m)||["","",""],0==r[0].length&&0==s[0].length)break;b=((0==r[1].length?0:parseInt(r[1],10))<(0==s[1].length?0:parseInt(s[1],10))?-1:(0==r[1].length?0:parseInt(r[1],10))>(0==s[1].length?0:parseInt(s[1],10))?1:0)||((0==r[2].length)<(0==s[2].length)?-1:(0==r[2].length)>(0==s[2].length)?1:0)||(r[2]<s[2]?-1:r[2]>s[2]?1:0)}while(0==b)}b=da[a]=0<=b}return b},fa=ea?x()||("CSS1Compat"==ea.compatMode?parseInt(ca,10):5):v,D=(C("9"),new function(){aa()},l),E=l,G=l,H=9<=fa,ga=function(a){if(!D)for(D={},E={},G={},a=0;65>a;a++)D[a]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(a),E[D[a]]=a,G[a]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.".charAt(a)},ha=function(a,b,c,d,e){for(a=a.replace(/\\r\\n/g,"\\n"),b=[],d=c=0;d<a.length;d++)e=a.charCodeAt(d),128>e?b[c++]=e:(2048>e?b[c++]=e>>6|192:(b[c++]=e>>12|224,b[c++]=e>>6&63|128),b[c++]=e&63|128);return b},ia=!C("9"),I=(C("8"),C("9"),function(a,b){this.type=a,this.currentTarget=this.target=b}),J=(I.prototype.pa=p,I.prototype.defaultPrevented=p,I.prototype.preventDefault=function(){this.defaultPrevented=h},function(a,b,c,d){a&&(c=this.type=a.type,I.call(this,c),this.currentTarget=b,d=a.relatedTarget,this.target=a.target||a.srcElement,d||("mouseover"==c?d=a.fromElement:"mouseout"==c&&(d=a.toElement)),this.relatedTarget=d,this.Y=a,this.button=a.button,this.ctrlKey=a.ctrlKey,this.altKey=a.altKey,this.shiftKey=a.shiftKey,this.metaKey=a.metaKey,this.state=a.state,this.screenX=a.screenX||0,this.screenY=a.screenY||0,this.keyCode=a.keyCode||0,this.offsetX=a.offsetX!==v?a.offsetX:a.layerX,this.offsetY=a.offsetY!==v?a.offsetY:a.layerY,this.clientX=a.clientX!==v?a.clientX:a.pageX,this.clientY=a.clientY!==v?a.clientY:a.pageY,this.charCode=a.charCode||("keypress"==c?a.keyCode:0),a.defaultPrevented&&this.preventDefault(),delete this.pa)}),ja=(function(){function a(){}a.prototype=I.prototype,J.qa=I.prototype,J.prototype=new a}(),g=J.prototype,g.target=l,g.relatedTarget=l,g.offsetX=0,g.offsetY=0,g.clientX=0,g.clientY=0,g.screenX=0,g.screenY=0,g.button=0,g.keyCode=0,g.charCode=0,g.ctrlKey=p,g.altKey=p,g.shiftKey=p,g.metaKey=p,g.Y=l,g.preventDefault=function(a){if(J.qa.preventDefault.call(this),a=this.Y,a.preventDefault)a.preventDefault();else if(a.returnValue=p,ia)try{if(a.ctrlKey||112<=a.keyCode&&123>=a.keyCode)a.keyCode=-1}catch(b){}},"closure_listenable_"+(1E6*Math.random()|0)),ka=0,la=function(a){try{return!(!a||!a[ja])}catch(b){return p}},K=function(a){this.src=a,this.l={},this.M=0},ma=function(a){a.s=h,a.k=l,a.t=l,a.src=l,a.K=l},na=function(a,b,c,d,e){this.k=a,this.t=l,this.src=b,this.type=c,this.K=e,this.capture=!!d,this.key=++ka,this.s=this.L=p},L=(K.prototype.add=function(a,b,c,d,e,f,k,m){f=this.l[a],f||(f=this.l[a]=[],this.M++);t:{for(k=0;k<f.length;++k)if(m=f[k],!m.s&&m.k==b&&m.capture==!!d&&m.K==e)break t;k=-1}return-1<k?(a=f[k],c||(a.L=p)):(a=new na(b,this.src,a,!!d,e),a.L=c,f.push(a)),a},"closure_lm_"+(1E6*Math.random()|0)),M={},oa=0,pa=function(a){return a=a[L],a instanceof K?a:l},sa=function(a,b){return a=ra,b=H?function(c){return a.call(b.src,b.k,c)}:function(c){if(c=a.call(b.src,b.k,c),!c)return c}},ra=function(a,b,c,d,e){if(a.s)return h;if(!H){if(!(c=b))t:{for(d=q,c=["window","event"];e=c.shift();)if(d[e]!=l)d=d[e];else{c=l;break t}c=d}return c=new J(c,this),d=h,d=ta(a,c)}return ta(a,new J(b,this))},N=function(a,b,c,d,e,f,k){if("array"==z(b))for(f=0;f<b.length;f++)N(a,b[f],c,d,e);else if(c=ua(c),la(a))a.ta(b,c,d,e);else{if(!b)throw Error("Invalid event type");if(f=!!d,!f||H)(k=pa(a))||(a[L]=k=new K(a)),c=k.add(b,c,p,d,e),c.t||(d=sa(),c.t=d,d.src=a,d.k=c,a.addEventListener?a.addEventListener(b,d,f):a.attachEvent(b in M?M[b]:M[b]="on"+b,d),oa++)}},ta=function(a,b,c,d,e,f,k,m,n,t){if(c=a.k,d=a.K||a.src,a.L&&"number"!=typeof a&&a&&!a.s)if(e=a.src,la(e))e.sa(a);else if(f=a.type,k=a.t,e.removeEventListener?e.removeEventListener(f,k,a.capture):e.detachEvent&&e.detachEvent(f in M?M[f]:M[f]="on"+f,k),oa--,f=pa(e)){if(k=a.type,m=k in f.l)m=f.l[k],n=ba(m,a),(t=0<=n)&&w.splice.call(m,n,1),m=t;m&&(ma(a),0==f.l[k].length&&(delete f.l[k],f.M--)),0==f.M&&(f.src=l,e[L]=l)}else ma(a);return c.call(d,b)},va="__closure_events_fn_"+(1E9*Math.random()>>>0),O=function(a,b){a.o=("E:"+b.message+":"+b.stack).slice(0,2048)},ua=function(a){return"function"==z(a)?a:a[va]||(a[va]=function(b){return a.handleEvent(b)})},wa=function(a,b){for(b=Array(a);a--;)b[a]=255*Math.random()|0;return b},P=function(a,b){return a[b]<<24|a[b+1]<<16|a[b+2]<<8|a[b+3]},xa=function(a,b){a.T.push(a.c.slice()),a.c[a.b]=v,Q(a,a.b,b)},ya=function(a,b,c){return c=function(){return a},b=function(){return c()},b.ca=function(b){a=b},b},Aa=function(a,b,c,d){return function(){if(!d||a.w)return Q(a,a.W,arguments),Q(a,a.m,c),za(a,b)}},R=function(a,b,c,d){for(c=[],d=b-1;0<=d;d--)c[b-1-d]=a>>8*d&255;return c},za=function(a,b,c,d){return c=a.a(a.b),a.f&&c<a.f.length?(Q(a,a.b,a.f.length),xa(a,b)):Q(a,a.b,b),d=a.B(),Q(a,a.b,c),d},X=function(a,b,c,d){for(b={},b.I=a.a(S(a)),b.J=S(a),c=S(a)-1,d=S(a),b.self=a.a(d),b.r=[];c--;)d=S(a),b.r.push(a.a(d));return b},Y=function(a,b){return b<=a.ka?b==a.h||b==a.d||b==a.g||b==a.u?a.p:b==a.W||b==a.Q||b==a.R||b==a.m?a.F:b==a.G?a.i:4:[1,2,4,a.p,a.F,a.i][b%a.la]},Ba=function(a,b,c,d){try{for(d=0;84941944608!=d;)a+=(b<<4^b>>>5)+b^d+c[d&3],d+=2654435769,b+=(a<<4^a>>>5)+a^d+c[d>>>11&3];return[a>>>24,a>>16&255,a>>8&255,a&255,b>>>24,b>>16&255,b>>8&255,b&255]}catch(e){throw e;}},Q=function(a,b,c){if(b==a.b||b==a.n)a.c[b]?a.c[b].ca(c):a.c[b]=ya(c);else if(b!=a.d&&b!=a.g&&b!=a.h||!a.c[b])a.c[b]=Ca(c,a.a);b==a.v&&(a.C=v,Q(a,a.b,a.a(a.b)+4))},S=function(a,b,c){if(b=a.a(a.b),!(b in a.f))throw a.e(a.fa),a.D;return a.C==v&&(a.C=P(a.f,b-4),a.H=v),a.H!=b>>3&&(a.H=b>>3,c=[0,0,0,a.a(a.v)],a.ga=Ba(a.C,a.H,c)),Q(a,a.b,b+1),a.f[b]^a.ga[b%8]},Ca=function(a,b,c,d,e,f,k,m,n){return m=Z,e=Z.prototype,f=e.B,k=e.X,n=e.e,d=function(){return c()},c=function(a,r,s){for(s=0,a=d[e.N],r=a===b,a=a&&a[e.N];a&&a!=f&&a!=k&&a!=m&&a!=n&&20>s;)s++,a=a[e.N];return c[e.oa+r+!(!a+(s>>2))]},d[e.S]=e,c[e.na]=a,a=v,d},$=function(a,b,c,d,e,f){for(e=a.a(b),b=b==a.g?function(b,c,d,f){try{c=e.length,d=c-4>>3,e.ja!=d&&(e.ja=d,d=(d<<3)-4,f=[0,0,0,a.a(a.P)],e.ia=Ba(P(e,d),P(e,d+4),f)),e.push(e.ia[c&7]^b)}catch(r){throw r;}}:function(a){e.push(a)},d&&b(d&255),f=0,d=c.length;f<d;f++)b(c[f])},Z=function(a,b,c,d,e,f,k,m){try{if(this.j=2048,this.c=[],Q(this,this.b,0),Q(this,this.n,0),Q(this,this.v,0),Q(this,this.h,[]),Q(this,this.d,[]),Q(this,this.Q,"object"==typeof window?window:q),Q(this,this.R,this),Q(this,this.A,0),Q(this,this.O,0),Q(this,this.P,0),Q(this,this.g,wa(4)),Q(this,this.u,[]),Q(this,this.m,{}),this.w=h,a&&"!"==a[0])this.o=a;else{for(ga(),b=E,c=[],d=0;d<a.length;){if(e=b[a.charAt(d++)],f=d<a.length?b[a.charAt(d)]:0,++d,k=d<a.length?b[a.charAt(d)]:0,++d,m=d<a.length?b[a.charAt(d)]:0,++d,e==l||f==l||k==l||m==l)throw Error();c.push(e<<2|f>>4),64!=k&&(c.push(f<<4&240|k>>2),64!=m&&c.push(k<<6&192|m))}(this.f=c)&&this.f.length?(this.T=[],this.B()):this.e(this.Z)}}catch(n){O(this,n)}};g=Z.prototype,g.b=0,g.v=1,g.h=2,g.n=3,g.d=4,g.G=5,g.W=6,g.U=8,g.Q=9,g.R=10,g.A=11,g.O=12,g.P=13,g.g=14,g.u=15,g.m=16,g.ka=17,g.$=15,g.ha=12,g.aa=10,g.ba=42,g.la=6,g.i=-1,g.p=-2,g.F=-3,g.Z=17,g.da=21,g.q=22,g.ma=30,g.fa=31,g.ea=33,g.D={},g.N="caller",g.S="toString",g.oa=34,g.na=36,Z.prototype.a=function(a,b){if(b=this.c[a],b===v)throw this.e(this.ma,0,a),this.D;return b()},Z.prototype.wa=function(a,b,c,d){d=a[(b+2)%3],a[b]=a[b]-a[(b+1)%3]-d^(1==b?d<<c:d>>>c)},Z.prototype.va=function(a,b,c,d){if(3==a.length){for(c=0;3>c;c++)b[c]+=a[c];for(c=0,d=[13,8,13,12,16,5,3,10,15];9>c;c++)b[3](b,c%3,d[c])}},Z.prototype.xa=function(a,b){b.push(a[0]<<24|a[1]<<16|a[2]<<8|a[3]),b.push(a[4]<<24|a[5]<<16|a[6]<<8|a[7]),b.push(a[8]<<24|a[9]<<16|a[10]<<8|a[11])},Z.prototype.e=function(a,b,c,d){d=this.a(this.n),a=[a,d>>8&255,d&255],c!=v&&a.push(c),0==this.a(this.h).length&&(this.c[this.h]=v,Q(this,this.h,a)),b&&3<this.j&&(c="",b.message&&(c+=b.message),b.stack!=v&&(c+=": "+b.stack),c=c.slice(0,this.j-3),this.j-=c.length+3,c=ha(c),$(this,this.g,R(c.length,2).concat(c),this.ha))},g.V=[function(){},function(a,b,c,d,e){b=S(a),c=S(a),d=a.a(b),b=Y(a,b),e=Y(a,c),e==a.i||e==a.p?d=""+d:0<b&&(1==b?d&=255:2==b?d&=65535:4==b&&(d&=4294967295)),Q(a,c,d)},function(a,b,c,d,e,f,k,m,n){if(b=S(a),c=Y(a,b),0<c){for(d=0;c--;)d=d<<8|S(a);Q(a,b,d)}else if(c!=a.F){if(d=S(a)<<8|S(a),c==a.i)if(c="",a.c[a.G]!=v)for(e=a.a(a.G);d--;)f=e[S(a)<<8|S(a)],c+=f;else{for(c=Array(d),e=0;e<d;e++)c[e]=S(a);for(d=c,c=[],f=e=0;e<d.length;)k=d[e++],128>k?c[f++]=String.fromCharCode(k):191<k&&224>k?(m=d[e++],c[f++]=String.fromCharCode((k&31)<<6|m&63)):(m=d[e++],n=d[e++],c[f++]=String.fromCharCode((k&15)<<12|(m&63)<<6|n&63));c=c.join("")}else for(c=Array(d),e=0;e<d;e++)c[e]=S(a);Q(a,b,c)}},function(a){S(a)},function(a,b,c,d){b=S(a),c=S(a),d=S(a),c=a.a(c),b=a.a(b),Q(a,d,b[c])},function(a,b,c){b=S(a),c=S(a),b=a.a(b),Q(a,c,z(b))},function(a,b,c,d,e){b=S(a),c=S(a),d=Y(a,b),e=Y(a,c),c!=a.h&&(d==a.i&&e==a.i?(a.c[c]==v&&Q(a,c,""),Q(a,c,a.a(c)+a.a(b))):e==a.p&&(0>d?(b=a.a(b),d==a.i&&(b=ha(""+b)),c!=a.d&&c!=a.g&&c!=a.u||$(a,c,R(b.length,2)),$(a,c,b)):0<d&&$(a,c,R(a.a(b),d))))},function(a,b,c){b=S(a),c=S(a),Q(a,c,function(a){return eval(a)}(a.a(b)))},function(a,b,c){b=S(a),c=S(a),Q(a,c,a.a(c)-a.a(b))},function(a,b){b=X(a),Q(a,b.J,b.I.apply(b.self,b.r))},function(a,b,c){b=S(a),c=S(a),Q(a,c,a.a(c)%a.a(b))},function(a,b,c,d,e){b=S(a),c=a.a(S(a)),d=a.a(S(a)),e=a.a(S(a)),b=a.a(b),N(b,c,Aa(a,d,e,h))},function(a,b,c,d){b=S(a),c=S(a),d=S(a),a.a(b)[a.a(c)]=a.a(d)},function(a,b,c,d,e){b=X(a),c=b.r,d=b.self,e=b.I;switch(c.length){case 0:c=d[e]();break;case 1:c=d[e](c[0]);break;case 2:c=d[e](c[0],c[1]);break;case 3:c=d[e](c[0],c[1],c[2]);break;default:a.e(a.q);return}Q(a,b.J,c)},function(a,b,c){b=S(a),c=S(a),Q(a,c,a.a(c)+a.a(b))},function(a,b,c){b=S(a),c=S(a),0!=a.a(b)&&Q(a,a.b,a.a(c))},function(a,b,c,d){b=S(a),c=S(a),d=S(a),a.a(b)==a.a(c)&&Q(a,d,a.a(d)+1)},function(a,b,c,d){b=S(a),c=S(a),d=S(a),a.a(b)>a.a(c)&&Q(a,d,a.a(d)+1)},function(a,b,c,d){b=S(a),c=S(a),d=S(a),Q(a,d,a.a(b)<<c)},function(a,b,c,d){b=S(a),c=S(a),d=S(a),Q(a,d,a.a(b)|a.a(c))},function(a,b){b=a.a(S(a)),xa(a,b)},function(a,b,c,d){if(b=a.T.pop()){for(c=S(a);0<c;c--)d=S(a),b[d]=a.c[d];a.c=b}else Q(a,a.b,a.f.length)},function(a,b,c,d){b=S(a),c=S(a),d=S(a),Q(a,d,(a.a(b)in a.a(c))+0)},function(a,b,c,d){b=S(a),c=a.a(S(a)),d=a.a(S(a)),Q(a,b,Aa(a,c,d))},function(a,b,c){b=S(a),c=S(a),Q(a,c,a.a(c)*a.a(b))},function(a,b,c,d){b=S(a),c=S(a),d=S(a),Q(a,d,a.a(b)>>c)},function(a,b,c,d){b=S(a),c=S(a),d=S(a),Q(a,d,a.a(b)||a.a(c))},function(a,b,c,d,e){b=X(a),c=b.r,d=b.self,e=b.I;switch(c.length){case 0:c=new d[e];break;case 1:c=new d[e](c[0]);break;case 2:c=new d[e](c[0],c[1]);break;case 3:c=new d[e](c[0],c[1],c[2]);break;case 4:c=new d[e](c[0],c[1],c[2],c[3]);break;default:a.e(a.q);return}Q(a,b.J,c)},function(a,b,c,d,e,f){if(b=S(a),c=S(a),d=S(a),e=S(a),b=a.a(b),c=a.a(c),d=a.a(d),a=a.a(e),"object"==z(b)){for(f in e=[],b)e.push(f);b=e}for(e=0,f=b.length;e<f;e+=d)c(b.slice(e,e+d),a)}],Z.prototype.ua=function(a){return(a=window.performance)&&a.now?function(){return a.now()|0}:function(){return+new Date}}(),Z.prototype.ra=function(a){a(this.X())},Z.prototype.B=function(a,b,c,d,e,f){try{for(b=2001,c=v,d=0,a=this.f.length;--b&&(d=this.a(this.b))<a;)try{Q(this,this.n,d),e=S(this)%this.V.length,(c=this.V[e])?c(this):this.e(this.da,0,e)}catch(k){k!=this.D&&((f=this.a(this.A))?(Q(this,f,k),Q(this,this.A,0)):this.e(this.q,k))}b||this.e(this.ea)}catch(m){try{this.e(this.q,m)}catch(n){O(this,n)}}return this.a(this.m)},Z.prototype.X=function(a,b,c,d,e,f,k,m,n,t,r,s,T,qa,U,V,W,F){if(this.o)return this.o;try{for(this.w=p,b=this.a(this.d).length,c=this.a(this.g).length,d=this.j,this.c[this.U]&&za(this,this.a(this.U)),e=this.a(this.h),0<e.length&&$(this,this.d,R(e.length,2).concat(e),this.$),f=this.a(this.O)&255,f-=this.a(this.d).length+4,k=this.a(this.g),4<k.length&&(f-=k.length+3),0<f&&$(this,this.d,R(f,2).concat(wa(f)),this.aa),4<k.length&&$(this,this.d,R(k.length,2).concat(k),this.ba),m=[3].concat(this.a(this.d)),ga(),t=[],e=0;e<m.length;e+=3)r=m[e],T=(s=e+1<m.length)?m[e+1]:0,U=(qa=e+2<m.length)?m[e+2]:0,f=r>>2,W=U&63,k=(r&3)<<4|T>>4,V=(T&15)<<2|U>>6,qa||(W=64,s||(V=64)),t.push(G[f],G[k],G[V],G[W]);if(n=t=t.join("").replace(/\\./g,""))n="!"+n;else for(n="",t=0;t<m.length;t++)F=m[t][this.S](16),1==F.length&&(F="0"+F),n+=F;a=n,this.j=d,this.w=h,this.a(this.d).length=b,this.a(this.g).length=c}catch(Da){O(this,Da),a=this.o}return a};try{N(window,"unload",function(){})}catch(Ea){}y("botguard.bg",Z),y("botguard.bg.prototype.invoke",Z.prototype.ra);')})()</script>
  <script type="text/javascript">
  document.bg = new botguard.bg('PbCG72Tkuqv63LFuGqzfNy8O2XB2+qrNxS4Je+crQ6J0Px/1TSkAVmmHiYC9gK2bHHwM1mE8iXskxvv3lazFSuOsu6ucgqb4gLdNcpARbHP5UTlyZajfNn61MBlW1pCUjogZksD0IA/pxWJOQVHws7lecqo7jvhDVkeqcaojdeZmSCto2c8lhBPRKzQ1sZxLmoexNWICO+ENcqMsqjn5ET6+3I2vsXtNTOPF3BNcglIMnjiAZD9QNGvO5OEHu1YbhXjJpwDlXW4KESG9fE7J2X3J/SJLzPZSRVBWDv8byuQdo2e0rrwilbBPD1k2rP/U7FwbyULwybboPtPhVqQq5ekw+4kBni0Ql7xceQFXl5FqJW7PT6uht3z5gc9OyakyNSztSYSk8HONJ4bes96GZPAC2NO7WRjEmvMZJ/HjT07ADA2IaKC66OdiXH5A+5bxgLJVSQSFTfMreSl0jsG54F+CiGBs1jR45orX92977BD0Y4qE1ub7quKPDrdywAn+r+/DQyrFkKgQRKt8S1U488MyV6rGNwDAsgfIjqrsvgf0yXKZDgqJ46cl0A8VH4CRxWbH4Vilmeggjl3jFuQ9iDjpvYHtPkm4QezlAiZfdxPNu7D/uloWh4wftE7kqyVIXaR0u/npVWMPgxyWl9p2Vrp8TaynkO1MQlwuApmp5f3GA1QTvvos0es043ypXhQgnEPStSHoGGi3BKi5XQAgMcf/f5fFUNACWqEbsYQfYJDUBjUzY4I+SYiWc05fJYCCewvgEQDdpuLZ1GbjsaoU1F0g81YQO/AOazY0jxtoq/jF4dEYIp+d38GBx/X4sVfgM6yvu3iPxGHAkI0eN6AxjMVhit7AISUBmjKIAJQwpLOoUYNFFXr6J821Tq4chF7NJFXt8VJJ7bHc9qpXp6Xc+qES+C5iqeavVHZkIa+dgC31nedYRB7bQuAVYK37uJx0jHi18Tg3QkZ3+QM9kJNcmoRic1xeT4pt1JZbkgM0HDkGGt8gq9eNbxi5rXfmWr9FzLvo3t/vDwOv9Jxj3TK7lKwiqEqVrrPtGit6/voCuv45HQUE/zPaUTo/Z4f42zUt7XKJQQuXfGYeQ7+5UgYWlSQAS6GOTM35L6mS9wW7MXc5aCmPSizCNWn8h5KgGYJsC/hkegx0cXCncUkD3cX1uj+x9UCsPxkQoDZhCwTHQFK7EQ+rwIjYGsetARCfRV7QxVlCjQlQPhurp1xNXEDJ3MuNg+2YVLFOTtYvJIjJWjHq9zZbpVJCdYY6sLa68sz+H9O/UlpHn7hM5aWIjp/2eGiM6jVl1L2t+CQOLIR2cwQn9LJXTPKmP2DkaxTK/MmFN8ZPEYjovW3NgEuDCHFgKzcTkyyGVlOyhGPstG3FXEY37Rte+WrH2zdLOy/ghGnToCGoJvfN2AHG2AWgqht+kbJOz+FdRP0Ffg4cTSN6Y7ICyIVA/H7632Q1BUeSswM7+eQ9ZjTHd/+hIbSQ85ANmt3XUjpCt13iXLWo9vGe1c077/vPQipmt4y3HoMtViOqSBoI2aXGmfdPZTBnkMpQo74rO3WYGzSZmgxG6Ba9J8Jw4DmHTuqaT+UPvBv1DCObbiaBN7RlC0DoBzpPqyQhAMh7yzHhpjbr5+NWcW6ZpNZpbCYFjxTd44xNgVcWbVeZJbaugM2NIGLP9P1kjkpGc3BAmZaeV1TilIAqrlR1R9V5QBmryD7gKD+FNFLIgmk5GUdP7zrL6j0cfMhuviXbUpWWdscpqN5Zijne3ZTMZOCZREJgB14nUZyj5JBRa3jvvMxxq3L7NaNdfla5gtSHXAwFXaYvXOqdhTp0BiR3HpqKLgVElUaEUcQEDu+p9T7JyIG9ALVE3uX2cr55TbbdDb0CMF8LMdSwHYnOvBlhillKNjjviymBCmc3VFy9AX2NrmYz32EBc50JVa2vS3Y8naRG0whZdMnPiSHFizzBrhTS+e/9beCKRVgYYF2W2hA7+mEHZK8xCnDuNUWfYROR5wwImipaBPg5g2ouSjdHmaAbVxZOGUHzH+ZrQoGorZzY+GAnPyh+3SHWunJhaIKvQpT5zs9YZYYbbzg634AVXbkQd9ZS6AACCJVSODzZ/v20Lf4HWPO5/YaS6i5v3VLGaksnGElOKPHHMY8YDuR7yoBanHdv7WLtRMNscOz8xXNhR37t+/FgGxU7FlEGkEMPAG8VGx9Nf2lMpUoMU/AptmityBXMwJjTZEYNq+G+b+kEdD1rSfTofz+1H9umvLdmMJGUHHBl17AipwsWDxSdUJckESn0PU0Vy89fJHuR/nL4utU8qu45rBe/5UL8ME7Y25hbaxnEFGigPuxRc2Fr3UfVEuCoFb4FvwU3TN7iXVpOSWjqz/sJ7E+IfNiP98IRBhyyWbTHT8myzhqjNRGKDzLNkJ2AqEzX3326fFtYtYHceix22XNe1noF4/ccynl/IuZusNr7VU6HocWeaEM8iK6XH3XEGQYKQOKl06z1pRrb1uKXBtmVCcKUTqDyUeiPvYqbmo071zngFjjRVzlTxbTZVlwwXMSw3EbJc0VvcioBKzaTly0SGMSELNnzD87Ngt0sTe9C3NSoFDXJksE6mg6rD2ES7RZMWmpuQvi5jC2zWzd0i2QKJSbKXRgVR+1lIon0JwRpGJlL9bppfubNXnkemYF4oGnRxJCES3iBF1bAP5dxJUmcL+EZZu4oj3EcXkDuItJzP21pMV2cy9J6ymevMoYp8uiaH9zVQoli+wuUGoyoT3yvoL4sFh0YTLcqp2XqDQ7RYjkFrbUya6Nn7PJjaeo6lnztRrCxFMXq9g96xvGEXV3SQQPx1cVC9fXc01lUuoo4ZvTvpnxdwXJNDNy7qB9wzoLURb4c+tR4SbfI8Xx0IAdvnyh7Hb3ODnsRbT4LyIip/nhVgU+uYxs1byQHNB7FBSk1xK45FRIMV8jLmUP28G2HprebniQHnv8dahb39Q2RaVIXkA1TBWECrBZIRZcjLrf/l51fGMqDC4gMAIZqz0Qa/fRcqPTf12lF/eSUWoe4qEr7KaXAKq7tNuX7Qq++XoHl+eIsuWmD1mtK0lkmvnLPMYls0rT6d0QuZJ4xGGgu2sCsD6n+JlaLRStYzPDpw0kmTAOylXaNS95FFbECptq7lJ7/XyilMDhj6R1AfKXR40N3B0srtiOogIXL95RXtcKhBlhj2OLAXxGwQpf60Hd01wj2qOgT7FZNz2OOGCJYEqmLgiQfoYwSTnDFUbLfG/FnuMNe1wkwKPlFYzFOr2ELx5xIIgv0ipPWZ8hCR7Tsgy5TWevfUTceQwAHLrHDnEiP3IvgiAKs2lhGvyA7OLpCWUw4hS/1lN7bBzTnUXn8kMLOI7U5YjyoSGuNiUI3cZfvf/ghynkGo8BpJ84xcyV8P/LavxzcIIfFEwORIZg7qkzjy4c572TxvIIdsqJsSH34zsiz+DpgNXrrq8XY5w1mEWQN1I4RA3eEZrvXcfEfG9M2ez2Na+6c90WvMdMYYyJ4OV2P3f/8i7TanWKarrj1Szmrr3zX5nWwX7watbPoxITLzcQWdLdbZ+78LlvEdGeRjBFlQRm1CnDrKNGHPOvVTEm3/q/b9Zf7WSXShwWoXO8VdvdiKX8KTBIMHH2f4+uaF4s+R3Vj5/A6GfwF7nB8z6jwQlzoVrpe0O1O/wJBruMrOEpDApTKxuer5PtoSGjI6Oh52oAIfSl/EJxbe7/V2uLLROsODgf0a8jZoqUOo2M4VYWuvkReFiGIOS4LF4j1fFc62uI7aOJ4Bk0YWlByZgbNH+sB6RlgMXHvXtnWPOGaAY0B8uIrtgBNfx9NjnMj24C5QWgy846bntjrWL91WW/TDQUTYahKgYzAIeOXVNYj1MrnHx/qMDmHZ5j8tqPn/i46P9rq+LG8nCMkzpqGKI5K35/heruoXfjQwaZ/8pnJ5tACxJGCsZEM3a3ajLMS8CmsCFcC3DvJ18dWKfRikd8JQoQ/cFUHF9YiKzLCDzqRQzSL5xqrcb8c9Wx1iAsxW/+asbrAebWRWWe+pqjrKivh9/9U2qUrblDV7/xFeKLQ5ChLFDQf4Rjp8TjZ9U1wjLZjtfsUZHx7qZ1CfIEe/ppwiNyYREEAfpNCD8F9gxF3oi3if/N3KLD34c5rgSyrcijyZs0Oem1i1qABhG2FUNPUd35FOVZvFOeosQeiWIPX0lx+xQtmofko4qGpkKpL+oKlfr56T+EJG6hkFBpmGVT6nz7pH9phSl7PMHzLFsTh7KL/gkBe873PEBrsMKJSapvCTE1+79isb3iE9b92s4h6CgVvD8yN8MMILpDbW7J4BBEsuq2SPz6wVZ3Um1VMESOGvuUAvXkWymAn4gg8i7pnpV1HmdM9IDIRIFSdR+LQDa9mNdKYTm7+ko9bVjNnTcliN9nuwZsoCr9/4gRtJdjc3qcYhr+4quu3y4mASHAFjmJv4/w9WUIhP3OsMFgRx4WN9OCp0g+iOvqS8JYMru6fpR+5CdtuEl17+ViLUag5yvKFYdDBxLmc1IXbYUc8lmzhU312LYIyst6vnKIrgvNqZIV4/7r2984xz2eqCI6mmoR6tr0TQiHH+jhvaoFBVwQ1B/rIUkJ/Ds4co3RwyfDTJ/MbeR+FPf1knvFFLbbNJ+5/4ibMK0pMSh8uB7pqlNCaI0zl0BSDVDKlX0BmUdClu06LCHq10tVgsfYTYz+rRo+x04sBSbXTOp1TEpCBc86nXqczJ/BhwZPl0c6nvkEkGld9BMUa0JI+10bODQbHnD5q8Sm732cgeAFMOjwZZ4q1xfpU0ZbSW8HpFPCPw1fNLuRrtzY6ViAZ0yVdlJJInPszea9xxO/78DX6Ll7Aw8NRmlTQJOClxKue7t9bRYXP8Fo7RlrUX6+fxQViM06Vdtpfc0jvw8jC5dQcfeObhZYxmd9D3MdL6DJqg1Ogvbw2bRQf5XYhlUAb+J4B31PKXH7Eq40sFM8bPbJ/QpnysdHx4Adock4yyj5ROZfT1SQcWB1L1cHg/NcPVf9tVkf6p+JQmdZIGcCamXs1AW/PJJ1RVIkU8kzKoA85reLAiQ3YG9qwjPed3otDb1bvC2+MwyAVpj2Ng7IXjJVxumuNmdQPKrAJ5RW9f30lHYCThfsBXmwK0VbndRFhdDsb0QRIkTOK44su+XmhdeJO9hoKVEfrLv2MWDJ8mV4yQNiD7OOu2/jw3pFUmogJvOAZxDK0E5HC4HJXnMX8ZidWrOmjbau0pKRKe64SPetaOW4/uuywTlmCw02U/KQi+Mdn/PMds1M3OqkiigjBeUQgnRDY5OD4noztQ+LdHPpeCdf20fDl/252ciqJ16DSQg3r4ziZ2F/W2cK4Y8oS9yicAfzuCSUcALalfweFi9/BbVXaQVkSCeDD9INlC3oqACr5DlA2Vb1minyOfkEYNwbfNjEz7uW5oVTLfSze3cSZGlzSsfN61WAMs8tl9JJGkut/l1PefIJCdx1ij4EyifYbMQskzqaKj/Z4O4rHAjSL6BdddHEBD/SO5kBW9rCI0GwB1i7SDGAjpE5VQMfGF/Q2aZilo9utLJFK0uAEpYNygbcjdfIozBAa1uCuZYfdUJlrCynVBsi3VwjsdmQKPcwGSYAjVwGoGdiRWgnYekE0pe7W3maTstjseBVth0L/pXL3Q7LtJ9G2NO/qloxeFRPcyyUDGI2lMP054r/QhrccY5LUYh61Ra5wY7BHiE2/xWt1Gap9pTuHGgoDKOELmBg6j4uLBZgdycKIeY8gkrZ8AJH4JXsgCrwFU/fa1imIYHR2WA/S4nlHuWsD9wv8wt5BQOUruXBIjUJeDLkIrRcnX/KodgLhexw4ofcPUlnDSXsVMlU7hnfdZggN0lIYfQimk8xMAgz064JpQ52fVfyZVtOp9ZaS4MJL9JGqb+o0a/1ymcFjrqGK0eMfQn/uRVhh+8WOwQjrfnohNuHmF1adXDgR1k0ee1EN4zLcLIKyF2w57OadwdLTkDXHhdy5ZLQMaJJPnqYyhHqndh6MKPSPMilU8hp3veXfKzVVsE5kSebkT8o+c8VaCqmTweYp2YSK4maMau97qPrimckLTTh7sPF0QI/i91XAqWylZQ4fFkpRRoBkES4r5mMQG6eZPSou/jLdgabh+keDgmk1v99KsGkYnCEgwutq8L2O2aSY5RjEGReb05iHE0NPpgY7HKE0FrWSfg/fkqxkCRGNbtQTHGe3+YpaIiABN6HR17h1vgVTQICW8Tal/A1A2Chv7uz6AfvrtLNR2ScsN4vst/yTEex0kxhH57nGog/+hE2SahHRB1dlCu6vRn/dCnISBpvUeo9akFqq+ZcBJE2lEPn9ToBLxnvRVRgH0Sd7Dhg/G9dL6O0ZGLywmR1a7Jq7ERGV9FTmirmcsrSrE1HKyyatk6tfD7wwDfwq/VWMc3gt2EGskXVgj6BcpHPio+dcWrlNj2j57VFg6BllAKe40S4rTvdWyaybWPlBX/1Lle3NYr+l4brSILguqhLhdtChhPVufbHLpY9yStImCGR0i1CVEM8dyrtDwi75mg3cmnjsukegfTdgoxHnAp8I5dMw1HHb5xu+fta8c12iQ5NIJF5ZbMFtQKmk3WChn8PUVjTPZSTXbmWSZ1UAkEfGg3SIyqhiK3UEQij3BRhsB+dTmTsSTW67vQkyBQz55m2hXZjV8g9HB6To+qLxkXYuUgXpWbtfS6La8ZzaVHP0nM5aDT7D1uQI7p4EnkSuBdUTYtQaKta9m0P8lZpZ0UHQxe5HWiPtYhCXBnuin5oivtFG2njwpcZIdYwvNsPMWHfIbJzsZNATfInapLPBpvF35ZvW17I+7eTt3RPQxLP5FqKCqAV4Oh3Wp11EQzsMjmxpcaTqHC5bPhu5kjkNxX6l6AL2fSmEaSuICLOm+56f5dESQkf/iA3ffslWxLGoWHv3F3HMwdTkAWZjEt7mXgSkzx6AHLmDD3Rq0C95lriiUTLphHTOLxlOrwycDP7FW6HetAybr27HHU/lqSMTYhnQtswHQTDxF6YVvljchKsIPjUcPFCOfDDYVfqlCzo6LeTdiwym2mA1vEfbygDKalFbZksSGysWeyz+ZVkPgwQP7AFMe6FD9BmdrQ6+1jemeNZWD0Y/eAfuLWxavXeJnq0xtMy3C3sjfMkNs0+22MPQUIiISKbCJS3Hzu3E9bj/l53REKBnB+oRo8/miSWpS7XTIFbOWYEC2oQJo7AV6x9n4YbSV58hAbrTzyZl8Yyu253qOLX3TScY8WP3R93j+MZIsZ4n8n9kyeAn4PM3+Qgy+O3i1JKT00BQMphTiDjWSIJpHfWsGpu8tRxNlue7dsLz/maxmRWhLNgFv9A1pO51Z5O9QoOnbobyJFqB9uwN5Qnn80o487Z/XtJ2z7C+b8S2PWmeWZUOu7r1u8tRFJVTe7X4bUu/QXR8QN8CKs49dkZf4wars5bopnikSVTi70BTDMIXALZqolHfhdhMun6pmLeJzbW4uwluxuRBIHhIAhCmOFqaJwAO8VLqi19bvr466+DSYuJgyllVkLUya6P9sg==');
  </script>
<script type="text/javascript">
  var gaia_hasInnerTextProperty =
  document.getElementsByTagName("body")[0].innerText != undefined ? true : false;
  var gaia_attachEvent = function(element, event, callback) {
  if (element.addEventListener) {
  element.addEventListener(event, callback, false);
  } else if (element.attachEvent) {
  element.attachEvent('on' + event, callback);
  }
  };
  var gaia_getElementsByClass = function(className) {
  if (document.getElementsByClassName) {
  return document.getElementsByClassName(className);
  } else if (document.querySelectorAll && document.querySelectorAll('.' + className)) {
  return document.querySelectorAll('.' + className);
  }
  return [];
  };
</script>
<script type="text/javascript">
  function gaia_parseFragment() {
  var hash = location.hash;
  var params = {};
  if (!hash) {
  return params;
  }
  var paramStrs = decodeURIComponent(hash.substring(1)).split('&');
  for (var i = 0; i < paramStrs.length; i++) {
      var param = paramStrs[i].split('=');
      params[param[0]] = param[1];
    }
    return params;
  }

  function gaia_prefillEmail() {
    var f = null;
    if (document.getElementById) {
      f = document.getElementById('gaia_loginform');
    }

    if (f && f.Email && (f.Email.value == null || f.Email.value == '')
        && (f.Email.type != 'hidden')) {
      hashParams = gaia_parseFragment();
      if (hashParams['Email'] && hashParams['Email'] != '') {
        f.Email.value = hashParams['Email'];
      }
    }
  }

  
  try {
    gaia_prefillEmail();
  } catch (e) {
  }


  
  function gaia_setFocus() {
    
    var f = null;
    if (document.getElementById) {
      f = document.getElementById('gaia_loginform');
    }
    if (f) {
      var agt = navigator.userAgent.toLowerCase();
      var is_ie = (agt.indexOf("msie") != -1);
      if (f.Email && (f.Email.value == null || f.Email.value == '' || is_ie)
          && (f.Email.type != 'hidden') && f.Email.focus) {
        f.Email.focus();
        if (f.Email.value) {
           
          f.Email.value = f.Email.value;
        }
      } else if (f.Passwd) {
        f.Passwd.focus();
      }
    }
    
  }

  if (!('ontouchstart' in window)) {
    window.onload = gaia_setFocus;
  }

  function gaia_onLoginSubmit() {
    
    
    if (window.gaiacb_onLoginSubmit) {
      gaiacb_onLoginSubmit();
    }
    
    

  
  try {
    document.bg.invoke(function(response) {
      document.getElementById('bgresponse').value = response;
    });
  } catch (err) {}
  


    return true;
  }
  document.getElementById('gaia_loginform').onsubmit = gaia_onLoginSubmit;

  
  

  

  

  
</script>
<script type="text/javascript">
  gaia_appendParam = function(url, name, value) {
  var param = encodeURIComponent(name) + '=' + encodeURIComponent(value);
  if (url.indexOf('?') >= 0) {
  return url + '&' + param;
  } else {
  return url + '?' + param;
  }
  };
  var langChooser = document.getElementById('lang-chooser');
  var langChooserWrap = document.getElementById('lang-chooser-wrap');
  if (langChooser && langChooserWrap) {
  var langChooserParam = 'hl';
  var langChooserUrl = '\x2FServiceLogin?service=SigmaVid\x26lp=1';
  langChooserWrap.style.display = '';
  langChooser.onchange = function() {
  window.location.href =
  gaia_appendParam(langChooserUrl, langChooserParam, this.value);
  };
  }
</script>
<script type="text/javascript">
  var gaia_swapHiResLogo = function() {
  var devicePixelRatio =
  window.devicePixelRatio ? window.devicePixelRatio : 1;
  if (devicePixelRatio > 1) {
  var logos = gaia_getElementsByClass('logo');
  for (var i = 0; i < logos.length; i++) {
        if (logos[i].nodeName == 'IMG' &&
            logos[i].src.search('nugg3t_logo_41.png') > 0) {
  logos[i].width = 116;
  logos[i].height = 41;
  logos[i].src = '//web.archive.org/web/20131012035920/https://ssl.gstatic.com/images/logo_ret.png';
  }
  }
  }
  }
  gaia_swapHiResLogo();
</script>
  </div>
  


</body></html><!--
     FILE ARCHIVED ON 03:59:20 Oct 12, 2013 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 15:28:41 Jul 21, 2024.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
--><!--
playback timings (ms):
  captures_list: 1.073
  exclusion.robots: 0.071
  exclusion.robots.policy: 0.049
  esindex: 0.019
  cdx.remote: 29.173
  LoadShardBlock: 159.592 (3)
  PetaboxLoader3.datanode: 46.476 (4)
  PetaboxLoader3.resolve: 246.302 (2)
  load_resource: 194.261
-->