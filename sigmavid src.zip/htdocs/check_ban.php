<?php
// Include the database connection
include 'db.php'; 

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Function to check if the user is banned
function checkBan($conn, $user_id) {
    $stmt = $conn->prepare("SELECT id FROM bans WHERE user_id = ? AND is_ip_ban = 0 AND (expires_at > NOW() OR expires_at IS NULL) LIMIT 1");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($ban_id);
    $stmt->fetch();
    $stmt->close();
    return $ban_id ? $ban_id : false;
}

// Function to check if the user's IP is banned
function checkIPBan($conn, $ip_address) {
    $stmt = $conn->prepare("SELECT id FROM bans WHERE ip_address = ? AND is_ip_ban = 1 AND (expires_at > NOW() OR expires_at IS NULL) LIMIT 1");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("s", $ip_address);
    $stmt->execute();
    $stmt->bind_result($ban_id);
    $stmt->fetch();
    $stmt->close();
    return $ban_id ? $ban_id : false;
}

// Check if user is logged in and has a user ID
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $ban_id = checkBan($conn, $user_id);

    if ($ban_id !== false) {
        // Redirect to ban page with the ban ID
        header("Location: ban.php?id=$ban_id");
        exit;
    }
}

// Check if the user's IP is banned
$ip_address = $_SERVER['REMOTE_ADDR'];
$ip_ban_id = checkIPBan($conn, $ip_address);

if ($ip_ban_id !== false) {
    // Redirect to ban page with the IP ban ID
    header("Location: ban.php?id=$ip_ban_id");
    exit;
}
?>
