<?php
// Start session only if not started already
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include 'db.php';
include 'check_maintenance.php';
include 'check_ban.php';

// Function to get time ago string
function getTimeAgoString($video) {
    if ($video['years_ago'] > 0) {
        return $video['years_ago'] . ' years ago';
    } elseif ($video['months_ago'] > 0) {
        return $video['months_ago'] . ' months ago';
    } elseif ($video['weeks_ago'] > 0) {
        return $video['weeks_ago'] . ' weeks ago';
    } elseif ($video['days_ago'] > 0) {
        return $video['days_ago'] . ' days ago';
    } elseif ($video['hours_ago'] > 0) {
        return $video['hours_ago'] . ' hours ago';
    } elseif ($video['minutes_ago'] > 0) {
        return $video['minutes_ago'] . ' minutes ago';
    } else {
        return $video['seconds_ago'] . ' seconds ago';
    }
}

// Function to format time ago
function timeAgo($timestamp) {
    $now = time();
    $timestamp = strtotime($timestamp);
    $diff = $now - $timestamp;

    if ($diff < 60) {
        return $diff . " seconds ago";
    } elseif ($diff < 3600) {
        return round($diff / 60) . " minutes ago";
    } elseif ($diff < 86400) {
        return round($diff / 3600) . " hours ago";
    } else {
        return round($diff / 86400) . " days ago";
    }
}

// Function to fetch user data by ID, including subscriber count
function getUserById($userId, $conn) {
    $userId = mysqli_real_escape_string($conn, $userId);
    $query = "
        SELECT 
            u.*, 
            (SELECT COUNT(*) FROM subscriptions WHERE user_id = u.id) AS subscriber_count 
        FROM 
            users u 
        WHERE 
            u.id = '$userId'
    ";
    $result = mysqli_query($conn, $query);
    if (!$result || mysqli_num_rows($result) == 0) {
        return false;
    }
    return mysqli_fetch_assoc($result);
}

// Function to fetch videos uploaded by user, limited to 5 most recent videos
function getRecentVideosByUserId($userId, $conn) {
    $userId = mysqli_real_escape_string($conn, $userId);
    $query = "SELECT * FROM videos WHERE user_id = '$userId' ORDER BY uploaded_at DESC LIMIT 5";
    $result = mysqli_query($conn, $query);
    if (!$result || mysqli_num_rows($result) == 0) {
        return [];
    }
    $videos = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $videos[] = $row;
    }
    return $videos;
}

// Function to fetch subscriber count for a user
function getSubscriberCount($userId, $conn) {
    $userId = mysqli_real_escape_string($conn, $userId);
    $query = "SELECT COUNT(*) AS subscriber_count FROM subscriptions WHERE user_id = '$userId'";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);
    return $data['subscriber_count'];
}

// Function to fetch subscribers for a user
function getSubscribers($userId, $conn) {
    $userId = mysqli_real_escape_string($conn, $userId);
    $query = "SELECT u.id, u.username, u.profile_picture 
              FROM subscriptions s 
              JOIN users u ON s.subscriber_id = u.id 
              WHERE s.user_id = '$userId'";
    $result = mysqli_query($conn, $query);
    $subscribers = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $subscribers[] = $row;
    }
    return $subscribers;
}



// Fetch featured videos with thumbnails, usernames, and upload time ago
$stmt_featured = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    WHERE v.is_featured = 1
    ORDER BY v.id DESC
    LIMIT 4
");
$stmt_featured->execute();
$result_featured = $stmt_featured->get_result();
$featured_videos = [];
while ($row = $result_featured->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $featured_videos[] = $row;
}
$stmt_featured->close();

// Fetch up to 6 most recent videos with thumbnails, usernames, and upload time ago, sorted by upload time
$stmt_recent = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    WHERE v.is_featured = 0
    ORDER BY v.uploaded_at DESC
    LIMIT 6
");
$stmt_recent->execute();
$result_recent = $stmt_recent->get_result();
$recent_videos = [];
while ($row = $result_recent->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $recent_videos[] = $row;
}
$stmt_recent->close();

// Fetch up to 8 most popular videos with thumbnails, usernames, and upload time ago, sorted by views
$stmt_popular = $conn->prepare("
    SELECT v.id, v.title, v.description, v.filename, v.thumbnail, v.views, v.user_id, u.username, v.uploaded_at,
           TIMESTAMPDIFF(SECOND, v.uploaded_at, NOW()) AS seconds_ago,
           TIMESTAMPDIFF(MINUTE, v.uploaded_at, NOW()) AS minutes_ago,
           TIMESTAMPDIFF(HOUR, v.uploaded_at, NOW()) AS hours_ago,
           TIMESTAMPDIFF(DAY, v.uploaded_at, NOW()) AS days_ago,
           TIMESTAMPDIFF(WEEK, v.uploaded_at, NOW()) AS weeks_ago,
           TIMESTAMPDIFF(MONTH, v.uploaded_at, NOW()) AS months_ago,
           TIMESTAMPDIFF(YEAR, v.uploaded_at, NOW()) AS years_ago
    FROM videos v
    LEFT JOIN users u ON v.user_id = u.id
    ORDER BY v.views DESC
    LIMIT 8
");
$stmt_popular->execute();
$result_popular = $stmt_popular->get_result();
$popular_videos = [];
while ($row = $result_popular->fetch_assoc()) {
    $row['time_ago'] = getTimeAgoString($row);
    $popular_videos[] = $row;
}
$stmt_popular->close();

if (isset($_GET['user_id'])) {
    $userId = $_GET['user_id'];
	$page = 'Channel ' . $userId;
    $user = getUserById($userId, $conn);

    if ($user) {
        // Fetch subscribers
        $subscribers = getSubscribers($userId, $conn);

        // Fetch recent videos
        $videos = getRecentVideosByUserId($userId, $conn);

        // Save the first recent video
        if (!empty($videos)) {
            $firstRecentVideo = reset($videos);

            // Check if 'filename' key exists in $firstRecentVideo array
            if (isset($firstRecentVideo['filename'])) {
                $firstRecentVideoFilename = $firstRecentVideo['filename'];
            } else {
                $firstRecentVideoFilename = 'No filename available';
            }

            // Save the next 4 recent videos
            $nextRecentVideos = array_slice($videos, 1);
        }
    }
}

$supercoolvariable = htmlspecialchars($_GET["user_id"]);


// Close the database connection after all operations
$conn->close();
?>



<!DOCTYPE html><html lang="en" data-cast-api-enabled="true"><head><script>var ytcsi = {gt: function(n) {n = (n || '') + 'data_';return ytcsi[n] || (ytcsi[n] = {tick: {},span: {},info: {}});},tick: function(l, t, n) {ytcsi.gt(n).tick[l] = t || +new Date();},span: function(l, s, n) {ytcsi.gt(n).span[l] = (typeof s == 'number') ? s :+new Date() - ytcsi.data_.tick[l];},info: function(k, v, n) {ytcsi.gt(n).info[k] = v;}};(function() {var perf = window['performance'] || window['mozPerformance'] ||window['msPerformance'] || window['webkitPerformance'];ytcsi.tick('_start', perf ? perf['timing']['responseStart'] : null);})();if (document.webkitVisibilityState == 'prerender') {ytcsi.info('prerender', 1);document.addEventListener('webkitvisibilitychange', function() {ytcsi.tick('_start');}, false);}try {ytcsi.pt_ = (window.chrome && chrome.csi().pageT ||window.gtbExternal && gtbExternal.pageT() ||window.external && external.pageT);if (ytcsi.pt_) {ytcsi.info('pt', Math.floor(ytcsi.pt_));}} catch(e) {}</script>  
  <link id="css-2838365198" class="www-core" rel="stylesheet" href="css/main.css" data-loaded="true">
<link class="www-channels4edit" rel="stylesheet" href="css/channels-extra.css">
<script>if (window.ytcsi) {window.ytcsi.tick("ce", null, '');}</script>  

    <script>
try {var ytbuffer = {};ytbuffer.bufferedClick;ytbuffer.handleClick = function(e) {var element = e.target || e.srcElement;while (element.parentElement) {if (element.className.match(/^yt-can-buffer$|^yt-can-buffer | yt-can-buffer$| yt-can-buffer /)) {ytbuffer.bufferedClick = e;element.className += ' yt-is-buffered';break;}element = element.parentElement;}};if (document.addEventListener) {document.addEventListener('click', ytbuffer.handleClick);} else {document.attachEvent('onclick', ytbuffer.handleClick);}} catch(e) {}  </script>
<title>SigmaVid</title>
<script>if (window.ytcsi) {window.ytcsi.tick("cl", null, '');}</script></head><!-- machid: palZfX2ZGYUViS0hwbGFMVlBQendwdzI3bU9YYzVsVk1ZQkNyVGpZS1VZUWEtME9uZkR2WFZn -->
    <body dir="ltr" class="  ltr        site-left-aligned  hitchhiker-enabled    guide-enabled  guide-expanded  " id="body">
<div id="body-container"><form name="logoutForm" method="POST" action="/logout"><input type="hidden" name="action_logout" value="1"></form>    
<?php include 'header.php'; ?>
    
  <div id="alerts">
      

  </div>
  
<div id="page-container"><div id="page" style="width: 1200px" class="  home     branded-page-v2-masthead-ad-header  clearfix">

<?php include 'guide.php'; ?>

<div id="player" class="  off-screen  ">
  <div id="playlist" class="playlist">
    
  </div>

  <div id="player-unavailable" class="  hid  ">
    
  </div>

    <div id="player-api" class="player-width player-height off-screen-target watch-content player-api"></div>


    <script>if (window.ytcsi) {window.ytcsi.tick("bf", null, '');}</script>
    <script>var ytplayer = ytplayer || {};ytplayer.config = {"attrs": {"id": "movie_player"}, "params": {"bgcolor": "#000000", "allowfullscreen": "true", "allowscriptaccess": "always"}, "assets": {"html": "\/html5_player_template", "css": "\/\/s.ytimg.com\/yts\/cssbin\/www-player-vflzE0TL9.css", "js": "\/\/s.ytimg.com\/yts\/jsbin\/html5player-vfl66X2C5.js"}, "url_v8": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/cps.swf", "url_v9as2": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/cps.swf", "url": "http:\/\/s.ytimg.com\/yts\/swfbin\/player-vfl6Oox_F\/watch_as3.swf", "args": {"enablejsapi": 1, "hl": "", "fexp": "903802,936905,910207,916611,936912,936910,923305,936913,907231", "autoplay": "0", "cr": ""}, "sts": 16031, "min_version": "8.0.0", "html5": false};</script>

  <div id="playlist-tray" class="playlist-tray">
    
  </div>

  <div class="clear"></div>
</div>


<!-- start channel: UC4OacAqWurOCgdxjbgR0W -->
<div id="content" class="" bis_skin_checked="1">  
  <div class="branded-page-v2-container " id="c4-overview-tab" bis_skin_checked="1">
    <div class="branded-page-v2-col-container" bis_skin_checked="1">
      <div class="branded-page-v2-col-container-inner" bis_skin_checked="1">
        <div class="branded-page-v2-primary-col" style="height:auto;border-bottom:none;" bis_skin_checked="1">
              <div class="branded-page-v2-primary-col-header-container branded-page-v2-primary-column-content" bis_skin_checked="1">
    <div class="branded-page-v2-header channel-header " bis_skin_checked="1">
        <div id="gh-banner" bis_skin_checked="1">
          <style>
  #c4-header-bg-container {
    background-image: url(<?php echo $user['banner_art']; ?>);
  }


    @media screen and (-webkit-min-device-pixel-ratio: 1.5),
           screen and (min-resolution: 1.5dppx) {
#c4-header-bg-container {
        background-image: url(<?php echo $user['banner_art']; ?>);
      }
    }

    </style>
  <div id="c4-header-bg-container" class=" has-custom-banner" bis_skin_checked="1">
          <div id="header-links" bis_skin_checked="1">
      <!--<ul class="about-network-links">
      </ul>-->
  </div>

          <a class="channel-header-profile-image-container spf-link" href="/channel.php?user_id=<?php echo $supercoolvariable ?>">
      <img class="channel-header-profile-image" src="<?php echo $user['profile_picture']; ?>" title="3rack$" alt="3rack$">
    </a>


  </div>

    </div>
      
  <div class="" bis_skin_checked="1">
    <div class="primary-header-contents" id="c4-primary-header-contents" bis_skin_checked="1">
      <div class="primary-header-actions clearfix" bis_skin_checked="1">
	<!-- Subscription Button -->
	<span class="channel-header-subscription-button-container yt-uix-button-subscription-container with-preferences">
	    <button type="button" class="yt-uix-subscription-button yt-uix-button yt-uix-button-subscribe-branded yt-uix-button-size-default yt-uix-button-has-icon" aria-role="button" data-channel-external-id="UC4OacAqWurOCgdxjbgR0W" onclick="handleSubscription('<?php echo htmlspecialchars($_GET["user_id"]) ?>', '343491', false)">
		<span class="yt-uix-button-icon-wrapper">
		    <img class="yt-uix-button-icon yt-uix-button-icon-subscribe" src="images/pixel-vfl3z5WfW.gif" alt="">
		</span>
		<span class="yt-uix-button-content">
		    <span class="subscribe-label" aria-label="Subscribe">Subscribe</span>
		    <span class="subscribed-label" aria-label="Unsubscribe">Subscribed</span>
		    <span class="unsubscribe-label" aria-label="Unsubscribe"></span>
		</span>
	    </button>
	    
	    <span class="yt-subscription-button-subscriber-count-branded-horizontal subscribed"><?= htmlspecialchars($user['subscriber_count']) ?></span>  
	</span>
  <script>
    // Function to check and update subscription status
    function checkSubscriptionStatus(channelId) {
        // Replace with your PHP endpoint URL
        const checkUrl = `check_subscription.php`;

        // Data to send via POST to PHP
        const formData = new FormData();
        formData.append('user_id', channelId); // Adjust as per your PHP variable name

        // AJAX request to check subscription status
        fetch(checkUrl, {
            method: 'POST',
            body: formData,
        })
        .then(response => response.text())
        .then(data => {
            // Handle PHP response
            if (data.trim() === 'subscribed') {
                // User is already subscribed, update UI
                updateSubscriptionUI(true);
            } else {
                // User is not subscribed, update UI
                updateSubscriptionUI(false);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Error checking subscription status. Please refresh your page.");
        });
    }

    // Function to handle subscription toggle
    function handleSubscriptionToggle(channelId, isSubscribed) {
        // Replace with your PHP endpoint URL
        const actionUrl = isSubscribed ? 'unsubscribe.php' : 'subscribe.php';

        // Data to send via POST to PHP
        const formData = new FormData();
        formData.append('user_id', channelId); // Adjust as per your PHP variable name

        // AJAX request to handle subscription toggle
        fetch(actionUrl, {
            method: 'POST',
            body: formData,
        })
        .then(response => response.text())
        .then(data => {
            // Handle PHP response
            if (data.startsWith("Error")) {
                alert(data); // Display PHP error message
            } else {
                // Update UI based on new subscription status
                if (isSubscribed) {
                    updateSubscriptionUI(false); // Unsubscribed successfully
                } else {
                    updateSubscriptionUI(true); // Subscribed successfully
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Error toggling subscription. Please refresh your page.");
        });
    }

    // Function to update UI based on subscription status
    function updateSubscriptionUI(isSubscribed) {
        var button = document.querySelector('.yt-uix-subscription-button');
        var subscribeLabel = button.querySelector('.subscribe-label');
        var subscribedLabel = button.querySelector('.subscribed-label');
        var unsubscribeLabel = button.querySelector('.unsubscribe-label');

        if (isSubscribed) {
            // Update UI to 'subscribed' appearance
            button.classList.remove('yt-uix-button-subscribe-branded');
            button.classList.add('yt-uix-button-subscribed-branded');
            subscribeLabel.style.display = 'none';
            subscribedLabel.style.display = 'inline';
            unsubscribeLabel.style.display = 'inline'; // Show unsubscribe option
        } else {
            // Update UI to 'not subscribed' appearance
            button.classList.add('yt-uix-button-subscribe-branded');
            button.classList.remove('yt-uix-button-subscribed-branded');
            subscribeLabel.style.display = 'inline';
            subscribedLabel.style.display = 'none';
            unsubscribeLabel.style.display = 'none'; // Hide unsubscribe option
        }
    }

    // Call checkSubscriptionStatus when the page loads or as needed
    document.addEventListener('DOMContentLoaded', function() {
        const channelId = '<?php echo $supercoolvariable; ?>'; // Replace with actual channelId or fetch dynamically
        checkSubscriptionStatus(channelId);
    });

    // Example usage to handle subscription toggle on button click
    document.querySelector('.yt-uix-subscription-button').addEventListener('click', function() {
        const channelId = '<?php echo $supercoolvariable; ?>'; // Replace with actual channelId
        const button = document.querySelector('.yt-uix-subscription-button');
        const isSubscribed = button.classList.contains('yt-uix-button-subscribed-branded');

        handleSubscriptionToggle(channelId, isSubscribed);
    });
</script>
  <div class="yt-uix-overlay " data-overlay-style="primary" data-overlay-shape="tiny" bis_skin_checked="1">
    
        <div class="yt-dialog hid" bis_skin_checked="1">
    <div class="yt-dialog-base" bis_skin_checked="1">
      <span class="yt-dialog-align"></span>
      <div class="yt-dialog-fg" bis_skin_checked="1">
        <div class="yt-dialog-fg-content" bis_skin_checked="1">
            <div class="yt-dialog-header" bis_skin_checked="1">
                <h2 class="yt-dialog-title">
                        Subscription preferences


                </h2>
            </div>
          <div class="yt-dialog-loading" bis_skin_checked="1">
              <div class="yt-dialog-waiting-content" bis_skin_checked="1">
    <div class="yt-spinner-img" bis_skin_checked="1"></div><div class="yt-dialog-waiting-text" bis_skin_checked="1">Loading...</div>
  </div>

          </div>
          <div class="yt-dialog-content" bis_skin_checked="1">
              <div class="subscription-preferences-overlay-content-container" bis_skin_checked="1">
    <div class="subscription-preferences-overlay-loading " bis_skin_checked="1">
        <p class="yt-spinner">
        <img class="yt-spinner-img" src="images/pixel-vfl3z5WfW.gif" alt="Loading icon" title="">

    <span class="yt-spinner-message">
Loading...
    </span>
  </p>

    </div>
    <div class="subscription-preferences-overlay-content" bis_skin_checked="1">
    </div>
  </div>

          </div>
          <div class="yt-dialog-working" bis_skin_checked="1">
              <div id="yt-dialog-working-overlay" bis_skin_checked="1">
  </div>
  <div id="yt-dialog-working-bubble" bis_skin_checked="1">
    <div class="yt-dialog-waiting-content" bis_skin_checked="1">
      <div class="yt-spinner-img" bis_skin_checked="1"></div><div class="yt-dialog-waiting-text" bis_skin_checked="1">Working...</div>
    </div>
  </div>

          </div>
        </div>
      </div>
    </div>
  </div>
  </div>

      </div>
      <h1 class="branded-page-header-title">
        <a class="spf-link" href="/channel.php?user_id=<?php echo $supercoolvariable ?>">
          <span class="qualified-channel-title ellipsized has-badge" title="3rack$"><span class="qualified-channel-title-wrapper ">  <span class="qualified-channel-title-text">
      <?php echo htmlspecialchars($user['username']); ?>  </span>


</span>      
</span>
<?php
// Check if 'user_id' is set in the $_SESSION array
if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $supercoolvariable): ?>
    <a style="color:black;font-size:12px;" href="profile.php">Edit Profile</a>
<?php else: ?>
    <p></p>
<?php endif; ?>

        </a>
      </h1>
    </div>
      <div id="channel-subheader" class="clearfix branded-page-gutter-padding appbar-content-trigger" bis_skin_checked="1">
    <ul id="channel-navigation-menu" class="clearfix">
        <li>
              <button onclick="location.href='/channel.php?user_id=<?php echo $supercoolvariable ?>';" type="button" class="epic-nav-item-empty selected yt-uix-button yt-uix-button-epic-nav-item yt-uix-button-size-default yt-uix-button-has-icon yt-uix-button-empty" data-button-menu-id="channel-navigation-menu-dropdown" role="button" aria-label="Select view:"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-c4-home" src="images/pixel-vfl3z5WfW.gif" alt="" title=""></span></button>
    <div id="channel-navigation-menu-dropdown" class="hid epic-nav-item-dropdown" bis_skin_checked="1">
  </div>


        </li> 
        <li>
          <a href="/channelvideos.php?user_id=<?php echo $supercoolvariable ?>" class="yt-uix-button   yt-uix-sessionlink yt-uix-button-epic-nav-item yt-uix-button-size-default" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw"><span class="yt-uix-button-content">Videos </span></a>
        </li>
        <!-- <li>
          <a href="/channel/UC4OacAqWurOCgdxjbgR0W/discussion" class="yt-uix-button   yt-uix-sessionlink yt-uix-button-epic-nav-item yt-uix-button-size-default" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw"><span class="yt-uix-button-content">Discussion </span></a>
        </li>                <li>
          <a href="/channel/UC4OacAqWurOCgdxjbgR0W/about" class="yt-uix-button   yt-uix-sessionlink yt-uix-button-epic-nav-item yt-uix-button-size-default" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw"><span class="yt-uix-button-content">About </span></a>
        </li>
        <li>
          <div id="channel-search" bis_skin_checked="1"><label class="show-search epic-nav-item secondary-nav" for="channels-search-field"><img class="epic-nav-item-heading-icon" src="images/pixel-vfl3z5WfW_1.gif" alt="Search Channel"></label><form class="search-form epic-nav-item secondary-nav" action="/channel/UC4OacAqWurOCgdxjbgR0W/search" method="get"><span class=" yt-uix-form-input-container yt-uix-form-input-text-container ">    <input class="yt-uix-form-input-text search-field" name="query" id="channels-search-field" type="text" placeholder="Search Channel" maxlength="100" autocomplete="off">
</span><button onclick=";return true;" type="submit" class="search-button yt-uix-button yt-uix-button-c4-search yt-uix-button-size-default yt-uix-button-has-icon yt-uix-button-empty" role="button"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-search" src="images/pixel-vfl3z5WfW.gif" alt="" title=""></span></button></form></div>
        </li> -->
    </ul>
  </div>

  </div>

  </div>


    </div>
  <div class="branded-page-v2-body branded-page-v2-primary-column-content" id="gh-overviewtab" bis_skin_checked="1">
          
<?php
// Assuming $firstRecentVideo is already defined and contains the data of the most recent video
if (!empty($firstRecentVideo)) {
?>
<!-- start spotlight module -->
<div class="c4-spotlight-module" bis_skin_checked="1">
  <div class="c4-spotlight-module-component upsell" bis_skin_checked="1">
    <div class="upsell-video-container" bis_skin_checked="1">
      <div class="video-player-view-component branded-page-box" bis_skin_checked="1">
        <div class="video-content clearfix" bis_skin_checked="1">
          <div class="c4-player-container c4-flexible-player-container" bis_skin_checked="1">
            <iframe height="250px" width="100%" src="/player/embed.php?video=<?php echo $firstRecentVideo['filename']; ?>&width=465&height=250" bis_size="{"x":256,"y":366,"w":450,"h":200,"abs_x":256,"abs_y":366}" bis_id="fr_zzp1twq7tei6tdm3d1vb8w" bis_depth="0" bis_chainid="1"></iframe>
          </div>
          <div class="video-detail" bis_skin_checked="1">
            <h3 class="title">
              <a href="/watch?id=<?php echo $firstRecentVideo['id']; ?>" title="3rack$" class="yt-uix-sessionlink yt-ui-ellipsis yt-ui-ellipsis-2" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&amp;feature=c4-overview">
                <span class="yt-ui-ellipsis-wrapper"><?php echo htmlspecialchars($firstRecentVideo['title']); ?></span>
              </a>
            </h3>
            <div class="view-count" bis_skin_checked="1">
              <span class="count">
                <?php echo $firstRecentVideo['views']; ?>
              </span>
              views
              <span class="content-item-time-created"><?php echo timeAgo($firstRecentVideo['uploaded_at']); ?></span>
            </div>
            <div class="description yt-uix-expander yt-uix-expander-collapsed" bis_skin_checked="1">
              <div class="yt-uix-expander-collapsed-body" bis_skin_checked="1">
                <div class="collapsed-description yt-ui-ellipsis yt-ui-ellipsis-ellipsized" data-max-lines="10" bis_skin_checked="1">
                  <span class="yt-ui-ellipsis-wrapper"><?php echo htmlspecialchars($firstRecentVideo['description']); ?></span>
                </div>
              </div>
            </div>
          </div>
          <div class="video-content-info" bis_skin_checked="1"></div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- end spotlight module -->
<?php
}
?>

      <div id="c4-shelves-container" class="context-data-container" bis_skin_checked="1">
        
          <div class="compact-shelf shelf-item yt-uix-shelfslider yt-uix-shelfslider-at-head vve-check clearfix branded-page-box fluid-shelf yt-uix-tdl" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&amp;ved=CEQQ3BwoAA" bis_skin_checked="1" data-fold="1062,966.890625">
            <h2 class="branded-page-module-title">
      <a href="/channel/UC4OacAqWurOCgdxjbgR0W/videos?sort=dd&amp;view=0&amp;shelf_id=1" class="yt-uix-sessionlink branded-page-module-title-link spf-nolink" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw">
            <span class="">Recent uploads</span>

      </a>

  </h2>


    

      <div class="yt-uix-shelfslider-body context-data-container" bis_skin_checked="1">
    <ul class="yt-uix-shelfslider-list">
                    <?php foreach ($nextRecentVideos as $video): ?>
        <li class="channels-content-item yt-shelf-grid-item yt-uix-shelfslider-item ">
    <div class="yt-lockup clearfix  yt-lockup-video yt-lockup-grid vve-check context-data-item" data-context-item-id="10883" data-context-item-type="video" data-context-item-views="13 views"  data-context-item-user="3rack$" data-context-item-time="6:55" bis_skin_checked="1">
    <div class="yt-lockup-thumbnail" bis_skin_checked="1">
      
  <a href="/watch?id=<?php echo htmlspecialchars($video['id'])?>" class="ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink yt-fluid-thumb-link contains-addto " data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&amp;ved=CEYQwBs&amp;feature=c4-overview-u">    <span class="video-thumb  yt-thumb yt-thumb-185 yt-thumb-fluid">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="<?php echo $video['thumbnail']; ?>" width="185">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


  <button onclick=";return false;" type="button" title="Watch Later" class="addto-button video-actions spf-nolink hide-until-delayloaded addto-watch-later-button-sign-in yt-uix-button yt-uix-button-default yt-uix-button-size-small yt-uix-tooltip" data-video-ids="10883" data-button-menu-id="shared-addto-watch-later-login" role="button"><span class="yt-uix-button-content">  <img src="images/pixel-vfl3z5WfW.gif" alt="Watch Later">
 </span><img class="yt-uix-button-arrow" src="images/pixel-vfl3z5WfW.gif" alt="" title=""></button>
</a>

    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
            <h3 class="yt-lockup-title">
    <a class="yt-uix-sessionlink yt-uix-tile-link yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" title="Startup | Windows Trap Beat (Produced By Skelebro Aka 3racks)" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&amp;ved=CEcQvxs&amp;feature=c4-overview-u" href="/watch?id=<?php echo htmlspecialchars($video['id'])?>"><span class="yt-ui-ellipsis-wrapper" ><?php echo htmlspecialchars($video['title']); ?>    </span></a>
  </h3>


  <div class="yt-lockup-meta" bis_skin_checked="1">
    <ul class="yt-lockup-meta-info">
      <li><?php echo $video['views']; ?> views</li>
        <li class="yt-lockup-deemphasized-text">
            <?php echo timeAgo($video['uploaded_at']); ?>        </li>
    </ul>
  </div>
  
  

    </div>
    
  </div>



        </li>
                    <?php endforeach; ?>
            </ul>
  </div>



  </div>

<!--
          <div class="compact-shelf shelf-item yt-uix-shelfslider yt-uix-shelfslider-at-head vve-check clearfix branded-page-box fluid-shelf yt-uix-tdl" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CMICENwcKAY" bis_skin_checked="1" data-fold="1062,2446.609375">
            <h2 class="branded-page-module-title">
      <a href="/channel/UC4OacAqWurOCgdxjbgR0W/videos?sort=dd&view=1&shelf_id=7" class="yt-uix-sessionlink branded-page-module-title-link spf-nolink" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw">
            <span class="">Playlists</span>

      </a>
  </h2>


    

      <div class="yt-uix-shelfslider-body context-data-container" bis_skin_checked="1">
    <ul class="yt-uix-shelfslider-list">

        <li class="channels-content-item yt-shelf-grid-item yt-uix-shelfslider-item ">
              


    <div class="yt-lockup clearfix  yt-lockup-playlist yt-lockup-grid vve-check context-data-item" data-context-item-id="PL084D12E08B9F7614" data-context-item-count="7" data-context-item-count-label="videos" data-context-item-videos="["g2sZSm9JcdY", "w-x9V-pVBOs", "s8qZKOPv39Q", "HrH1RYzTBwU", "G3EeGUn4b7Y"]" data-context-item-type="playlist" data-context-item-title="How-To Videos" data-context-item-user="3rack$" bis_skin_checked="1">
    <div class="yt-lockup-thumbnail" bis_skin_checked="1">
            <a href="/watch?v=G3EeGUn4b7Y&list=PL084D12E08B9F7614" class="yt-pl-thumb-link yt-uix-sessionlink " data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CMUCEMAb&feature=c4-overview">
      <span class="yt-pl-thumb  yt-pl-thumb-fluid">
                <span class="video-thumb  yt-thumb yt-thumb-185 yt-thumb-fluid">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/g2sZSm9JcdY/mqdefault.jpg" width="185">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>



    <span class="sidebar">
      <span class="video-count-wrapper yt-valign">
        <span class="video-count-block yt-valign-container">
          <span class="count-label">
            7
          </span>
          <span class="text-label">
            videos
          </span>
        </span>
      </span>
      <span class="side-thumbs yt-uix-tdl" data-fold="444,2368.203125">
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/w-x9V-pVBOs/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/s8qZKOPv39Q/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/HrH1RYzTBwU/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/G3EeGUn4b7Y/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
      </span>
    </span>
      <span class="yt-pl-thumb-overlay">
        <span class="yt-pl-thumb-overlay-content">
          <img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="">
Play all
        </span>
      </span>
  </span>

  </a>


    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
          <h3 class="yt-lockup-title">
    <a class="yt-uix-sessionlink yt-uix-tile-link yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" title="How-To Videos" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CMYCEL8b" href="/playlist?list=PL084D12E08B9F7614"><span class="yt-ui-ellipsis-wrapper" data-original-html="How-To Videos
    ">How-To Videos
    </span></a>
  </h3>

  <div class="yt-lockup-meta" bis_skin_checked="1">
    <ul class="yt-lockup-meta-info">

    </ul>
    <ul class="yt-lockup-meta-info">
        <li>
          7 videos
        </li>
        <li class="yt-lockup-deemphasized-text">
          1 year ago
        </li>
    </ul>
  </div>

    </div>
    
  </div>



        </li>

        <li class="channels-content-item yt-shelf-grid-item yt-uix-shelfslider-item ">
              


    <div class="yt-lockup clearfix  yt-lockup-playlist yt-lockup-grid vve-check context-data-item" data-context-item-id="PL475D75813E9C76E5" data-context-item-count="19" data-context-item-count-label="videos" data-context-item-videos="["mO1QBTG6EXs", "uxxPlbT8RaA", "DNTzKHkxki8", "3IaMyYw4tJw", "MS_NKaKnYnA"]" data-context-item-type="playlist" data-context-item-title="Gaming Related Videos" data-context-item-user="3rack$" bis_skin_checked="1">
    <div class="yt-lockup-thumbnail" bis_skin_checked="1">
            <a href="/watch?v=uxxPlbT8RaA&list=PL475D75813E9C76E5" class="yt-pl-thumb-link yt-uix-sessionlink " data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CMkCEMAb&feature=c4-overview">
      <span class="yt-pl-thumb  yt-pl-thumb-fluid">
                <span class="video-thumb  yt-thumb yt-thumb-185 yt-thumb-fluid">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/mO1QBTG6EXs/mqdefault.jpg" width="185">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>



    <span class="sidebar">
      <span class="video-count-wrapper yt-valign">
        <span class="video-count-block yt-valign-container">
          <span class="count-label">
            19
          </span>
          <span class="text-label">
            videos
          </span>
        </span>
      </span>
      <span class="side-thumbs yt-uix-tdl" data-fold="640,2368.203125">
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/uxxPlbT8RaA/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/DNTzKHkxki8/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/3IaMyYw4tJw/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/MS_NKaKnYnA/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
      </span>
    </span>
      <span class="yt-pl-thumb-overlay">
        <span class="yt-pl-thumb-overlay-content">
          <img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="">
Play all
        </span>
      </span>
  </span>

  </a>


    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
          <h3 class="yt-lockup-title">
    <a class="yt-uix-sessionlink yt-uix-tile-link yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" title="Gaming Related Videos" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CMoCEL8b" href="/playlist?list=PL475D75813E9C76E5"><span class="yt-ui-ellipsis-wrapper" data-original-html="Gaming Related Videos
    ">Gaming Related Videos
    </span></a>
  </h3>

  <div class="yt-lockup-meta" bis_skin_checked="1">
    <ul class="yt-lockup-meta-info">

    </ul>
    <ul class="yt-lockup-meta-info">
        <li>
          19 videos
        </li>
        <li class="yt-lockup-deemphasized-text">
          2 years ago
        </li>
    </ul>
  </div>

    </div>
    
  </div>



        </li>

        <li class="channels-content-item yt-shelf-grid-item yt-uix-shelfslider-item ">
              


    <div class="yt-lockup clearfix  yt-lockup-playlist yt-lockup-grid vve-check context-data-item" data-context-item-id="PL2C924BB1F9863B0A" data-context-item-count="10" data-context-item-count-label="videos" data-context-item-videos="["e1h5TzdTq0o", "LfoGBVM86PM", "rBD7XVvJ02s", "wzy9D_YKxso", "APV5LnQvqFw"]" data-context-item-type="playlist" data-context-item-title="Pokemon Videos" data-context-item-user="3rack$" bis_skin_checked="1">
    <div class="yt-lockup-thumbnail" bis_skin_checked="1">
            <a href="/watch?v=e1h5TzdTq0o&list=PL2C924BB1F9863B0A" class="yt-pl-thumb-link yt-uix-sessionlink " data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CM0CEMAb&feature=c4-overview">
      <span class="yt-pl-thumb  yt-pl-thumb-fluid">
                <span class="video-thumb  yt-thumb yt-thumb-185 yt-thumb-fluid">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/e1h5TzdTq0o/mqdefault.jpg" width="185">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>



    <span class="sidebar">
      <span class="video-count-wrapper yt-valign">
        <span class="video-count-block yt-valign-container">
          <span class="count-label">
            10
          </span>
          <span class="text-label">
            videos
          </span>
        </span>
      </span>
      <span class="side-thumbs yt-uix-tdl" data-fold="836,2368.203125">
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/LfoGBVM86PM/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/rBD7XVvJ02s/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/wzy9D_YKxso/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/APV5LnQvqFw/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
      </span>
    </span>
      <span class="yt-pl-thumb-overlay">
        <span class="yt-pl-thumb-overlay-content">
          <img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="">
Play all
        </span>
      </span>
  </span>

  </a>


    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
          <h3 class="yt-lockup-title">
    <a class="yt-uix-sessionlink yt-uix-tile-link yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" title="Pokemon Videos" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CM4CEL8b" href="/playlist?list=PL2C924BB1F9863B0A"><span class="yt-ui-ellipsis-wrapper" data-original-html="Pokemon Videos
    ">Pokemon Videos
    </span></a>
  </h3>

  <div class="yt-lockup-meta" bis_skin_checked="1">
    <ul class="yt-lockup-meta-info">

    </ul>
    <ul class="yt-lockup-meta-info">
        <li>
          10 videos
        </li>
        <li class="yt-lockup-deemphasized-text">
          2 years ago
        </li>
    </ul>
  </div>

    </div>
    
  </div>



        </li>

        <li class="channels-content-item yt-shelf-grid-item yt-uix-shelfslider-item ">
              


    <div class="yt-lockup clearfix  yt-lockup-playlist yt-lockup-grid vve-check context-data-item" data-context-item-id="PL0929612B0EB32178" data-context-item-count="11" data-context-item-count-label="videos" data-context-item-videos="["APV5LnQvqFw", "r8PAYm5GUMg", "Z-xiNaTXZV8", "cO2DSl6opEg", "-D_xPnq6onE"]" data-context-item-type="playlist" data-context-item-title="If [blank] Were Real" data-context-item-user="3rack$" bis_skin_checked="1">
    <div class="yt-lockup-thumbnail" bis_skin_checked="1">
            <a href="/watch?v=dLGvKxkUSmk&list=PL0929612B0EB32178" class="yt-pl-thumb-link yt-uix-sessionlink " data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CNICEMAb&feature=c4-overview">
      <span class="yt-pl-thumb  yt-pl-thumb-fluid">
                <span class="video-thumb  yt-thumb yt-thumb-185 yt-thumb-fluid">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/APV5LnQvqFw/mqdefault.jpg" width="185">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>



    <span class="sidebar">
      <span class="video-count-wrapper yt-valign">
        <span class="video-count-block yt-valign-container">
          <span class="count-label">
            11
          </span>
          <span class="text-label">
            videos
          </span>
        </span>
      </span>
      <span class="side-thumbs yt-uix-tdl" data-fold="1032,2368.203125">
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/r8PAYm5GUMg/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/Z-xiNaTXZV8/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/cO2DSl6opEg/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/-D_xPnq6onE/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
      </span>
    </span>
      <span class="yt-pl-thumb-overlay">
        <span class="yt-pl-thumb-overlay-content">
          <img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="">
Play all
        </span>
      </span>
  </span>

  </a>


    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
          <h3 class="yt-lockup-title">
    <a class="yt-uix-sessionlink yt-uix-tile-link yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" title="If [blank] Were Real" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CNECEL8b" href="/playlist?list=PL0929612B0EB32178"><span class="yt-ui-ellipsis-wrapper" data-original-html="If [blank] Were Real
    ">If [blank] Were Real
    </span></a>
  </h3>

  <div class="yt-lockup-meta" bis_skin_checked="1">
    <ul class="yt-lockup-meta-info">

    </ul>
    <ul class="yt-lockup-meta-info">
        <li>
          11 videos
        </li>
        <li class="yt-lockup-deemphasized-text">
          2 years ago
        </li>
    </ul>
  </div>

    </div>
    
  </div>



        </li>

        <li class="channels-content-item yt-shelf-grid-item yt-uix-shelfslider-item ">
              


    <div class="yt-lockup clearfix  yt-lockup-playlist yt-lockup-grid vve-check context-data-item" data-context-item-id="PL21A272CC1406CF4A" data-context-item-count="24" data-context-item-count-label="videos" data-context-item-videos="["CqGB11V0yYg", "2xHKsp51q1I", "7xg48eBUkDw", "7IrfOYp2Bn4", "12PWq22E9CQ"]" data-context-item-type="playlist" data-context-item-title="Music Videos" data-context-item-user="3rack$" bis_skin_checked="1">
    <div class="yt-lockup-thumbnail" bis_skin_checked="1">
            <a href="/watch?v=WpMt2vzrIxs&list=PL21A272CC1406CF4A" class="yt-pl-thumb-link yt-uix-sessionlink " data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CNYCEMAb&feature=c4-overview">
      <span class="yt-pl-thumb  yt-pl-thumb-fluid">
                <span class="video-thumb  yt-thumb yt-thumb-185 yt-thumb-fluid">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/CqGB11V0yYg/mqdefault.jpg" width="185">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>



    <span class="sidebar">
      <span class="video-count-wrapper yt-valign">
        <span class="video-count-block yt-valign-container">
          <span class="count-label">
            24
          </span>
          <span class="text-label">
            videos
          </span>
        </span>
      </span>
      <span class="side-thumbs yt-uix-tdl" data-fold="1062,2368.203125">
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/2xHKsp51q1I/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/7xg48eBUkDw/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/7IrfOYp2Bn4/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/12PWq22E9CQ/default.jpg" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
      </span>
    </span>
      <span class="yt-pl-thumb-overlay">
        <span class="yt-pl-thumb-overlay-content">
          <img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="">
Play all
        </span>
      </span>
  </span>

  </a>


    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
          <h3 class="yt-lockup-title">
    <a class="yt-uix-sessionlink yt-uix-tile-link yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" title="Music Videos" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CNUCEL8b" href="/playlist?list=PL21A272CC1406CF4A"><span class="yt-ui-ellipsis-wrapper" data-original-html="Music Videos
    ">Music Videos
    </span></a>
  </h3>

  <div class="yt-lockup-meta" bis_skin_checked="1">
    <ul class="yt-lockup-meta-info">

    </ul>
    <ul class="yt-lockup-meta-info">
        <li>
          24 videos
        </li>
        <li class="yt-lockup-deemphasized-text">
          2 years ago
        </li>
    </ul>
  </div>

    </div>
    
  </div>



        </li>

        <li class="channels-content-item yt-shelf-grid-item yt-uix-shelfslider-item ">
              


    <div class="yt-lockup clearfix  yt-lockup-playlist yt-lockup-grid vve-check context-data-item" data-context-item-id="SP8A3B1C53A51D29A8" data-context-item-count="4" data-context-item-count-label="videos" data-context-item-videos="["agEjzQLiuGA", "6D9p-wmtIJc", "ut5fFyTkKv4", "cvHeVdlZQPs"]" data-context-item-type="playlist" data-context-item-title="Theme songs" data-context-item-user="3rack$" bis_skin_checked="1">
    <div class="yt-lockup-thumbnail" bis_skin_checked="1">
            <a href="/watch?v=agEjzQLiuGA&list=SP8A3B1C53A51D29A8" class="yt-pl-thumb-link yt-uix-sessionlink " data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CNkCEMAb&feature=c4-overview">
      <span class="yt-pl-thumb  yt-pl-thumb-fluid">
                <span class="video-thumb  yt-thumb yt-thumb-185 yt-thumb-fluid">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" src="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/agEjzQLiuGA/mqdefault.jpg" width="185">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>



    <span class="sidebar">
      <span class="video-count-wrapper yt-valign">
        <span class="video-count-block yt-valign-container">
          <span class="count-label">
            4
          </span>
          <span class="text-label">
            videos
          </span>
        </span>
      </span>
      <span class="side-thumbs yt-uix-tdl" data-fold="1062,2368.203125">
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/6D9p-wmtIJc/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/ut5fFyTkKv4/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/cvHeVdlZQPs/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
      </span>
    </span>
      <span class="yt-pl-thumb-overlay">
        <span class="yt-pl-thumb-overlay-content">
          <img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="">
Play all
        </span>
      </span>
  </span>

  </a>


    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
          <h3 class="yt-lockup-title">
    <a class="yt-uix-sessionlink yt-uix-tile-link yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" title="Theme songs" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CNoCEL8b" href="/playlist?list=PL8A3B1C53A51D29A8"><span class="yt-ui-ellipsis-wrapper" data-original-html="Theme songs
    ">Theme songs
    </span></a>
  </h3>

  <div class="yt-lockup-meta" bis_skin_checked="1">
    <ul class="yt-lockup-meta-info">

    </ul>
    <ul class="yt-lockup-meta-info">
        <li>
          4 videos
        </li>
        <li class="yt-lockup-deemphasized-text">
          3 years ago
        </li>
    </ul>
  </div>

    </div>
    
  </div>



        </li>

        <li class="channels-content-item yt-shelf-grid-item yt-uix-shelfslider-item ">
              


    <div class="yt-lockup clearfix  yt-lockup-playlist yt-lockup-grid vve-check context-data-item" data-context-item-id="SPA02DB6C66045CDF1" data-context-item-count="200" data-context-item-count-label="videos" data-context-item-videos="["LfoGBVM86PM", "PfpOJ3QXq7E", "HrH1RYzTBwU", "jDhYU2ps2ys", "1urxclRYqV8"]" data-context-item-type="playlist" data-context-item-title="3rack$" data-context-item-user="3rack$" bis_skin_checked="1">
    <div class="yt-lockup-thumbnail" bis_skin_checked="1">
            <a href="/watch?v=LfoGBVM86PM&list=SPA02DB6C66045CDF1" class="yt-pl-thumb-link yt-uix-sessionlink " data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CN0CEMAb&feature=c4-overview">
      <span class="yt-pl-thumb  yt-pl-thumb-fluid">
                <span class="video-thumb  yt-thumb yt-thumb-185 yt-thumb-fluid">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/LfoGBVM86PM/mqdefault.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="185">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>



    <span class="sidebar">
      <span class="video-count-wrapper yt-valign">
        <span class="video-count-block yt-valign-container">
          <span class="count-label">
            200
          </span>
          <span class="text-label">
            videos
          </span>
        </span>
      </span>
      <span class="side-thumbs yt-uix-tdl" data-fold="1062,2368.203125">
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/PfpOJ3QXq7E/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/HrH1RYzTBwU/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/jDhYU2ps2ys/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/1urxclRYqV8/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
      </span>
    </span>
      <span class="yt-pl-thumb-overlay">
        <span class="yt-pl-thumb-overlay-content">
          <img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="">
Play all
        </span>
      </span>
  </span>

  </a>


    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
          <h3 class="yt-lockup-title">
    <a class="yt-uix-sessionlink yt-uix-tile-link yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" title="3rack$" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CN4CEL8b" href="/playlist?list=PLA02DB6C66045CDF1"><span class="yt-ui-ellipsis-wrapper" data-original-html="3rack$    ">3rack$    </span></a>
  </h3>

  <div class="yt-lockup-meta" bis_skin_checked="1">
    <ul class="yt-lockup-meta-info">

    </ul>
    <ul class="yt-lockup-meta-info">
        <li>
          200 videos
        </li>
        <li class="yt-lockup-deemphasized-text">
          3 years ago
        </li>
    </ul>
  </div>

    </div>
    
  </div>



        </li>

        <li class="channels-content-item yt-shelf-grid-item yt-uix-shelfslider-item ">
              


    <div class="yt-lockup clearfix  yt-lockup-playlist yt-lockup-grid vve-check context-data-item" data-context-item-id="PL4569F63F2FF0357B" data-context-item-count="8" data-context-item-count-label="videos" data-context-item-videos="["bJXKkxE1Ri0", "R8Qtft2lAfU", "Y-SJ-4uqmUU", "xRxkj0efDJE", "s0MmvxvOomU"]" data-context-item-type="playlist" data-context-item-title="Food Battle" data-context-item-user="3rack$" bis_skin_checked="1">
    <div class="yt-lockup-thumbnail" bis_skin_checked="1">
            <a href="/watch?v=yFGBjXqwzbw&list=PL4569F63F2FF0357B" class="yt-pl-thumb-link yt-uix-sessionlink " data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=COECEMAb&feature=c4-overview">
      <span class="yt-pl-thumb  yt-pl-thumb-fluid">
                <span class="video-thumb  yt-thumb yt-thumb-185 yt-thumb-fluid">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/bJXKkxE1Ri0/mqdefault.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="185">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>



    <span class="sidebar">
      <span class="video-count-wrapper yt-valign">
        <span class="video-count-block yt-valign-container">
          <span class="count-label">
            8
          </span>
          <span class="text-label">
            videos
          </span>
        </span>
      </span>
      <span class="side-thumbs yt-uix-tdl" data-fold="1062,2368.203125">
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/R8Qtft2lAfU/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb ">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/Y-SJ-4uqmUU/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/xRxkj0efDJE/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
          <span class="sidethumb  columns-support-required">
                      <span class="video-thumb  yt-thumb yt-thumb-43">
      <span class="yt-thumb-default">
        <span class="yt-thumb-clip">
          <img alt="Thumbnail" data-thumb="//web.archive.org/web/20131205044335/http://i1.ytimg.com/vi/s0MmvxvOomU/default.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="43">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>


          </span>
      </span>
    </span>
      <span class="yt-pl-thumb-overlay">
        <span class="yt-pl-thumb-overlay-content">
          <img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="">
Play all
        </span>
      </span>
  </span>

  </a>


    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
          <h3 class="yt-lockup-title">
    <a class="yt-uix-sessionlink yt-uix-tile-link yt-ui-ellipsis yt-ui-ellipsis-2" dir="ltr" title="Food Battle" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=COICEL8b" href="/playlist?list=PL4569F63F2FF0357B"><span class="yt-ui-ellipsis-wrapper" data-original-html="Food Battle
    ">Food Battle
    </span></a>
  </h3>

  <div class="yt-lockup-meta" bis_skin_checked="1">
    <ul class="yt-lockup-meta-info">

    </ul>
    <ul class="yt-lockup-meta-info">
        <li>
          8 videos
        </li>
        <li class="yt-lockup-deemphasized-text">
          5 years ago
        </li>
    </ul>
  </div>

    </div>
    
  </div>



        </li>
    </ul>
  </div>



  </div>



    </div>



-->
    <img class="hid" src="https://ad.doubleclick.net/activity;src=2542116;type=youtu444;cat=youtu714;ord=1" border="0" width="1" height="1">

    <img class="hid" src="//web.archive.org/web/20131205044335im_/http://googleads.g.doubleclick.net/pagead/viewthroughconversion/962985656/?data=type%3Dcview%3Butuid%3DY30JRSgfhYXA6i6xX1erWg&amp;label=default" border="0" width="1" height="1">

        


  <div id="ad_creative_1" class="ad-div hid" style="z-index: 1" bis_skin_checked="1">


  </div>


  </div>

        </div>

          <!--<div class="branded-page-v2-secondary-col" bis_skin_checked="1">
            

        <div class="branded-page-related-channels branded-page-box " bis_skin_checked="1">
            <h2 class="branded-page-related-channels-title" dir="ltr">
        <a href="/channel/UC4OacAqWurOCgdxjbgR0W/about">Featured channels</a>
    </h2>

        <ul class="branded-page-related-channels-list">
        <li class="branded-page-related-channels-item spf-nolink clearfix" data-external-id="UCXdYATEcQDVlMdUs7THtzXA">



    <a class="yt-lockup clearfix  yt-lockup-channel yt-lockup-mini vve-check yt-uix-sessionlink" href="/user/ShutUpCartoons" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CDoQ9BwoCA&feature=rc-feat">
    <div class="yt-lockup-thumbnail" style="width: 34px;" bis_skin_checked="1">
          <span class="video-thumb  yt-thumb yt-thumb-34">
      <span class="yt-thumb-square">
        <span class="yt-thumb-clip">
          <img alt="Shut Up! Cartoons" data-thumb="https://web.archive.org/web/20131205044335/https://lh6.googleusercontent.com/-hPeBepXIji0/AAAAAAAAAAI/AAAAAAAAAAA/JbMIcHEtXos/s88-c-k-no/photo.jpg" src="https://lh6.googleusercontent.com/-hPeBepXIji0/AAAAAAAAAAI/AAAAAAAAAAA/JbMIcHEtXos/s88-c-k-no/photo.jpg" width="34" data-group-key="thumb-group-0">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>

    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
        <h3 class="yt-lockup-title">
    <span class="qualified-channel-title ellipsized has-badge"><span class="qualified-channel-title-wrapper  g-hovercard" data-ytid="UC-T_EdQ6MTufAWnFXa7dnYw" data-name="rc-feat">  <span class="qualified-channel-title-text">
      Shut Up! Cartoons
  </span>
</span>      <span class="qualified-channel-title-badge">
<img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" class="yt-uix-tooltip yt-channel-title-icon-verified" alt="" title="Verified">  </span>

</span>
  </h3>
  <div class="yt-lockup-meta" bis_skin_checked="1">
      <span class=" yt-uix-button-subscription-container"><button aria-busy="false" aria-live="polite" title="1,318,192 subscribers" class="yt-uix-subscription-button yt-uix-hovercard yt-uix-button yt-uix-button-subscribe-unbranded yt-uix-button-size-default yt-uix-button-has-icon yt-uix-tooltip" onclick=";return false;" type="button" aria-role="button" data-subscriber-count-tooltip="True" data-href="https://accounts.google.com/ServiceLogin?passive=true&continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26continue_action%3DQUFFLUhqbDF6MUlQZWRlRFlUNXNLckNoY0NIX1Q0R0Fzd3xBQ3Jtc0tuRjhGZzJsZVVvdW9OWnJwelNia1NlX0NfczJScE9UaldUcEU3TU5KY0h0SlY1QlpQLXdIOHQxVTR6ai1SMy1wNUxaai1Ga3JoWWhyNlNHM1RnX3g4cXRqa2U4TGVXdTVLV05CT2xMa2d5MVphVG5vV25fQkhwazhZSHQ2Q2VuNU5CNVFhZ3NkdDlnbkkydzBWT3o3OGRGcjA2VElCeGpJaWVHVmFYWktBam1OQUZvUTVOQjBuVWg1WE05a3hSazBMcjYtelM%253D%26feature%3Dsubscribe%26hl%3Den%26next%3D%252Fchannel%252FUC-T_EdQ6MTufAWnFXa7dnYw&service=youtube&uilel=3&hl=en" data-style-type="unbranded" data-channel-external-id="UC-T_EdQ6MTufAWnFXa7dnYw" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CD0QmysoAg&feature=rc-feat" data-subscriber-count-title="1,318,192 subscribers" role="button"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-subscribe" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="1,318,192 subscribers" title=""></span><span class="yt-uix-button-content"><span class="subscribe-label" aria-label="Subscribe">Subscribe</span><span class="subscribed-label" aria-label="Unsubscribe">Subscribed</span><span class="unsubscribe-label" aria-label="Unsubscribe">Unsubscribe</span> </span></button>  <span class="yt-subscription-button-disabled-mask" title=""></span>
</span>
  </div>

    </div>
    
  </a>


  </li>

  </ul>
  
    </div>


        <div class="branded-page-related-channels branded-page-box " bis_skin_checked="1">
            <h2 class="branded-page-related-channels-title yt-uix-tooltip" data-tooltip-text="These recommendations have been automatically generated by YouTube." dir="ltr">
        Related channels on YouTube
    </h2>

        <ul class="branded-page-related-channels-list">
        <li class="branded-page-related-channels-item spf-nolink clearfix" data-external-id="UC9gFih9rw0zNCK3ZtoKQQyA">
    




    <a class="yt-lockup clearfix  yt-lockup-channel yt-lockup-mini vve-check yt-uix-sessionlink" href="/user/JennaMarbles" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CAUQ9BwoAA&feature=rc-rel">
    <div class="yt-lockup-thumbnail" style="width: 34px;" bis_skin_checked="1">
          <span class="video-thumb  yt-thumb yt-thumb-34">
      <span class="yt-thumb-square">
        <span class="yt-thumb-clip">
          <img alt="JennaMarbles" data-thumb="https://web.archive.org/web/20131205044335/https://lh3.googleusercontent.com/-34FbM3JM5Ck/AAAAAAAAAAI/AAAAAAAAAAA/qVlymUN44C8/s88-c-k-no/photo.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="34" data-group-key="thumb-group-1">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>

    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
        <h3 class="yt-lockup-title">
    <span class="qualified-channel-title ellipsized has-badge"><span class="qualified-channel-title-wrapper  g-hovercard" data-ytid="UC9gFih9rw0zNCK3ZtoKQQyA" data-name="rc-rel">  <span class="qualified-channel-title-text">
      JennaMarbles
  </span>
</span>      <span class="qualified-channel-title-badge">
<img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" class="yt-uix-tooltip yt-channel-title-icon-verified" alt="" title="Verified">  </span>

</span>
  </h3>
  <div class="yt-lockup-meta" bis_skin_checked="1">
      <span class=" yt-uix-button-subscription-container"><button aria-busy="false" aria-live="polite" title="11,539,275 subscribers" class="yt-uix-subscription-button yt-uix-hovercard yt-uix-button yt-uix-button-subscribe-unbranded yt-uix-button-size-default yt-uix-button-has-icon yt-uix-tooltip" onclick=";return false;" type="button" aria-role="button" data-subscriber-count-tooltip="True" data-href="https://accounts.google.com/ServiceLogin?passive=true&continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26continue_action%3DQUFFLUhqbU1kSHJMcllPTUdDeDI2QnFzdGtYSmNCQy02QXxBQ3Jtc0trQzA2U2VxU1oxU24zeDJJd3ZieVAtaUY5WkswbDN1TUQzYVFMaWxwdjBNeEpfTkN1SWt6WHd1TkczbnJTYlRsRjBseV9JYi1xODlmMlg3OEdpVE4xNFBXNkprZmxmWFlMYUhFY3RuVVJwbTM3ZkhoVk9oRk5xTzFqX1VXLUp1TjR2VEViRVlyQ0h0VmtxYmdmaXFNRWdsQ0hTZi1xaWhPZVZ2U0UwZ0U1WXl2NXU4V0dlYjZJNHc5WTZJdDBQeEdRSDFEbkg%253D%26feature%3Dsubscribe%26hl%3Den%26next%3D%252Fchannel%252FUC9gFih9rw0zNCK3ZtoKQQyA&service=youtube&uilel=3&hl=en" data-style-type="unbranded" data-channel-external-id="UC9gFih9rw0zNCK3ZtoKQQyA" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CAgQmysoAg&feature=rc-rel" data-subscriber-count-title="11,539,275 subscribers" role="button"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-subscribe" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="11,539,275 subscribers" title=""></span><span class="yt-uix-button-content"><span class="subscribe-label" aria-label="Subscribe">Subscribe</span><span class="subscribed-label" aria-label="Unsubscribe">Subscribed</span><span class="unsubscribe-label" aria-label="Unsubscribe">Unsubscribe</span> </span></button>  <span class="yt-subscription-button-disabled-mask" title=""></span>
</span>
  </div>

    </div>
    
  </a>


  </li>

        <li class="branded-page-related-channels-item spf-nolink clearfix" data-external-id="UCGt7X90Au6BV8rf49BiM6Dg">
    




    <a class="yt-lockup clearfix  yt-lockup-channel yt-lockup-mini vve-check yt-uix-sessionlink" href="/user/RayWilliamJohnson" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CAkQ9BwoAQ&feature=rc-rel">
    <div class="yt-lockup-thumbnail" style="width: 34px;" bis_skin_checked="1">
          <span class="video-thumb  yt-thumb yt-thumb-34">
      <span class="yt-thumb-square">
        <span class="yt-thumb-clip">
          <img alt="RayWilliamJohnson" data-thumb="https://web.archive.org/web/20131205044335/https://lh3.googleusercontent.com/-hRXKieB44W8/AAAAAAAAAAI/AAAAAAAAAAA/wgjphzDvYw8/s88-c-k-no/photo.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="34" data-group-key="thumb-group-1">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>

    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
        <h3 class="yt-lockup-title">
    <span class="qualified-channel-title ellipsized has-badge"><span class="qualified-channel-title-wrapper  g-hovercard" data-ytid="UCGt7X90Au6BV8rf49BiM6Dg" data-name="rc-rel">  <span class="qualified-channel-title-text">
      RayWilliamJohnson
  </span>
</span>      <span class="qualified-channel-title-badge">
<img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" class="yt-uix-tooltip yt-channel-title-icon-verified" alt="" title="Verified">  </span>

</span>
  </h3>
  <div class="yt-lockup-meta" bis_skin_checked="1">
      <span class=" yt-uix-button-subscription-container"><button aria-busy="false" aria-live="polite" title="10,517,422 subscribers" class="yt-uix-subscription-button yt-uix-hovercard yt-uix-button yt-uix-button-subscribe-unbranded yt-uix-button-size-default yt-uix-button-has-icon yt-uix-tooltip" onclick=";return false;" type="button" aria-role="button" data-subscriber-count-tooltip="True" data-href="https://accounts.google.com/ServiceLogin?passive=true&continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26continue_action%3DQUFFLUhqbkhReXFmSDdWbXAwMk5qWjJoLU9tSUdxaXBSUXxBQ3Jtc0ttRmZZVUZ1MXRtQW9EdTFuQmIzeThfQWJ6bzlzRER4RWluNHZxVWkwSjhVWG1qZ1RfUUlLbmRqYUI5bE9URmdzUGVBbXdNUWVsd3pRS25KOHR6X0t0S3FQdV9pZVFWcG5OSWRvMGlyZkNSWEVNT253MVFUZFhtdWNKblF2WE5zZjB3ZnlGWUF2NTlBcmgyUllEajJIeEpXVlRWZ0dsTWVtUGdRR1VhSDVaS0xoVFdXNl8xWGFZS0Jic1NDWkxEWlY2S3NvT0w%253D%26feature%3Dsubscribe%26hl%3Den%26next%3D%252Fchannel%252FUCGt7X90Au6BV8rf49BiM6Dg&service=youtube&uilel=3&hl=en" data-style-type="unbranded" data-channel-external-id="UCGt7X90Au6BV8rf49BiM6Dg" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CAwQmysoAg&feature=rc-rel" data-subscriber-count-title="10,517,422 subscribers" role="button"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-subscribe" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="10,517,422 subscribers" title=""></span><span class="yt-uix-button-content"><span class="subscribe-label" aria-label="Subscribe">Subscribe</span><span class="subscribed-label" aria-label="Unsubscribe">Subscribed</span><span class="unsubscribe-label" aria-label="Unsubscribe">Unsubscribe</span> </span></button>  <span class="yt-subscription-button-disabled-mask" title=""></span>
</span>
  </div>

    </div>
    
  </a>


  </li>

        <li class="branded-page-related-channels-item spf-nolink clearfix" data-external-id="UCzH3iADRIq1IJlIXjfNgTpA">
    




    <a class="yt-lockup clearfix  yt-lockup-channel yt-lockup-mini vve-check yt-uix-sessionlink" href="/user/RoosterTeeth" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CA0Q9BwoAg&feature=rc-rel">
    <div class="yt-lockup-thumbnail" style="width: 34px;" bis_skin_checked="1">
          <span class="video-thumb  yt-thumb yt-thumb-34">
      <span class="yt-thumb-square">
        <span class="yt-thumb-clip">
          <img alt="Rooster Teeth" data-thumb="https://web.archive.org/web/20131205044335/https://lh6.googleusercontent.com/-hddEYyXVeZM/AAAAAAAAAAI/AAAAAAAAAAA/ghwEL1-FHdE/s88-c-k-no/photo.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="34" data-group-key="thumb-group-1">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>

    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
        <h3 class="yt-lockup-title">
    <span class="qualified-channel-title ellipsized has-badge"><span class="qualified-channel-title-wrapper  g-hovercard" data-ytid="UCzH3iADRIq1IJlIXjfNgTpA" data-name="rc-rel">  <span class="qualified-channel-title-text">
      Rooster Teeth
  </span>
</span>      <span class="qualified-channel-title-badge">
<img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" class="yt-uix-tooltip yt-channel-title-icon-verified" alt="" title="Verified">  </span>

</span>
  </h3>
  <div class="yt-lockup-meta" bis_skin_checked="1">
      <span class=" yt-uix-button-subscription-container"><button aria-busy="false" aria-live="polite" title="6,719,368 subscribers" class="yt-uix-subscription-button yt-uix-hovercard yt-uix-button yt-uix-button-subscribe-unbranded yt-uix-button-size-default yt-uix-button-has-icon yt-uix-tooltip" onclick=";return false;" type="button" aria-role="button" data-subscriber-count-tooltip="True" data-href="https://accounts.google.com/ServiceLogin?passive=true&continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26continue_action%3DQUFFLUhqa3lQOVN1Ykg3eFN2NU5VQk55MjdERkhzOFNOZ3xBQ3Jtc0tuSDdCbDVQUFBfa3JkcXIydE55OHFTM0JTQ1cweGl0azJ1NVlsZ0RVVWVpWjd4RWw1Wkd0UjBMR1E3NUE1ZXN6OUtSWS15Yl9QcExyeW1HOFd6VkdqM2t2U0RESnc1TU5aVTFEOVo0WmQ2RWFRQTBPZDJxdzV6OG9qZEVETmtVWVVSRHlCS2owV0QwRUUzTmt6WWtnT3Rod2cxdkZlNFY3UnZQVUJfd2lSMGhadUdoRC1Cbld0RENtaWlrWHBVWnBwbjNoZEg%253D%26feature%3Dsubscribe%26hl%3Den%26next%3D%252Fchannel%252FUCzH3iADRIq1IJlIXjfNgTpA&service=youtube&uilel=3&hl=en" data-style-type="unbranded" data-channel-external-id="UCzH3iADRIq1IJlIXjfNgTpA" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CBAQmysoAg&feature=rc-rel" data-subscriber-count-title="6,719,368 subscribers" role="button"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-subscribe" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="6,719,368 subscribers" title=""></span><span class="yt-uix-button-content"><span class="subscribe-label" aria-label="Subscribe">Subscribe</span><span class="subscribed-label" aria-label="Unsubscribe">Subscribed</span><span class="unsubscribe-label" aria-label="Unsubscribe">Unsubscribe</span> </span></button>  <span class="yt-subscription-button-disabled-mask" title=""></span>
</span>
  </div>
    </div>
  </a>
  </li>
        <li class="branded-page-related-channels-item spf-nolink clearfix" data-external-id="UC0v-tlzsn0QZwJnkiaUSJVQ">
    <a class="yt-lockup clearfix  yt-lockup-channel yt-lockup-mini vve-check yt-uix-sessionlink" href="/user/TheFineBros" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CBEQ9BwoAw&feature=rc-rel">
    <div class="yt-lockup-thumbnail" style="width: 34px;" bis_skin_checked="1">
          <span class="video-thumb  yt-thumb yt-thumb-34">
      <span class="yt-thumb-square">
        <span class="yt-thumb-clip">
          <img alt="TheFineBros" data-thumb="https://web.archive.org/web/20131205044335/https://lh4.googleusercontent.com/-UsqednQXiuQ/AAAAAAAAAAI/AAAAAAAAAAA/HHn1lQdSH8I/s88-c-k-no/photo.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="34" data-group-key="thumb-group-1">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>
    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
        <h3 class="yt-lockup-title">
    <span class="qualified-channel-title ellipsized has-badge"><span class="qualified-channel-title-wrapper  g-hovercard" data-ytid="UC0v-tlzsn0QZwJnkiaUSJVQ" data-name="rc-rel">  <span class="qualified-channel-title-text">
      TheFineBros
  </span>
</span>      <span class="qualified-channel-title-badge">
<img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" class="yt-uix-tooltip yt-channel-title-icon-verified" alt="" title="Verified">  </span>
</span>
  </h3>
  <div class="yt-lockup-meta" bis_skin_checked="1">
      <span class=" yt-uix-button-subscription-container"><button aria-busy="false" aria-live="polite" title="6,590,422 subscribers" class="yt-uix-subscription-button yt-uix-hovercard yt-uix-button yt-uix-button-subscribe-unbranded yt-uix-button-size-default yt-uix-button-has-icon yt-uix-tooltip" onclick=";return false;" type="button" aria-role="button" data-subscriber-count-tooltip="True" data-href="https://accounts.google.com/ServiceLogin?passive=true&continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26continue_action%3DQUFFLUhqbDgtZlcyU1RkdHlMX3VQVmdGc0FZWFAyTElid3xBQ3Jtc0treHFuQjk0WDhpYV9udGU1T0VIcVFsUS1UeG15WmRxb2RmWlg0a2d6RDJrYWJ5bkJzV09ybG5jeDl0d3V5aTE0NmRpTkpEdHpwbkloX1VWNlBPazdIcnpjaUp0VFNDV3ZkRlFzNS12MmdhalRleHhvNkFjMTZFQ2JUa2VoQnJob2E2RGJMOTNDWUthdFNwRVh6UVQ2eE56cDlDZERmdEhIVGoyemx1aVlZTHROdTRza0hsZWFMdTNiRzNYTHpWZU84QlBRN3Q%253D%26feature%3Dsubscribe%26hl%3Den%26next%3D%252Fchannel%252FUC0v-tlzsn0QZwJnkiaUSJVQ&service=youtube&uilel=3&hl=en" data-style-type="unbranded" data-channel-external-id="UC0v-tlzsn0QZwJnkiaUSJVQ" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CBQQmysoAg&feature=rc-rel" data-subscriber-count-title="6,590,422 subscribers" role="button"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-subscribe" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="6,590,422 subscribers" title=""></span><span class="yt-uix-button-content"><span class="subscribe-label" aria-label="Subscribe">Subscribe</span><span class="subscribed-label" aria-label="Unsubscribe">Subscribed</span><span class="unsubscribe-label" aria-label="Unsubscribe">Unsubscribe</span> </span></button>  <span class="yt-subscription-button-disabled-mask" title=""></span>
</span>
  </div>
    </div>
  </a>
  </li>
        <li class="branded-page-related-channels-item spf-nolink clearfix" data-external-id="UCYjk_zY-iYR8YNfJmuzd70A">
    <a class="yt-lockup clearfix  yt-lockup-channel yt-lockup-mini vve-check yt-uix-sessionlink" href="/user/EpicMealTime" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CBUQ9BwoBA&feature=rc-rel">
    <div class="yt-lockup-thumbnail" style="width: 34px;" bis_skin_checked="1">
          <span class="video-thumb  yt-thumb yt-thumb-34">
      <span class="yt-thumb-square">
        <span class="yt-thumb-clip">
          <img alt="Epic Meal Time" data-thumb="https://web.archive.org/web/20131205044335/https://lh6.googleusercontent.com/-wsUurA2UA6Q/AAAAAAAAAAI/AAAAAAAAAAA/mYrc7qkwqbw/s88-c-k-no/photo.jpg" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" width="34" data-group-key="thumb-group-1">
          <span class="vertical-align"></span>
        </span>
      </span>
    </span>

    </div>
    <div class="yt-lockup-content" bis_skin_checked="1">
        <h3 class="yt-lockup-title">
    <span class="qualified-channel-title ellipsized has-badge"><span class="qualified-channel-title-wrapper  g-hovercard" data-ytid="UCYjk_zY-iYR8YNfJmuzd70A" data-name="rc-rel">  <span class="qualified-channel-title-text">
      Epic Meal Time
  </span>
</span>      <span class="qualified-channel-title-badge">
<img src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" class="yt-uix-tooltip yt-channel-title-icon-verified" alt="" title="Verified">  </span>

</span>
  </h3>
  <div class="yt-lockup-meta" bis_skin_checked="1">
      <span class=" yt-uix-button-subscription-container"><button aria-busy="false" aria-live="polite" title="5,874,957 subscribers" class="yt-uix-subscription-button yt-uix-hovercard yt-uix-button yt-uix-button-subscribe-unbranded yt-uix-button-size-default yt-uix-button-has-icon yt-uix-tooltip" onclick=";return false;" type="button" aria-role="button" data-subscriber-count-tooltip="True" data-href="https://accounts.google.com/ServiceLogin?passive=true&continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26continue_action%3DQUFFLUhqbHdvajBRc3RoenBXdHJkYUllZVNFWmIyVWczQXxBQ3Jtc0trU0ZsWl9pckdSclNtYS14TThrbWx2ZHd5WnhCazRrNUJQek9rVDFiVm9YWmxnOEVzMkJzRk5YTDZCYXUxT2UzNzZRLTc2STB4WGV3Z2U2eGNsc0ZsRS1yRnBLaWdlVWJkUnczeTdiRF9tYUR4UXlEZHU5OVVEaDBLXzBQdG5DWGd0eEhCcWlHRll1cVNxVHBibDF2dUlpWGRDS1lhOVhHRUlsSzRSTkRCdjdZNDR4UEtNZ01POVY5dlZUaGV1VnJFS0ljQXE%253D%26feature%3Dsubscribe%26hl%3Den%26next%3D%252Fchannel%252FUCYjk_zY-iYR8YNfJmuzd70A&service=youtube&uilel=3&hl=en" data-style-type="unbranded" data-channel-external-id="UCYjk_zY-iYR8YNfJmuzd70A" data-sessionlink="ei=dwSgUq_uNIWbiAL36YDICw&ved=CBgQmysoAg&feature=rc-rel" data-subscriber-count-title="5,874,957 subscribers" role="button"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-subscribe" src="http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt="5,874,957 subscribers" title=""></span><span class="yt-uix-button-content"><span class="subscribe-label" aria-label="Subscribe">Subscribe</span><span class="subscribed-label" aria-label="Unsubscribe">Subscribed</span><span class="unsubscribe-label" aria-label="Unsubscribe">Unsubscribe</span> </span></button>  <span class="yt-subscription-button-disabled-mask" title=""></span>
</span>
  </div>

    </div>
    
  </a>


  </li>

  </ul>

    </div>-->


          </div>
          <div class="branded-page-v2-secondary-col" bis_skin_checked="1"><div bis_skin_checked="1">          
</div></div>
      </div>
    </div>
  </div>
</div>

<!-- end channel: -->
</div></div></div>  <div id="footer-container"><div id="footer"><div id="footer-main"><div id="footer-l0go"><a href="/" title="SigmaVid home"><img height="30px" width="72px" id="logo1" src="images/SigmaVid-logo.png" alt="SigmaVid home"></a></div> 
 

</div><div id="footer-links"><ul id="footer-links-primary">  <li><a href="/about">About</a></li>
  <li><a href="/blog">Press &amp; Blogs</a></li>
  <li><a href="/copyright">Copyright</a></li>
  <li><a href="/creators">Creators &amp; Partners</a></li>
  <li><a href="/advertise">Advertising</a></li>
  <li><a href="/dev">Developers</a></li>
</ul><ul id="footer-links-secondary">  <li><a href="/tos">Terms</a></li>
  <li><a href="/policyandsafety">
Policy &amp; Safety
  </a></li>
  <li>  <span class="copyright" dir="ltr">© 2024 SigmaVid</span>
</li>
</ul></div></div></div>


      <div class="yt-dialog hid" id="feed-privacy-lb">
    <div class="yt-dialog-base">
      <span class="yt-dialog-align"></span>
      <div class="yt-dialog-fg">
        <div class="yt-dialog-fg-content">
          <div class="yt-dialog-loading">
              <div class="yt-dialog-waiting-content">
    <div class="yt-spinner-img"></div><div class="yt-dialog-waiting-text">Loading...</div>
  </div>

          </div>
          <div class="yt-dialog-content">
              <div id="feed-privacy-dialog">
  </div>

          </div>
          <div class="yt-dialog-working">
              <div id="yt-dialog-working-overlay">
  </div>
  <div id="yt-dialog-working-bubble">
    <div class="yt-dialog-waiting-content">
      <div class="yt-spinner-img"></div><div class="yt-dialog-waiting-text">Working...</div>
    </div>
  </div>

          </div>
        </div>
      </div>
    </div>
  </div>



    <div id="shared-addto-watch-later-login" class="hid">
      <a href="https://accounts.google.com/ServiceLogin?passive=true&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26feature%3Dplaylist%26hl%3Den%26next%3D%252F&amp;uilel=3&amp;service=youtube&amp;hl=en" class="sign-in-link">Sign in</a> to add this to Watch Later

    </div>
  

  




</body></html>