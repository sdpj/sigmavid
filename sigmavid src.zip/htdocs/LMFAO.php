<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BO1ISTHEBEST</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            overflow: hidden;
            background: url('https://files.catbox.moe/7hpz8b.png') no-repeat center center fixed;
            background-size: 100% 100%; /* Stretch the image to fit */
            font-family: 'Roboto', Arial, sans-serif;
            filter: blur(0px); /* Initially no blur */
            transition: filter 0.3s; /* Smooth transition for blur effect */
        }
        .play-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8); /* Darker overlay */
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px; /* Larger text size */
            cursor: pointer;
            text-align: center;
            backdrop-filter: blur(10px); /* Stronger blur effect */
            z-index: 10; /* Ensure it sits above the background */
            opacity: 0; /* Start hidden for fade-in animation */
            animation: fadeIn 1s forwards; /* Fade-in animation */
        }

        @keyframes fadeIn {
            from {
                opacity: 0.5;
            }
            to {
                opacity: 1;
            }
        }

        .play-overlay p {
            margin: 0;
            font-weight: 700; /* Bold font weight */
        }
    </style>
</head>
<body>
    <div class="play-overlay">
        <p>Click anywhere to start audio</p>
    </div>
    <audio id="audio1" src="https://files.catbox.moe/0rv4u6.mp3"></audio>
    <audio id="audio2" src="https://files.catbox.moe/b39hbv.mp3"></audio>
    <script>
        document.querySelector('.play-overlay').addEventListener('click', function() {
            var audio1 = document.getElementById('audio1');
            var audio2 = document.getElementById('audio2');

            document.body.style.filter = 'blur(0px)'; // Remove blur effect
            audio1.play().then(() => {
                audio1.onended = function() {
                    audio2.play();
                };
                // Hide overlay once audio starts playing with a fade-out effect
                this.style.opacity = '0';
                setTimeout(() => { this.style.display = 'none'; }, 300); // Delay hiding for smooth transition
            }).catch(error => {
                console.error('Playback failed:', error);
            });
        });
    </script>
</body>
</html>