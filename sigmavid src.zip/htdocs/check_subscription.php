<?php
session_start(); // Start session for user authentication

include 'db.php'; // Include your database connection file

// Check if user is logged in
if (isset($_SESSION['user_id'])) {
    $subscriberId = $_SESSION['user_id'];

    // Check if user_id is provided via POST
    if (isset($_POST['user_id'])) {
        $userId = $_POST['user_id'];

        // Check if already subscribed
        $query = "SELECT * FROM subscriptions WHERE user_id = '$userId' AND subscriber_id = '$subscriberId'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            echo "subscribed";
        } else {
            // Not subscribed
            // Optionally, you can return any other status or message here
            // For simplicity, return nothing if not subscribed
        }
    } else {
        echo "User ID not provided.";
    }
} else {
    echo "Please log in to check subscription status.";
}
?>
