<?php
// Start session
session_start();

// Set timezone to CDT
date_default_timezone_set('America/Chicago');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page or handle unauthorized access
    header("Location: login.php");
    exit();
}

// Include database connection
include 'db.php';

// Get form data
$video_id = $_POST['video_id'];
$user_id = $_SESSION['user_id'];
$comment_text = trim($_POST['comment_text']); // Trim whitespace
$ip_address = $_SERVER['REMOTE_ADDR'];

// Define the cooldown period in seconds (e.g., 60 seconds)
$cooldown_period = 60;

// Define banned words
$banned_words = array("nigger", "faggot", "sigmavidtrollpolice", "nugg4t", "svtp", "nigg3r", "nig3r", "grandma", "vidlii", "uttp", "troll police", "sigmavid troll police", "sigma vid troll police", "kozakgamer");

// Validate comment text
if (empty($comment_text)) {
    header("Location: watch.php?id=" . $video_id . "&error=Comment cannot be empty.");
    exit();
}

// Check if the comment contains banned words
foreach ($banned_words as $word) {
    if (stripos($comment_text, $word) !== false) {
        header("Location: watch.php?id=" . $video_id . "&error=There was an error submitting your comment.");
        exit();
    }
}

// Check the last comment time for this IP address
$stmt = $conn->prepare("SELECT comment_date FROM comments WHERE ip_address = ? ORDER BY comment_date DESC LIMIT 1");
$stmt->bind_param("s", $ip_address);
$stmt->execute();
$stmt->bind_result($last_comment_time);
$stmt->fetch();
$stmt->close();

// Check if the cooldown period has passed
$current_time = time();
if ($last_comment_time) {
    $last_comment_timestamp = strtotime($last_comment_time);
    $time_diff = $current_time - $last_comment_timestamp;

    if ($time_diff < $cooldown_period) {
        $remaining_time = $cooldown_period - $time_diff;
        header("Location: watch.php?id=" . $video_id . "&error=Please wait " . $remaining_time . " seconds before commenting again.");
        exit();
    }
}

// Insert comment into database
$stmt = $conn->prepare("INSERT INTO comments (video_id, user_id, comment_text, comment_date, ip_address) VALUES (?, ?, ?, NOW(), ?)");
$stmt->bind_param("iiss", $video_id, $user_id, $comment_text, $ip_address);
$stmt->execute();
$stmt->close();

// Redirect back to watch.php with the video ID
header("Location: watch.php?id=" . $video_id);
exit();
?>
