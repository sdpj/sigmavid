<?php
    $video = $_GET["video"];
    $width = $_GET["width"];
    $height = $_GET["height"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="player/script/player.js"></script>
    <title>MeTube Player Preview</title>
    <script>
        var MTP_Values = {
            'PlayerAppendEl': "#MT_Player",
            'VideoSource': "/uploads/<?php echo $video; ?>",
            'Autoplay': false,
            'DurationSeconds': 0,
            'Width': <?php echo $width; ?>,
            'Height': <?php echo $height; ?>
        }
    </script>
    <style>
        body {
            margin: 0;
        }
    </style>
</head>
<div id="MT_Player"></div>
</html>
