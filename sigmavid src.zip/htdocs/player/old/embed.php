<?php $video = $_GET['video']; ?>
<script type="text/javascript">window.addEventListener('DOMContentLoaded',function(){var v=archive_analytics.values;v.service='wb';v.server_name='wwwb-app100.us.archive.org';v.server_ms=7462;archive_analytics.send_pageview({});});</script><script type="text/javascript" src="watch2_files/playback.bundle.js.download" charset="utf-8"></script>
<script type="text/javascript" src="watch2_files/wombat.js.download" charset="utf-8"></script>
<script type="text/javascript">
  __wm.init("https://web.archive.org/web");
  __wm.wombat("http://www.youtube.com/watch?v=oHg5SJYRHA0","20120713150632","https://web.archive.org/","web","/_static/",
	      "1342191992");
</script>
<link rel="stylesheet" type="text/css" href="watch2_files/banner-styles.css">
<link rel="stylesheet" type="text/css" href="watch2_files/iconochive.css">
<!-- Start Wayback Rewrite JS Include -->
<script type="text/javascript" src="watch2_files/jwplayer.js.download" charset="utf-8"></script>
<script type="text/javascript" src="watch2_files/video-embed-rewriter.js.download" charset="utf-8"></script>
<script type="text/javascript">
_wmVideos_.init("/web");
</script>
<!-- End Wayback Rewrite JS Include -->

        <script>
var yt = yt || {};yt.timing = yt.timing || {};yt.timing.tick = function(label, opt_time) {var timer = yt.timing['timer'] || {};if(opt_time) {timer[label] = opt_time;}else {timer[label] = new Date().getTime();}yt.timing['timer'] = timer;};yt.timing.info = function(label, value) {var info_args = yt.timing['info_args'] || {};info_args[label] = value;yt.timing['info_args'] = info_args;};yt.timing.info('e', "904510,914061,900203,907217,907335,921602,919306,922600,919316,919804,924500,906831,924700,913542,919324,920706,924402,907344,912706,902518");yt.timing.wff = true;yt.timing.info('an', "");if (document.webkitHidden == 'prerender') {document.addEventListener('webkitvisibilitychange', function() {yt.timing.tick('start');}, false);}yt.timing.tick('start');yt.timing.info('li','0');try {yt.timing['srt'] = window.gtbExternal && window.gtbExternal.pageT() ||window.external && window.external.pageT;} catch(e) {}if (window.chrome && window.chrome.csi) {yt.timing['srt'] = Math.floor(window.chrome.csi().pageT);}if (window.msPerformance && window.msPerformance.timing) {yt.timing['srt'] = window.msPerformance.timing.responseStart - window.msPerformance.timing.navigationStart;}    </script>

<script>var yt = yt || {};yt.preload = {};yt.preload.counter_ = 0;yt.preload.start = function(src) {var img = new Image();var counter = ++yt.preload.counter_;yt.preload[counter] = img;img.onload = img.onerror = function () {delete yt.preload[counter];};img.src = src;img = null;};yt.preload.start("https:\/\/web.archive.org\/web\/20120713150632\/http:\/\/o-o.preferred.nuq04s15.v18.lscache1.c.youtube.com\/crossdomain.xml");yt.preload.start("https:\/\/web.archive.org\/web\/20120713150632\/http:\/\/o-o.preferred.nuq04s15.v18.lscache1.c.youtube.com\/generate_204?ip=207.241.226.145\u0026upn=garqfim3DUQ\u0026sparams=algorithm%2Cburst%2Ccp%2Cfactor%2Cid%2Cip%2Cipbits%2Citag%2Csource%2Cupn%2Cexpire\u0026fexp=904510%2C914061%2C900203%2C907217%2C907335%2C921602%2C919306%2C922600%2C919316%2C919804%2C924500%2C906831%2C924700%2C913542%2C919324%2C920706%2C924402%2C907344%2C912706%2C902518\u0026mt=1342191798\u0026ms=au\u0026algorithm=throttle-factor\u0026burst=40\u0026ipbits=8\u0026itag=34\u0026sver=3\u0026signature=8672A95239A58FE5CEBBF027D076E07661F7D7FB.3F8E89E41882DADD0F16D743504116F363139425\u0026source=youtube\u0026expire=1342215946\u0026key=yt1\u0026factor=1.25\u0026cp=U0hTR1JMU19JUENOM19KRldKOlRQSUNaNGw5czJL\u0026id=a078394896111c0d");</script>
    <link id="www-core-css" rel="stylesheet" href="watch2_files/www-core-vflMJW9Qx.css">
    <script>
    var gYouTubePlayerReady = false;
    if (!window['onYouTubePlayerReady']) {
      window['onYouTubePlayerReady'] = function() {
        gYouTubePlayerReady = true;
      };
    }
  </script>
      <script>
if (window.yt.timing) {yt.timing.tick("ct");}    </script>
<link rel="stylesheet" type="text/css" href="watch2_files/www-player-vflv3bqnK.css" id="www-player-css"><style type="text/css">.gssb_c{border:0;position:absolute;z-index:989}.gssb_e{border:1px solid #ccc;border-top-color:#d9d9d9;box-shadow:0 2px 4px rgba(0,0,0,0.2);-webkit-box-shadow:0 2px 4px rgba(0,0,0,0.2);cursor:default}.gssb_f{visibility:hidden;white-space:nowrap}.gssb_k{border:0;display:block;position:absolute;top:0;z-index:988}.gsdd_a{border:none!important}.gsib_a{width:100%;padding:4px 6px 0}.gsib_a,.gsib_b{vertical-align:top}.gssb_a{padding:0 7px}.gssb_a,.gssb_a td{white-space:nowrap;overflow:hidden;line-height:22px}#gssb_b{font-size:11px;color:#36c;text-decoration:none}#gssb_b:hover{font-size:11px;color:#36c;text-decoration:underline}.gssb_m{color:#000;background:#fff}.gssb_g{text-align:center;padding:8px 0 7px;position:relative}.gssb_h{font-size:15px;height:28px;margin:0.2em;-webkit-appearance:button}.gssb_i{background:#eee}.gss_ifl{visibility:hidden;padding-left:5px}.gssb_i .gss_ifl{visibility:visible}a.gssb_j{font-size:13px;color:#36c;text-decoration:none;line-height:100%}a.gssb_j:hover{text-decoration:underline}.gssb_l{height:1px;background-color:#e5e5e5}.gscp_a{background:#d9e7fe;border:1px solid #9cb0d8;cursor:default;display:inline-block;height:23px;line-height:22px;margin:1px 2px 1px 1px;outline:none;text-decoration:none!important;user-select:none;vertical-align:bottom;-khtml-user-select:none;-moz-user-select:none;-webkit-user-select:none}.gscp_a:hover{border-color:#869ec9;cursor:default}a.gscp_b{background:#4787ec;border-color:#3967bf!important}.gscp_c{color:#444;font-size:13px;font-weight:bold}.gscp_c:hover{color:#222}a.gscp_b .gscp_c{color:#fff}.gscp_d{color:#aeb8cb;cursor:pointer;display:inline-block;font:23px arial,sans-serif;padding: 0 7px 2px 7px;vertical-align:middle}.gscp_a:hover .gscp_d{color:#575b66}a.gscp_b .gscp_d{color:#edf3fb!important}.gscp_e{padding:0 4px}.gscp_f{display:inline-block;vertical-align:top}a.gspqs_a{padding:0 3px 0 8px}.gspqs_b{color:#666;line-height:22px}.gsq_a{padding:0}.gspr_a{padding-right:1px}.gsfe_a{border:1px solid #b9b9b9;border-top-color:#a0a0a0;box-shadow:inset 0px 1px 2px rgba(0,0,0,0.1);-moz-box-shadow:inset 0px 1px 2px rgba(0,0,0,0.1);-webkit-box-shadow:inset 0px 1px 2px rgba(0,0,0,0.1);}.gsfe_b{border:1px solid #4d90fe;outline:none;box-shadow:inset 0px 1px 2px rgba(0,0,0,0.3);-moz-box-shadow:inset 0px 1px 2px rgba(0,0,0,0.3);-webkit-box-shadow:inset 0px 1px 2px rgba(0,0,0,0.3);}.gsok_a{background:url(data:image/gif;base64,R0lGODlhEwALAKECAAAAABISEv///////yH5BAEKAAIALAAAAAATAAsAAAIdDI6pZ+suQJyy0ocV3bbm33EcCArmiUYk1qxAUAAAOw==) no-repeat center;display:inline-block;height:11px;line-height:0;width:19px}.gsok_a img{border:none;visibility:hidden}.gsst_a,.gsst_d{display:inline-block}.gsst_a{cursor:pointer;padding:0 3px}.gsst_a:hover{text-decoration:none!important}.gsst_b{font-size:16px;padding:0 3px;user-select:none;-webkit-user-select:none;white-space:nowrap}.gsst_d{width:4px}.gsst_e{opacity:0.55;}.gsst_a:hover .gsst_e,.gsst_a:focus .gsst_e{opacity:0.72;}.gsst_a:active .gsst_e{opacity:1;}.gsfi{font-size:13px}.gsfs{font-size:13px}a.gssb_j{font-size:12px;color:#03c}.gssb_a,.gssb_a td{line-height:17px}.gssb_a{padding:0 5px}.gssb_c{z-index:3000001}.gssb_i td{background:#eee}.gssb_k{z-index:3000000}.gssb_l{margin:2px 0}.gsib_a{padding:0 4px}.gsok_a{padding:0}.gsok_a img{display:block}.gsfe_b{border:1px solid #1c62b9;box-shadow:inset 0px 1px 2px rgba(0,0,0,0.3);-webkit-box-shadow:inset 0px 1px 2px rgba(0,0,0,0.3);outline:none;}</style><style></style></head>
  <body id="" class="date-20120712 en_US ltr  exp-edit-on-watch exp-channel-promo-on-watch ytg-old-clearfix " dir="ltr" data-player-size="small">

 <div id="watch-video-container">
    <div id="watch-video" class="">
          <script>
if (window.yt.timing) {yt.timing.tick("bf");}    </script>

          <div id="watch-player" class="flash-player wm-videoplayer"><div id="movie_player-html5" class="html5-video-player el-detailpage paused-mode hide-controls" style="" tabindex="-1">
      <style class="html5-viewport-sheet" disabled="true">
    @-o-viewport { width: device-width; }
    @-moz-viewport { width: device-width; }
    @-ms-viewport { width: device-width; }
    @-webkit-viewport { width: device-width; }
    @viewport { width: device-width; }
  </style>

      <div class="html5-video-fallback html5-stop-propagation hid" style="display: none;">
    <div class="html5-video-fallback-content">
      This video is currently unavailable.
    </div>
  </div>

    <div class="html5-video-container">
        <div class="html5-modal-panel html5-stop-propagation hid" style="display: none;">
    <div class="html5-modal-panel-clipboard-substitute-content">
      <input type="text" readonly="readonly">
    </div>
    <div class="html5-modal-panel-infobox-content">
    </div>
    <button onclick="return false;" type="button" class="html5-modal-panel-close-button" role="button">
Close
    </button>
    <div class="html5-show-video-info-template hid">
      <table class="html5-video-info-table">
        <tbody><tr><th>Video ID:</th><td>__videoId__</td></tr>
        <tr><th>Dimensions:</th><td>__videoWidth__x__videoHeight__</td></tr>
        <tr><th>Volume:</th><td>__volume__%</td></tr>
        <tr><th>Stream Type:</th><td>__streamType__</td></tr>
      </tbody></table>
      &nbsp;
      <table class="html5-video-info-table html5-video-element-info-table">
        <tbody><tr><th>Decoded Frames</th><th>Dropped Frames</th><th>Parsed Frames</th><th>Presented Frames</th></tr>
        <tr><td>__decodedFrames__</td><td>__droppedFrames__</td><td>__parsedFrames__</td><td>__presentedFrames__</td></tr>
        <tr><th>Video Bytes Decoded</th><th>Audio Bytes Decoded</th><th>Painted Frames</th><th>Paint Delay</th></tr>
        <tr><td>__videoBytesDecoded__</td><td>__audioBytesDecoded__</td><td>__paintedFrames__</td><td>__paintDelay__</td></tr>
      </tbody></table>
    </div>
  </div>

        <div class="html5-dialog-holder html5-center-overlay html5-center-transform">
      <div class="captions-translation-dialog html5-popup-dialog html5-stop-propagation hid">
    <div class="html5-popup-dialog-title">
      <h3>Translate...</h3>
      <span class="html5-beta-label">BETA</span>
    </div>
    <select class="captions-translation-select"></select>
    <div class="html5-popup-dialog-buttons">
      <button type="button" class="captions-translation-confirm yt-uix-button yt-uix-button-default" onclick=";return false;" role="button"><span class="yt-uix-button-content">OK </span></button>
      <button type="button" class="captions-translation-cancel yt-uix-button yt-uix-button-default" onclick=";return false;" role="button"><span class="yt-uix-button-content">Cancel </span></button>
    </div>
  </div>
  <div class="captions-settings-dialog html5-popup-dialog html5-stop-propagation hid">
    <div class="html5-popup-dialog-title">
      <h3>Caption Settings</h3>
    </div>
    <div class="html5-popup-dialog-body">
      <div class="html5-popup-grouping">
        <p class="html5-popup-side-left">
          <button type="button" class="captions-settings-bg yt-uix-button yt-uix-button-default" onclick=";return false;" role="button"><span class="yt-uix-button-content">Background </span></button>
Shortcut: b
        </p>
        <p class="html5-popup-side-right">
          <button type="button" class="captions-settings-font-inc yt-uix-button yt-uix-button-default yt-uix-tooltip" onclick=";return false;" title="Increase font size" role="button" aria-label="Increase font size"><span class="yt-uix-button-content">+ </span></button>
          <button type="button" class="captions-settings-font-dec yt-uix-button yt-uix-button-default yt-uix-tooltip" onclick=";return false;" title="Decrease font size" role="button" aria-label="Decrease font size"><span class="yt-uix-button-content">- </span></button>
Shortcut: +/-
        </p>
      </div>
      <div class="html5-popup-grouping">
        <p class="html5-popup-side-left">
Foreground
        </p>
        <p class="html5-popup-side-right">
              <button data-color="#080808" style="background: #080808" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" role="button" aria-label="color #080808"></button>
    <button data-color="#00f" style="background: #00f" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" role="button" aria-label="color #00f"></button>
    <button data-color="#0f0" style="background: #0f0" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" role="button" aria-label="color #0f0"></button>
    <button data-color="#0ff" style="background: #0ff" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" role="button" aria-label="color #0ff"></button>
    <button data-color="#f00" style="background: #f00" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" role="button" aria-label="color #f00"></button>
    <button data-color="#f0f" style="background: #f0f" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" role="button" aria-label="color #f0f"></button>
    <button data-color="#ff0" style="background: #ff0" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" role="button" aria-label="color #ff0"></button>
    <button data-color="#fff" style="background: #fff" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" role="button" aria-label="color #fff"></button>

        </p>
      </div>
      <div class="html5-popup-grouping">
        <p class="html5-popup-side-left">
Background
        </p>
        <p class="html5-popup-side-right">
              <button style="background: #080808" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" data-background="#080808" role="button" aria-label="background #080808"></button>
    <button style="background: #00f" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" data-background="#00f" role="button" aria-label="background #00f"></button>
    <button style="background: #0f0" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" data-background="#0f0" role="button" aria-label="background #0f0"></button>
    <button style="background: #0ff" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" data-background="#0ff" role="button" aria-label="background #0ff"></button>
    <button style="background: #f00" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" data-background="#f00" role="button" aria-label="background #f00"></button>
    <button style="background: #f0f" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" data-background="#f0f" role="button" aria-label="background #f0f"></button>
    <button style="background: #ff0" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" data-background="#ff0" role="button" aria-label="background #ff0"></button>
    <button style="background: #fff" onclick=";return false;" type="button" class="html5-color-picker-button yt-uix-button yt-uix-button-default yt-uix-button-empty" data-background="#fff" role="button" aria-label="background #fff"></button>

        </p>
      </div>
    </div>
    <div class="html5-popup-dialog-buttons">
      <p class="html5-popup-side-left">
      </p>
      <button type="button" class="captions-settings-cancel yt-uix-button yt-uix-button-default" onclick=";return false;" role="button"><span class="yt-uix-button-content">Reset </span></button>
      <button type="button" class="captions-settings-confirm yt-uix-button yt-uix-button-default" onclick=";return false;" role="button"><span class="yt-uix-button-content">Done </span></button>
    </div>
  </div>

      <div class="threed-html5-warning-dialog html5-popup-dialog html5-stop-propagation hid">
    <div class="html5-popup-dialog-title">
      <h3>No HTML5 3D hardware detected</h3>
    </div>
    <div class="html5-popup-dialog-body">
      <p>
Get <a href="https://web.archive.org/web/20120713143119/https://support.google.com/youtube/bin/answer.py?answer=1229982&amp;hl=en-US">help setting up HTML5 3D</a>, or change 3D viewing modes.
      </p>
    </div>
    <div class="html5-popup-dialog-buttons">
      <button href="#" type="button" class="html5-threed-dialog-change-mode-button yt-uix-button yt-uix-button-default" onclick=";window.location.href=this.getAttribute(&#39;href&#39;);return false;" role="button"><span class="yt-uix-button-content">Change 3D viewing mode </span></button>
      <button type="button" class="threed-html5-warning-close yt-uix-button yt-uix-button-default" onclick=";return false;" role="button"><span class="yt-uix-button-content">Close </span></button>
    </div>
  </div>

  </div>

        <div class="html5-video-content" style="width: 100%; height: 100%; left: 0px; top: 0px;">
		<video id="video-stream" class="video-stream" x-webkit-airplay="allow" src="/uploads/<?php echo $video; ?>"></video></div>

        <div class="video-annotations">
    <div class="annotation-close-button-container hid">
      <svg class="annotation-close-button" width="100%" height="100%" viewBox="0 0 21 21" preserveAspectRatio="align">
        <circle cx="10" cy="10" r="8"></circle>
        <path d="M 7,7 L 13,13"></path>
        <path d="M 7,13 L 13,7"></path>
      </svg>
    </div>
    <svg class="countdowntimer hid" width="60" height="60">
      <g>
        <circle cx="30" cy="30" r="15" class="countdowntimer-background-circle"></circle>
        <path d="M30,30 z" class="countdowntimer-diminishing-pieslice"></path>
        <circle cx="30" cy="30" r="4" class="countdowntimer-middle-dot"></circle>
      </g>
    </svg>
  </div>

        <div class="video-ads">
    <div class="video-ad-status-bar">
      <div class="video-ad-label">Advertisement</div>
      <div class="video-ad-time-left"></div>
        <div class="html5-progress-bar html5-stop-propagation">
    <div class="html5-ad-progress-list html5-progress-list html5-progress-item"></div>
  </div>

    </div>
    <div class="ad-container"></div>
  </div>

        <div class="html5-video-loader html5-center-overlay" style="transform: rotate(4.83189e+11deg);"></div>

        <div class="html5-info-bar hid" style="display: none;">
    <div class="html5-title" tabindex="1"></div>
    <div class="html5-author hid" tabindex="2">
By <span></span>
    </div>
    <div class="html5-info-bar-logo hid">YouTube</div>
  </div>

        <img class="html5-watermark html5-stop-propagation html5-scalable-icon hid" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt="watermark" style="display: none;">

          <svg class="html5-big-play-button html5-center-overlay html5-scalable-icon">
      <path fill="#380308" d="M89.2,34.4c-0.064,2.649-0.265,5.434-0.6,8.35c-0.467,3.733-1.05,6.867-1.75,9.4
c-1.4,5.133-4.4,8.184-9,9.149c-3.533,0.733-7.6,1.217-12.2,1.45c-4.033,0.233-9.867,0.35-17.5,0.35H40.1
c-10.567,0-20.133-0.6-28.7-1.8c-4.467-0.667-7.467-3.716-9-9.149c-0.7-2.533-1.267-5.667-1.7-9.4
c-0.361-2.916-0.578-5.699-0.65-8.35c0.122,2.316,0.338,4.733,0.65,7.25c0.433,3.732,1,6.866,1.7,9.399
c1.533,5.435,4.533,8.483,9,9.15c8.567,1.2,18.133,1.8,28.7,1.8h8.05c7.633,0,13.467-0.117,17.5-0.35
c4.6-0.233,8.667-0.718,12.2-1.45c4.6-0.967,7.6-4.018,9-9.15c0.7-2.533,1.283-5.667,1.75-9.399
C88.89,39.134,89.089,36.717,89.2,34.4z"></path>
      <path class="html5-overlay-button-background" d="M86.85,10.9c0.7,2.532,1.283,5.684,1.75,9.449c0.433,3.733,0.65,7.268,0.65,10.601V31
c0,3.333-0.217,6.883-0.65,10.65c-0.467,3.732-1.05,6.866-1.75,9.399c-1.4,5.133-4.4,8.185-9,9.15
c-3.533,0.732-7.6,1.216-12.2,1.45C61.617,61.883,55.783,62,48.15,62H40.1c-10.567,0-20.133-0.6-28.7-1.8
c-4.467-0.667-7.467-3.717-9-9.15c-0.7-2.533-1.267-5.667-1.7-9.399C0.233,37.883,0,34.333,0,31v-0.05
c0-3.333,0.233-6.867,0.7-10.601c0.433-3.767,1-6.917,1.7-9.449c1.4-5.134,4.4-8.184,9-9.15c3.5-0.7,7.567-1.183,12.2-1.45
C27.533,0.1,33.367,0,41.1,0h8.05c10.8,0,20.367,0.583,28.7,1.75C82.317,2.417,85.317,5.467,86.85,10.9z"></path>
      <g viewBox="-15.025 -15.151 30.05 30.303" transform="matrix(1 0 0 -1 47.375 29.75)">
        <path fill="#FCFCFC" d="M10.275,4c3.167-1.866,4.75-3.199,4.75-4c0-0.8-1.583-2.149-4.75-4.05
                                c-1.367-0.8-4.517-2.482-9.45-5.05c-4.5-2.333-7.233-3.733-8.2-4.2c-2.533-1.232-4.066-1.85-4.6-1.85
                                c-1.233-0.033-2.083,0.399-2.55,1.3c-0.333,0.667-0.5,1.75-0.5,3.25v21.2c0,1.5,0.167,2.583,0.5,3.25
                                c0.467,0.899,1.317,1.333,2.55,1.3c0.534,0,2.067-0.617,4.6-1.85c0.967-0.468,3.7-1.867,8.2-4.2C5.758,6.533,8.908,4.833,10.275,4
                                z"></path>
      </g>
      <defs>
        <lineargradient id="html5-big-play-button-red" gradientUnits="userSpaceOnUse" x1="44.625" y1="0" x2="44.625" y2="62">
          <stop offset="0" style="stop-color:#CD332D"></stop>
          <stop offset="0.8549" style="stop-color:#6E0610"></stop>
        </lineargradient>
        <lineargradient id="html5-big-play-button-black" gradientUnits="userSpaceOnUse" x1="44.625" y1="0" x2="44.625" y2="62">
          <stop offset="0" style="stop-color:#3E3D3D"></stop>
          <stop offset="0.7451" style="stop-color:#131313"></stop>
        </lineargradient>
      </defs>
    </svg>

        <div class="html5-endscreen">
    <div class="html5-endscreen-content"></div>
    <div class="html5-endscreen-actionbar">
      <button type="button" class="html5-actionbar-replay-button html5-control html5-control-sep yt-uix-button yt-uix-button-player" onclick=";return false;" role="button"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-html5" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt=""></span><span class="yt-uix-button-content">Replay </span></button>
      <button type="button" class="html5-like-button html5-control yt-uix-button yt-uix-button-player" onclick=";return false;" role="button"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-html5" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt=""></span><span class="yt-uix-button-content">Like </span></button>
      <button type="button" class="html5-dislike-button html5-control yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty" onclick=";return false;" title="Dislike" role="button" aria-label="Dislike"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-html5" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt="Dislike"></span></button>

      <button type="button" class="html5-share-button html5-text-button html5-control-right yt-uix-button yt-uix-button-player" onclick=";return false;" role="button"><span class="yt-uix-button-content">Share </span></button>
    </div>

    <div class="videowall-still-content-template">
      <!--
        <span class="videowall-still-featured-label">Featured video</span>
        <span class="videowall-info">__info__</span>
      -->
    </div>
    <div class="videowall-info-template">
      <!--
        <span class="videowall-info-title">__title__</span>
        <span class="videowall-info-author">__author__</span>
        <span class="videowall-info-duration">__duration__</span>
        <span class="videowall-info-view-count">__view_count__</span>
      -->
    </div>
  </div>

        

        <div class="html5-ypc-module">
    <div class="html5-ypc-overlay html5-stop-propagation">
      <div class="html5-ypc-message"></div>
      <button class="html5-ypc-purchase"></button>
      <button class="html5-module-close html5-stop-propagation"></button>
    </div>
    <button class="html5-module-recall html5-stop-propagation"></button>
  </div>

      <div class="html5-fresca-module html5-stop-propagation"><div class="html5-fresca-band-slate"><hgroup class="html5-fresca-message"></hgroup><span class="html5-fresca-countdown"></span></div></div><div class="html5-fresca-template"><!--<h2 class="html5-fresca-heading">__heading__</h2><h3 class="html5-fresca-subheading">__subheading__</h3><h4 class="html5-fresca-long-text">__long_text__</h4>--></div>
    </div>
    <div id="controls" class="html5-video-controls" style="margin-left: -9px;">
        <div class="html5-progress-bar html5-stop-propagation">
    <input id="video-slider" type="range" min="0" max="100" value="100" style="width: 100%; height: 1px;">
  </div>
  <div class="html5-progress-tooltip with-thumbnail hid" style="left: 313.5px; display: none;">
    <img class="html5-progress-tooltip-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 80px; height: 60px; margin: 0px 14px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -240px -360px; background-size: 800px 600px;">
    <span class="html5-progress-tooltip-timestamp">2:02</span>
    <div class="html5-progress-tooltip-arrow" style="left: 51px;"></div>
  </div>

        <div class="html5-storyboard enabled" style="height: 111px;">
    <div class="html5-storyboard-filmstrip" style="width: 7668px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: 0px 0px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -52px 0px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -104px 0px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -156px 0px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -208px 0px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -260px 0px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -312px 0px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -364px 0px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -416px 0px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -468px 0px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: 0px -39px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -52px -39px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -104px -39px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -156px -39px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -208px -39px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -260px -39px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -312px -39px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -364px -39px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -416px -39px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -468px -39px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: 0px -78px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -52px -78px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -104px -78px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -156px -78px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -208px -78px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -260px -78px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -312px -78px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -364px -78px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -416px -78px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -468px -78px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: 0px -117px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -52px -117px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -104px -117px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -156px -117px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -208px -117px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -260px -117px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -312px -117px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -364px -117px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -416px -117px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -468px -117px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: 0px -156px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -52px -156px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -104px -156px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -156px -156px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -208px -156px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -260px -156px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -312px -156px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -364px -156px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -416px -156px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -468px -156px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: 0px -195px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -52px -195px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -104px -195px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -156px -195px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -208px -195px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -260px -195px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -312px -195px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -364px -195px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -416px -195px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -468px -195px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: 0px -234px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -52px -234px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -104px -234px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -156px -234px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -208px -234px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -260px -234px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -312px -234px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -364px -234px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -416px -234px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -468px -234px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: 0px -273px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -52px -273px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -104px -273px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -156px -273px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -208px -273px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -260px -273px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -312px -273px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -364px -273px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -416px -273px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -468px -273px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: 0px -312px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -52px -312px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -104px -312px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -156px -312px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -208px -312px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -260px -312px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -312px -312px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -364px -312px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -416px -312px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -468px -312px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: 0px -351px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -52px -351px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -104px -351px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -156px -351px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -208px -351px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -260px -351px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -312px -351px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -364px -351px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -416px -351px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M0.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -468px -351px; background-size: 520px 390px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M1.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: 0px 0px; background-size: 520px 39px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M1.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -52px 0px; background-size: 520px 39px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M1.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -104px 0px; background-size: 520px 39px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M1.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -156px 0px; background-size: 520px 39px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M1.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -208px 0px; background-size: 520px 39px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M1.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -260px 0px; background-size: 520px 39px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M1.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -312px 0px; background-size: 520px 39px;"><img class="html5-storyboard-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif" style="width: 52px; height: 39px; margin: 0px 10px 0px 9px; background-image: url(&quot;https://web.archive.org/web/20120713150632/http://i4.ytimg.com/sb/oHg5SJYRHA0/storyboard3_L1/M1.jpg?sigh=3QCcFMpSH_MACnGTmY_ha2J8UU0&quot;); background-position: -364px 0px; background-size: 520px 39px;"></div>
    <div class="html5-storyboard-lens" style="width: 142px; height: 91px; left: 249px;">
      <img class="html5-storyboard-lens-thumbnail" src="watch2_files/pixel-vfl3z5WfW(1).gif">
      <span class="html5-storyboard-lens-timestamp"></span>
    </div>
  </div>

        <div class="html5-player-chrome html5-stop-propagation">
    <button id="playpause" onclick="playVid();" data-title-default="Play" title="Play" class="html5-control html5-control-sep yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty html5-play-button" data-title-replay="Replay" onclick=";return false;" data-title-pause="Pause" type="button" data-title-stop="Stop live playback" tabindex="3" role="button" aria-label="Play" data-tooltip-text="Play" data-tooltip-title="Play"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-html5" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt="Play"></span></button>

    <div class="yt-uix-button yt-uix-button-player html5-volume-control html5-control html5-control-sep">
    <button id="mutebutton" data-title-default="Mute" title="Mute" data-title-alt="Unmute" onclick="mute();" type="button" class="html5-volume-button yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty" tabindex="4" role="button" aria-label="mute toggle" data-tooltip-text="Mute" data-value="max" data-volume="100" data-tooltip-title="Mute"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-html5" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt="Mute"></span></button>
<style>
input[type=range].vol {
  width: 100%;
  margin: 7.3px 0;
  background-color: transparent;
  -webkit-appearance: none;
}
input[type=range].vol:focus {
  outline: none;
}
input[type=range].vol::-webkit-slider-runnable-track {
  background: #ff0000;
  border: 0.2px solid #010101;
  border-radius: 1.3px;
  width: 100%;
  height: 5.4px;
  cursor: pointer;
}
input[type=range].vol::-webkit-slider-thumb {
  margin-top: -7.5px;
  width: 9px;
  height: 20px;
  background: #ffffff;
  border: 1px solid #000000;
  border-radius: 3px;
  cursor: pointer;
  -webkit-appearance: none;
}
input[type=range].vol:focus::-webkit-slider-runnable-track {
  background: #ff1a1a;
}
input[type=range].vol::-moz-range-track {
  background: #ff0000;
  border: 0.2px solid #010101;
  border-radius: 1.3px;
  width: 100%;
  height: 5.4px;
  cursor: pointer;
}
input[type=range].vol::-moz-range-thumb {
  width: 9px;
  height: 20px;
  background: #ffffff;
  border: 1px solid #000000;
  border-radius: 3px;
  cursor: pointer;
}
input[type=range].vol::-ms-track {
  background: transparent;
  border-color: transparent;
  border-width: 8.3px 0;
  color: transparent;
  width: 100%;
  height: 5.4px;
  cursor: pointer;
}
input[type=range].vol::-ms-fill-lower {
  background: #e60000;
  border: 0.2px solid #010101;
  border-radius: 2.6px;
}
input[type=range].vol::-ms-fill-upper {
  background: #ff0000;
  border: 0.2px solid #010101;
  border-radius: 2.6px;
}
input[type=range].vol::-ms-thumb {
  width: 9px;
  height: 20px;
  background: #ffffff;
  border: 1px solid #000000;
  border-radius: 3px;
  cursor: pointer;
  margin-top: 0px;
  /*Needed to keep the Edge thumb centred*/
}
input[type=range].vol:focus::-ms-fill-lower {
  background: #ff0000;
}
input[type=range].vol:focus::-ms-fill-upper {
  background: #ff1a1a;
}
input[type=range] {
  width: 100%;
  margin: 3.8px 0;
  background-color: transparent;
  -webkit-appearance: none;
}
input[type=range]:focus {
  outline: none;
}
input[type=range]::-webkit-slider-runnable-track {
  background: #ff0000;
  border: 0.2px solid #010101;
  border-radius: 1.3px;
  width: 100%;
  height: 10.4px;
  cursor: pointer;
}
input[type=range]::-webkit-slider-thumb {
  margin-top: -4px;
  width: 17px;
  height: 18px;
  background: #dcdbdb;
  border: 5px solid #ffffff;
  border-radius: 50px;
  cursor: pointer;
  -webkit-appearance: none;
}
input[type=range]:focus::-webkit-slider-runnable-track {
  background: #ff1a1a;
}
input[type=range]::-moz-range-track {
  background: #ff0000;
  border: 0.2px solid #010101;
  border-radius: 1.3px;
  width: 100%;
  height: 10.4px;
  cursor: pointer;
}
input[type=range]::-moz-range-thumb {
  width: 17px;
  height: 18px;
  background: #dcdbdb;
  border: 5px solid #ffffff;
  border-radius: 50px;
  cursor: pointer;
}
input[type=range]::-ms-track {
  background: transparent;
  border-color: transparent;
  border-width: 4.8px 0;
  color: transparent;
  width: 100%;
  height: 10.4px;
  cursor: pointer;
}
input[type=range]::-ms-fill-lower {
  background: #e60000;
  border: 0.2px solid #010101;
  border-radius: 2.6px;
}
input[type=range]::-ms-fill-upper {
  background: #ff0000;
  border: 0.2px solid #010101;
  border-radius: 2.6px;
}
input[type=range]::-ms-thumb {
  width: 17px;
  height: 18px;
  background: #dcdbdb;
  border: 5px solid #ffffff;
  border-radius: 50px;
  cursor: pointer;
  margin-top: 0px;
  /*Needed to keep the Edge thumb centred*/
}
input[type=range]:focus::-ms-fill-lower {
  background: #ff0000;
}
input[type=range]:focus::-ms-fill-upper {
  background: #ff1a1a;
}
.html5-video-container {
    background: #000 no-repeat scroll center center;
    position: absolute;
    top: 0;
    bottom: 30px;
    left: 0;
    right: 0;
    z-index: 920;
    height: 100%;
}
</style>
      <div class="html5-volume-panel" role="slider" tabindex="5" aria-valuemin="0" aria-valuemax="100" aria-valuenow="100" aria-valuetext="100% volume">
        <div class="slider" style="height: 25px;">
		<input id="volume" class="vol" type="range" min="0" max="100" value="100" style="width: 50px; height: 10px;"></div>
      </div>
    </div>
    <div class="progress-text html5-control"><span id="currenttime" class="current-time html5-current-time">00:00</span><span class="html5-time-separator"> / </span><span id="duration" class="duration-time html5-duration-time">00:00</span><span class="html5-live-indicator hid">Live</span></div>


    <button data-title-default="Full screen" onclick="openFullscreen();" data-value="fullscreen" title="Full screen" data-title-alt="Exit full screen" onclick=";return false;" type="button" class="html5-fullscreen-button html5-control-right yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty" tabindex="15" role="button" aria-label="Full screen"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-html5" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt="Full screen"></span></button>

<script>
var gTimeFormat=function(seconds){
	var m=Math.floor(seconds/60)<10?"0"+Math.floor(seconds/60):Math.floor(seconds/60);
	var s=Math.floor(seconds-(m*60))<10?"0"+Math.floor(seconds-(m*60)):Math.floor(seconds-(m*60));
	return m+":"+s;
};
var elem = document.getElementById("watch-player");
var vid = document.getElementById("video-stream");
var playpause = document.getElementById("playpause");
var mutebtn = document.getElementById("mutebutton");
var vol = document.getElementById("volume");
var slider = document.getElementById("video-slider");
var controls = document.getElementById('controls');
var speed1 = document.getElementById("speed1");
var speed2 = document.getElementById("speed2");
var speed3 = document.getElementById("speed3");
var speed4 = document.getElementById("speed4");
var speed5 = document.getElementById("speed5");
function openFullscreen() {
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
	isfullscreen = 1;
  } else if (elem.webkitRequestFullscreen) { /* Safari */
    elem.webkitRequestFullscreen();
	isfullscreen = 1;
  } else if (elem.msRequestFullscreen) { /* IE11 */
    elem.msRequestFullscreen();
	isfullscreen = 1;
  }
}

function playVid() {
if (playpause.className == "html5-control html5-control-sep yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty html5-play-button") {
    vid.play();
	playpause.className = "html5-control html5-control-sep yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty html5-pause-button";
	} else if (playpause.className == "html5-control html5-control-sep yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty html5-replay-button") {
	vid.play();
	playpause.className = "html5-control html5-control-sep yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty html5-pause-button";
	} else {
	vid.pause();
	playpause.className = "html5-control html5-control-sep yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty html5-play-button";
	}
}
function mute() {
if (mutebtn.getAttribute("data-value") == "max") {
    vol.value = "0";
	} else {
	vol.value = "100";
	}
}
vid.ontimeupdate = function() {timeUpdate()};
setTimeout(function (){
document.getElementById("duration").innerHTML = gTimeFormat(vid.duration);
slider.value = 0;
slider.setAttribute("min", 0);
}, 1000);
function timeUpdate() {
setTimeout(function (){
    document.getElementById("currenttime").innerHTML = gTimeFormat(vid.currentTime);
	document.getElementById("duration").innerHTML = gTimeFormat(vid.duration);
	slider.setAttribute("max", vid.duration);
	slider.value = vid.currentTime;
	}, 500);
	if(vid.currentTime == vid.duration) {
	vid.pause();
	playpause.className = "html5-control html5-control-sep yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty html5-replay-button";
	}
	if(vol.value == 0) {
	mutebtn.setAttribute("data-value", "off");
	} else {
	mutebtn.setAttribute("data-value", "max");
	}
	vid.volume = vol.value / 100;
}
function setTime() {
vid.currentTime = slider.value;
}
slider.addEventListener('input', setTime);
var timeout;
var duration = 3000;
function setSpeed1() {
    vid.playbackRate = 2.0;
	document.getElementById("speed1").className = "yt-uix-button-menu-item active";
	document.getElementById("speed2").className = "yt-uix-button-menu-item";
	document.getElementById("speed3").className = "yt-uix-button-menu-item";
	document.getElementById("speed4").className = "yt-uix-button-menu-item";
	document.getElementById("speed5").className = "yt-uix-button-menu-item";
}
function setSpeed2() {
    vid.playbackRate = 1.5;
	document.getElementById("speed1").className = "yt-uix-button-menu-item";
	document.getElementById("speed2").className = "yt-uix-button-menu-item active";
	document.getElementById("speed3").className = "yt-uix-button-menu-item";
	document.getElementById("speed4").className = "yt-uix-button-menu-item";
	document.getElementById("speed5").className = "yt-uix-button-menu-item";
}
function setSpeed3() {
    vid.playbackRate = 1.0;
	document.getElementById("speed1").className = "yt-uix-button-menu-item";
	document.getElementById("speed2").className = "yt-uix-button-menu-item";
	document.getElementById("speed3").className = "yt-uix-button-menu-item active";
	document.getElementById("speed4").className = "yt-uix-button-menu-item";
	document.getElementById("speed5").className = "yt-uix-button-menu-item";
}
function setSpeed4() {
    vid.playbackRate = 0.5;
	document.getElementById("speed1").className = "yt-uix-button-menu-item";
	document.getElementById("speed2").className = "yt-uix-button-menu-item";
	document.getElementById("speed3").className = "yt-uix-button-menu-item";
	document.getElementById("speed4").className = "yt-uix-button-menu-item active";
	document.getElementById("speed5").className = "yt-uix-button-menu-item";
}
function setSpeed5() {
    vid.playbackRate = 0.25;
	document.getElementById("speed1").className = "yt-uix-button-menu-item";
	document.getElementById("speed2").className = "yt-uix-button-menu-item";
	document.getElementById("speed3").className = "yt-uix-button-menu-item";
	document.getElementById("speed4").className = "yt-uix-button-menu-item";
	document.getElementById("speed5").className = "yt-uix-button-menu-item active";
}
noContext = document.getElementById('video-stream');

noContext.addEventListener('contextmenu', e => {
  e.preventDefault();
});
</script>
    <button onclick=";return false;" title="Watch on YouTube" type="button" class="html5-watch-on-youtube-button html5-control-right html5-control-sep yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty" tabindex="12" role="button" aria-label="Watch on YouTube"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-html5" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt="Watch on YouTube"></span></button>

    <button onclick=";return false;" title="Watch later" type="button" class="html5-watch-later-button html5-control-right html5-control-sep yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty" tabindex="11" role="button" aria-label="Watch later" data-tooltip-text="Watch later"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-html5" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt="Watch later"></span></button>

    <button onclick=";return false;" title="Settings" type="button" class="html5-quality-button html5-control-right html5-control-sep yt-uix-button-reverse yt-uix-button-center-menu flip yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty" tabindex="10" role="button" aria-pressed="false" aria-expanded="false" aria-haspopup="true" aria-activedescendant="" aria-label="Settings" data-tooltip-text="Settings"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-html5" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt="Settings"></span><img class="yt-uix-button-arrow" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt=""><div class="yt-uix-button-menu yt-uix-button-menu-player hid" style="min-width: 30px; max-height: 495.422px; left: 898.5px; top: 371.422px; display: none;">  <div class="html5-settings-popup-menu html5-popup-menu list-style-menu">
    <ul class="html5-quality-popup-menu">
      <li class="html5-popup-menu-header">
Quality
      </li>
      <li class="yt-uix-button-menu-item" data-value="highres" style="display: none;">
        <span>Original <sup>HD</sup></span>
      </li>
      <li class="yt-uix-button-menu-item" data-value="hd1080" style="display: none;">
        <span class="yt-uix-button-menu-close">1080p <sup>HD</sup></span>
      </li>
      <li class="yt-uix-button-menu-item" data-value="hd720" style="display: none;">
        <span class="yt-uix-button-menu-close">720p <sup>HD</sup></span>
      </li>
      <li class="yt-uix-button-menu-item" data-value="large" style="display: none;">
        <span class="yt-uix-button-menu-close">480p</span>
      </li>
      <li class="yt-uix-button-menu-item active" data-value="medium" style="display: list-item;">
        <span class="yt-uix-button-menu-close">360p</span>
      </li>
      <li class="yt-uix-button-menu-item" data-value="small" style="display: none;">
        <span class="yt-uix-button-menu-close">240p</span>
      </li>
      <li class="yt-uix-button-menu-item" data-value="auto" style="display: none;">
        <span class="yt-uix-button-menu-close">Auto</span>
      </li>
    </ul>
    <ul class="html5-speed-popup-menu">
      <li class="html5-popup-menu-header">
Speed
      </li>
      <li class="yt-uix-button-menu-item" id="speed1" data-value="2.0">
        <span class="yt-uix-button-menu-close" onclick="setSpeed1();">2.0x</span>
      </li>
      <li class="yt-uix-button-menu-item" id="speed2" data-value="1.5">
        <span class="yt-uix-button-menu-close" onclick="setSpeed2();">1.5x</span>
      </li>
      <li class="yt-uix-button-menu-item active" id="speed3" data-value="1.0">
        <span class="yt-uix-button-menu-close" onclick="setSpeed3();">Normal</span>
      </li>
      <li class="yt-uix-button-menu-item" id="speed4" data-value="0.5">
        <span class="yt-uix-button-menu-close" onclick="setSpeed4();">0.5x</span>
      </li>
      <li class="yt-uix-button-menu-item" id="speed5" data-value="0.25">
        <span class="yt-uix-button-menu-close" onclick="setSpeed5();">0.25x</span>
      </li>
    </ul>
  </div>
</div></button>

    <button onclick=";return false;" title="Captions" type="button" class="html5-captions-button html5-module-button html5-control-right yt-uix-button-reverse flip yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty" tabindex="9" role="button" aria-pressed="false" aria-expanded="false" aria-haspopup="true" aria-activedescendant="" aria-label="Captions toggle"><img class="yt-uix-button-arrow" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt=""><div class="yt-uix-button-menu yt-uix-button-menu-player" style="display: none;">  <ul class="html5-captions-popup-menu html5-popup-menu">
    <li>
      <div class="html5-captions-actions html5-popup-menu-item-group">
        <ul>
          <li class="yt-uix-button-menu-item" data-action="settings">
Settings...
          </li>
        </ul>
      </div>
      <div class="captions-transforms html5-captions-actions html5-popup-menu-item-group">
        <ul>
          <li class="yt-uix-button-menu-item" data-action="translate">
Translate Captions
            <span class="html5-beta-label">BETA</span>
          </li>
        </ul>
      </div>
      <form class="html5-captions-tracks html5-popup-menu-item-group">
        <ul></ul>
      </form>
      <div class="html5-captions-off html5-popup-menu-item-group">
        <ul>
          <li class="yt-uix-button-menu-item" data-action="captions-off">
Turn Captions Off
          </li>
        </ul>
      </div>
    </li>
  </ul>
</div></button>

    <button onclick=";return false;" title="Annotations" type="button" class="html5-annotations-button html5-control-right hid yt-uix-button yt-uix-button-player yt-uix-tooltip yt-uix-button-empty" tabindex="8" role="button" aria-label="Annotations" style="display: none;"><span class="yt-uix-button-icon-wrapper"><img class="yt-uix-button-icon yt-uix-button-icon-html5" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt="Annotations"></span></button>

    <button type="button" class="html5-text-button html5-threed-button html5-control-right yt-uix-button-reverse flip hid yt-uix-button yt-uix-button-player" onclick=";return false;" tabindex="6" role="button" aria-pressed="false" aria-expanded="false" aria-haspopup="true" aria-activedescendant="" aria-label="3D" style="display: none;"><span class="yt-uix-button-content">3D </span><img class="yt-uix-button-arrow" src="watch2_files/pixel-vfl3z5WfW(1).gif" alt=""><div class="yt-uix-button-menu yt-uix-button-menu-player" style="display: none;">  <ul class="html5-threed-popup-menu html5-popup-menu">
    <li class="yt-uix-button-menu-item">
      <a class="html5-threed-popup-menu-change-mode-link">Change 3D viewing mode...</a>
    </li>
    <li class="yt-uix-button-menu-item html5-threed-conversion-on hid">
Turn on converted 3D
    </li>
    <li class="yt-uix-button-menu-item html5-threed-conversion-off hid">
Turn off converted 3D
    </li>
  </ul>
</div></button>
  </div>

    </div>
  </div></div>
    <script></script>