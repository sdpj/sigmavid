<?php

include 'db.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $ip_address = $_SERVER['REMOTE_ADDR'];

    // Update user's IP address in the database
    $stmt = $conn->prepare("UPDATE users SET ip_address = ? WHERE id = ?");
    $stmt->bind_param("si", $ip_address, $user_id);
    $stmt->execute();
    $stmt->close();
}

$conn->close();
?>
