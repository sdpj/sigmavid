<?php
include 'db.php';

// Fetch user details if logged in
$user_id_header = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_header = null;
$subscriberCountHeader = 0; // Default value

function getSubscriberCountHeader($userId, $conn) {
    $userId = mysqli_real_escape_string($conn, $userId);
    $query = "SELECT COUNT(*) AS subscriber_count FROM subscriptions WHERE user_id = '$userId'";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $data = mysqli_fetch_assoc($result);
        return isset($data['subscriber_count']) ? $data['subscriber_count'] : 0;
    }
    return 0;
}

if ($user_id_header) {
    // Fetch user details from the database
    $stmt_userheader = $conn->prepare("SELECT id, username, profile_picture FROM users WHERE id = ?");
    $stmt_userheader->bind_param("i", $user_id_header);
    $stmt_userheader->execute();
    $result_user_header = $stmt_userheader->get_result();

    if ($result_user_header->num_rows > 0) {
        $user_header = $result_user_header->fetch_assoc();
        $subscriberCountHeader = getSubscriberCountHeader($user_id_header, $conn);
    }
    $stmt_userheader->close();
}
?>
<?php include 'ticker.php'; ?>

<?php if ($ticker): ?>
	<div id="ticker" class="ytg-base "><div id="ticker-inner"><div class="ytg-wide"><button onclick="yt.net.cookies.set('HideTicker', 1, 604800);" class="yt-uix-close" data-close-parent-id="ticker"><img alt="Close" src="//web.archive.org/web/20130301230851im_/http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif"></button><img class="ticker-icon" src="//web.archive.org/web/20130301230851im_/http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif" alt=""><div class="ticker-content"><?php echo $ticker; ?></div></div></div></div>
<?php endif; ?>

<div id="yt-masthead-container" class="yt-grid-box yt-base-gutter">
    <div id="yt-masthead" class="">
        <a id="logo-container" href="/" title="SigmaVid home" class=" ">
            <iframe width="560" height="315" src="https://www.youtube.com/embed/98fsOSnqTh8?si=ScL5-KGTjW1_mEpX&amp;autoplay=1&amp;controls=1&amp;loop=1&amp;mute=1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen="" style="display:none;"></iframe>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/H2_l_Vp0Xjw?si=ScL5-KGTjW1_mEpX&amp;autoplay=1&amp;controls=1&amp;loop=1&amp;mute=1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen="" style="display:none;"></iframe>
            <img height="30" width="70" id="logo1" src="images/sigmavid.png" alt="SigmaVid home">
        </a>

        <?php if ($user_header): ?>
            <!-- Display user profile information -->
            <div id="masthead-user-bar-container" bis_skin_checked="1">
                <div id="masthead-user-bar" bis_skin_checked="1">
                    <div id="masthead-user" bis_skin_checked="1">
                        <span id="masthead-gaia-user-expander" class="masthead-user-menu-expander masthead-expander" onclick="wow()">
                            <span id="masthead-gaia-user-wrapper" class="yt-rounded" tabindex="0">
                                <?php echo htmlspecialchars($user_header['username']); ?>
                            </span>
                        </span>
                        <span id="masthead-gaia-photo-expander" class="masthead-user-menu-expander masthead-expander" onclick="wow()">
                            <span id="masthead-gaia-photo-wrapper" class="yt-rounded">
                                <span id="masthead-gaia-user-image">
                                    <span class="clip">
                                        <span class="clip-center">
                                            <img src="<?php echo htmlspecialchars($user_header['profile_picture']); ?>" alt="">
                                            <span class="vertical-center"></span>
                                        </span>
                                    </span>
                                </span>
                                <span class="masthead-expander-arrow"></span>
                            </span>
                        </span>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- Display login button if user not logged in -->
            <div id="yt-masthead-signin">
                <button href="/login" onclick=";window.location.href=this.getAttribute('href');return false;" class=" yt-uix-button yt-uix-button-primary yt-uix-button-size-default" type="button" role="button">
                    <span class="yt-uix-button-content">Sign in</span>
                </button>
            </div>
        <?php endif; ?>

        <div id="yt-masthead-content">
            <span id="masthead-upload-button-group">
                <a href="/upload" class="yt-uix-button yt-uix-sessionlink yt-uix-button-default yt-uix-button-size-default" data-sessionlink="feature=mhsb&amp;ei=yyOdUvWjKJOziAKBy4HABQ">
                    <span class="yt-uix-button-content">Upload</span>
                </a>
            </span>
            <form id="masthead-search" class="search-form consolidated-form" action="/results" onsubmit="if (_gel('masthead-search-term').value == '') return false;">
                <button onclick="if (_gel('masthead-search-term').value == '') return false; _gel('masthead-search').submit(); return false;;return true;" class="search-btn-component search-button yt-uix-button yt-uix-button-default yt-uix-button-size-default" dir="ltr" id="search-btn" tabindex="2" type="submit" role="button">
                    <span class="yt-uix-button-content">Search</span>
                </button>
                <div id="masthead-search-terms" class="masthead-search-terms-border" dir="ltr">
                    <label>
                        <input id="masthead-search-term" autocomplete="off" autofocus="" class="search-term yt-uix-form-input-bidi" name="search_query" value="" type="text" tabindex="1" title="Search">
                    </label>
                    <script>var searchBox = document.getElementById('masthead-search-term');if (searchBox) {searchBox.focus();}</script>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="masthead-expanded-container" style="height: 142px;display:none;" class="with-sandbar" bis_skin_checked="1">
    <div id="masthead-expanded-menus-container" bis_skin_checked="1">
        <span id="masthead-expanded-menu-shade"></span>
        <div id="masthead-expanded-menu" class="" bis_skin_checked="1">
            <ul id="masthead-expanded-menu-list">
                <li class="masthead-expanded-menu-item">
                    <a href="/channel?user_id=<?php echo htmlspecialchars($_SESSION['user_id']); ?>" class="yt-uix-sessionlink" data-sessionlink="ei=UCd131nmJ5MOh9TmIyqA81&amp;feature=mhee">My channel</a>
                </li>
                <li class="masthead-expanded-menu-item">
                    <a href="/manage_videos" class="yt-uix-sessionlink" data-sessionlink="ei=UCd131nmJ5MOh9TmIyqA81&amp;feature=mhee">Video Manager</a>
                </li>
                <?php
                    if ($_SESSION['user_id']) {
                        $user_id_admin = $_SESSION['user_id'];
                        $query = "SELECT role FROM users WHERE id = $user_id_admin LIMIT 1";
                        $result_admin = mysqli_query($conn, $query);
                        $row_admin = mysqli_fetch_assoc($result_admin);
                        if ($row_admin['role'] == 'admin') {
                            echo '<li class="masthead-expanded-menu-item">';
                            echo '<a class="end" href="/admin">Admin Panel</a>';
                            echo '</li>';
                        }
                    }
                ?>
                <li class="masthead-expanded-menu-item">
                    <a class="end" href="/logout">Log out</a>
                </li>
            </ul>
        </div>
        <div id="masthead-expanded-google-menu" bis_skin_checked="1">
            <div id="masthead-expanded-menu-google-container" bis_skin_checked="1">
                <div id="masthead-expanded-menu-google-column2" bis_skin_checked="1">
                    <div id="masthead-expanded-menu-account-container" bis_skin_checked="1">
                        <img id="masthead-expanded-menu-gaia-photo" alt="" data-src="<?php echo htmlspecialchars($user_header['profile_picture']); ?>" src="<?php echo htmlspecialchars($user_header['profile_picture']); ?>">
                        <div id="masthead-expanded-menu-account-info" class="email-only" bis_skin_checked="1">
                            <p><?php echo htmlspecialchars($user_header['username']); ?></p>
                            <p id="masthead-expanded-menu-email"><?php echo htmlspecialchars($subscriberCountHeader); ?> subscribers</p>
                        </div>
                    </div>
                    <ul></ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function wow() {
  var masthead = document.getElementById('masthead-expanded-container');
  
  // Toggle visibility
  masthead.style.display = (masthead.style.display === 'none') ? 'block' : 'none';
}

// Initially hide the masthead element
document.addEventListener('DOMContentLoaded', function() {
  var masthead = document.getElementById('masthead-expanded-container');
  masthead.style.display = 'none';
});
</script>
