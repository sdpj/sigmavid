<?php
session_start();
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$comment_id = $_GET['comment_id'];
$action = $_GET['action'];
$user_id = $_SESSION['user_id'];

// Determine current status
$current_status = null;
$stmt_check = $conn->prepare("SELECT status FROM comment_likes WHERE comment_id = ? AND user_id = ?");
$stmt_check->bind_param("ii", $comment_id, $user_id);
$stmt_check->execute();
$stmt_check->bind_result($current_status);
$stmt_check->fetch();
$stmt_check->close();

// Determine new status and actions
if ($action === 'like' || $action === 'unlike') {
    $new_status = ($action === 'like') ? 'like' : null;
    if ($current_status === 'like') {
        $new_status = null; // Remove like if already liked
    }
} elseif ($action === 'dislike' || $action === 'undislike') {
    $new_status = ($action === 'dislike') ? 'dislike' : null;
    if ($current_status === 'dislike') {
        $new_status = null; // Remove dislike if already disliked
    }
}

// Remove existing like/dislike if needed
if ($current_status && $new_status === null) {
    $stmt_remove = $conn->prepare("DELETE FROM comment_likes WHERE comment_id = ? AND user_id = ?");
    $stmt_remove->bind_param("ii", $comment_id, $user_id);
    $stmt_remove->execute();
    $stmt_remove->close();
}

// Add new like/dislike if needed
if ($new_status) {
    $stmt_add = $conn->prepare("INSERT INTO comment_likes (comment_id, user_id, status) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE status = ?");
    $stmt_add->bind_param("iiss", $comment_id, $user_id, $new_status, $new_status);
    $stmt_add->execute();
    $stmt_add->close();
}

header("Location: watch.php?id=" . $_GET['video_id']);
exit();
?>
