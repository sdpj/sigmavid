<?php include 'all.php'; ?>
<?php $page = 'Upload' ?>
<!DOCTYPE html>
<html lang="en" data-cast-api-enabled="true">
<head>
    <link id="css-2838365198" class="www-core" rel="stylesheet" href="css/main.css" data-loaded="true">
    <link class="www-core" rel="stylesheet" href="css/yt-framework.css" data-loaded="true">
    <title>SigmaVid</title>
    <link rel="search" type="application/opensearchdescription+xml" href="https://www.youtube.com/opensearch?locale=en_US" title="SigmaVid Video Search">
    <link rel="shortcut icon" href="favicon-vfldLzJxy.ico" type="image/x-icon">
    <link rel="icon" href="images/favicon_32-vflWoMFGx.png" sizes="32x32">
    <link rel="alternate" media="handheld" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
    <link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
    <meta name="description" content="Share your videos with friends, family, and the world">
    <meta name="keywords" content="video, sharing, camera phone, video phone, free, upload">
    <meta property="og:image" content="images/youtube_logo_stacked-vfl225ZTx.png">
    <meta property="fb:app_id" content="87741124305">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body dir="ltr" class="ltr site-left-aligned hitchhiker-enabled guide-enabled guide-expanded" id="body">
    <div id="body-container">
        <form name="logoutForm" method="POST" action="/logout"><input type="hidden" name="action_logout" value="1"></form>
        <?php include 'header.php'; ?>
        <div id="alerts"></div>
        <div id="page-container">
            <div id="page" class="home branded-page-v2-masthead-ad-header clearfix">
                <?php include 'guide.php'; ?>
                <div id="content" style="height:800px;" class="content">
				<div id="notification-container">
				</div>
                    <div class="yt-navigation-dark">
                        <li>Upload video files</li>
                    </div>
                    <div id="upload-container" style="padding:15px;height:700px;border:1px solid #e2e2e2;">
                        <div id="upload-stage1" style="height:695px;border:1px solid #e2e2e2;">
                            <div style="width:250px;text-align:center;margin:auto;margin-top:150px;">
                                <form id="upload-form" style="margin:auto;width:180px;">
                                    <input id='fileid' type='file' hidden />
                                    <a href="#"><img style="width:180px;" id="uploadbutton" src="images/upload_button.png" /></a>
                                </form>
<script>
    function showNotification(message, type) {
        const notificationContainer = document.getElementById('notification-container');
        const notification = document.createElement('div');
        notification.className = `yt-notification ${type}`;
        notification.innerHTML = `
            <div class="yt-notification-icon"></div>
            <span>${message}</span>
            <div class="yt-notification-close" data-dismiss="alert" onclick="this.parentElement.style.display='none';"></div>
        `;
        notificationContainer.appendChild(notification);
        setTimeout(() => {
            notification.style.display = 'none';
        }, 5000);
    }

    function generateUniqueId(length) {
        const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    document.getElementById('uploadbutton').addEventListener('click', openDialog);

    function openDialog() {
        document.getElementById('fileid').click();
    }

    document.getElementById('fileid').addEventListener('change', uploadFile);

    function uploadFile() {
        const file = document.getElementById('fileid').files[0];
        if (!file) return;

        const chunkSize = 5 * 1024 * 1024; // 5MB
        const totalChunks = Math.ceil(file.size / chunkSize);
        let currentChunk = 0;
        const chunkId = generateUniqueId(16); // Generate a 16-character unique ID

        // Show stage 2 immediately
        document.getElementById('upload-stage1').style.display = 'none';
        document.getElementById('upload-stage2').style.display = 'block';

        function uploadChunk() {
            const start = currentChunk * chunkSize;
            const end = Math.min(file.size, start + chunkSize);
            const chunk = file.slice(start, end);

            const formData = new FormData();
            formData.append('file', chunk);
            formData.append('filename', file.name);
            formData.append('chunk', currentChunk);
            formData.append('totalChunks', totalChunks);
            formData.append('chunkId', chunkId); // Send the unique chunk ID

            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'upload_ajax.php', true);

            xhr.upload.onprogress = function (event) {
                if (event.lengthComputable) {
                    const percentComplete = ((currentChunk * chunkSize + event.loaded) / file.size) * 100;
                    if (percentComplete < 99) {
                        document.getElementById('upload-progress').value = percentComplete;
                        document.getElementById('progress-text').innerText = `${Math.round(percentComplete)}%`;
                    }
                }
            };

            xhr.onload = function () {
                if (xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    if (response.status === 'success') {
                        currentChunk++;
                        if (currentChunk < totalChunks) {
                            uploadChunk(); // Upload next chunk
                        } else {
                            // Set progress to 99% while processing
                            document.getElementById('upload-progress').value = 99;
                            document.getElementById('progress-text').innerText = `99%`;
                            document.getElementById('video-title').innerText = 'Processing...';
                            document.getElementById('video-title-2').innerText = 'Processing your video... (This can take up to 5 minutes, do not leave the page.)';
                            checkProcessingStatus(response.newFileName); // Pass the filename for status check
                        }
                    } else {
                        showNotification(response.error, 'important');
                    }
                } else {
                    showNotification('Upload failed!', 'important');
                }
            };

            xhr.send(formData);
        }

        uploadChunk(); // Start uploading chunks
    }

    function checkProcessingStatus(filename) {
        const interval = setInterval(function () {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', `check_processing_status.php?filename=${filename}`, true);

            xhr.onload = function () {
                if (xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    if (response.status === 'completed') {
                        clearInterval(interval);
                        showStage2(response.newFileName, response.thumbnailFile);
                    }
                }
            };

            xhr.send();
        }, 5000); // Check every 5 seconds
    }

    function showStage2(filename, thumbnailFile) {
        document.getElementById('video-title').innerText = filename;
        document.getElementById('thumbnail-preview').src = 'uploads/' + thumbnailFile;
        document.getElementById('thumbnail').value = thumbnailFile;

        // Ensure the filename is set in the hidden input field
        document.getElementById('filename').value = filename;

        document.querySelector('input[type="submit"]').disabled = false;
        document.getElementById('upload-progress').value = 100;
        document.getElementById('progress-text').innerText = `100%`;
        document.getElementById('video-title-2').innerText = 'Processing complete! You may now upload your video.';
    }

    function submitForm(event) {
        event.preventDefault();
        const form = document.getElementById('stage2-form');
        const formData = new FormData(form);

        // Debugging: log form data to ensure filename is included
        for (let [key, value] of formData.entries()) {
            console.log(`${key}: ${value}`);
        }

        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'upload_db.php', true);
        xhr.onload = function () {
            if (xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                if (response.status === 'success') {
                    showNotification(response.message, 'success');
                    setTimeout(function() {
                        window.location.replace("/manage_videos.php");
                    }, 2000); // Delay for 2 seconds
                } else {
                    showNotification(response.message, 'important');
                }
            } else {
                showNotification('Form submission failed.', 'important');
            }
        };
        xhr.send(formData);
    }
</script>





                    






                                <div style="margin-top:15px;">
                                    <p style="color:#575757;font-size:23px;">Select files to upload</p><br>
                                    <p style="color:#7a7a7a;font-size:17px;">Or drag and drop video files</p>
                                </div>
                            </div>
                        </div>
                        <div id="upload-stage2" style="display:none;">
                            <div style="display:flex;gap:15px;">
                                <img id="thumbnail-preview" src="uploads/default_thumbnail.jpg" style="height:80px;width:150px;border:1px solid #ababab;">
                                <div>
                                    <h1 id="video-title">Uploading...</h1><br>
                                    <div id="video-title-2" style="color:#919191;margin-bottom:2px;">Uploading your video.</div>
                                    <div id="progress-container">
                                        <progress class="yt-progress-bar" id="upload-progress" style="width:250px;" value="0" max="100"></progress>
                                        <p id="progress-text">0%</p>
                                    </div>
                                </div>
                            </div>
                            <div class="tabbable" style="max-width:100%;">
                                <div class="tabs">
                                    <ul class="yt-tabs">
                                        <li class="ui-state-default ui-corner-top ui-tabs-active ui-state-active"><a href="#">Basic Info</a></li>
                                    </ul>
                                    <div style="width:100%;border-top:1px solid #e2e2e2;"></div>
                                </div>
                                <div style="padding-top:15px;">
                                    <form id="stage2-form" onsubmit="submitForm(event)">
                                        <input type="hidden" id="filename" name="filename" />
                                        <input type="hidden" id="thumbnail" name="thumbnail" />
                                        <div style="display:flex;gap:15px;">
                                            <div class="left" style="width:60%">
                                                <label for="title">Title</label><br>
                                                <input name="title" id="title" type="text" class="yt-search-input" style="width:100%;" required /><br><br>
                                                <label for="description">Description</label><br>
                                                <textarea name="description" id="description" type="text" class="yt-search-input" style="height:80px;width:100%" required></textarea><br><br>
                                            </div>
                                            <div class="right" style="width:40%">
                                                <label for="privacy">Privacy Settings</label><br>
                                                <select name="privacy" class="yt-dropdown-menu">
                                                    <option value="public">Public</option>
                                                </select><br><br>
                                                <label for="category">Category</label><br>
                                                <select name="category" id="category" class="yt-dropdown-menu">
													<option value="music">Music</option>
													<option value="education">Education</option>
													<option value="entertainment">Entertainment</option>
													<option value="gaming">Gaming</option>
													<option value="news">News</option>
													<option value="technology">Science and Technology</option>
													<option value="other">Other</option>
                                                </select><br><br>
                                                <div class="g-recaptcha" data-sitekey="6Le_PBMqAAAAANAtepZMGwnqmj5W_4aRCfinfmFO"></div><br>
                                            </div>
                                        </div>
                                        <div style="margin-left:680px;">
                                            <input value="Save Changes" type="submit" class="yt-button yt-button-blue" disabled></input>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<div id="footer-container" style="margin-top:0;">
					<div id="footer">
						<div id="footer-main">
							<div id="footer-l0go"><a href="/" title="SigmaVid home"><img height="30px" width="72px" id="logo1" src="images/SigmaVid-logo.png" alt="SigmaVid home"></a></div>
						</div>
						<div id="footer-links">
							<ul id="footer-links-primary">
								<li><a href="/about">About</a></li>
								<li><a href="/blog">Press &amp; Blogs</a></li>
								<li><a href="/copyright">Copyright</a></li>
								<li><a href="/creators">Creators &amp; Partners</a></li>
								<li><a href="/advertise">Advertising</a></li>
								<li><a href="/dev">Developers</a></li>
							</ul>
							<ul id="footer-links-secondary">
								<li><a href="/tos">Terms</a></li>
								<li><a href="/policyandsafety">Policy &amp; Safety</a></li>
								<li><span class="copyright" dir="ltr">© 2024 SigmaVid</span></li>
							</ul>
						</div>
					</div>
				</div>				
            </div>
        </div>
    </div>
</body>
</html>
