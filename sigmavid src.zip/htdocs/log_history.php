<?php
// log_history.php

// Include the database connection
include 'db.php';

// Start the session to access session variables
session_start();

// Retrieve item_id from the URL parameter
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $item_id = intval($_GET['id']);
} else {
    // Handle the case where item_id is not provided or is invalid
    die("Invalid item ID.");
}

// Check if user_id is set in the session
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO history (user_id, item_id, item_type) VALUES (?, ?, ?)");
    $item_type = 'movie'; // Or whatever type you want to use
    $stmt->bind_param("iis", $user_id, $item_id, $item_type);

    // Execute the statement
	$stmt->execute();


    // Close the statement
    $stmt->close();
} else {
    // User is not logged in; no history update
}

// Close the database connection
?>
