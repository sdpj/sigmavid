<?php
session_start(); // Ensure session is started
include 'db.php';

$page = 'Playlists';
if (!isset($_SESSION['user_id'])) {
    die("User not logged in.");
}

$userIdLol = $_SESSION['user_id']; // Retrieve user ID from session

// MySQLi connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to get the latest video from each user you are subscribed to, including username
$query = "
    SELECT v.*, u.username, u.profile_picture
    FROM videos v
    INNER JOIN users u ON v.user_id = u.id
    INNER JOIN (
        SELECT v.user_id, MAX(v.uploaded_at) as latest_upload
        FROM videos v
        JOIN subscriptions s ON v.user_id = s.user_id
        WHERE s.subscriber_id = ?
        GROUP BY v.user_id
    ) latest ON v.user_id = latest.user_id AND v.uploaded_at = latest.latest_upload
    ORDER BY v.uploaded_at DESC
";


// Prepare and bind
$stmt = $conn->prepare($query);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param('i', $userIdLol);
$stmt->execute();

// Get result
$result = $stmt->get_result();
if (!$result) {
    die("Get result failed: " . $stmt->error);
}
$latestVideos = $result->fetch_all(MYSQLI_ASSOC);


function getTimeAgoString2($uploaded_at) {
    try {
        $now = new DateTime();
        $uploadedDate = new DateTime($uploaded_at);
        $interval = $now->diff($uploadedDate);

        if ($interval->y > 0) {
            return $interval->y . ' years ago';
        } elseif ($interval->m > 0) {
            return $interval->m . ' months ago';
        } elseif ($interval->d > 0) {
            return $interval->d . ' days ago';
        } elseif ($interval->h > 0) {
            return $interval->h . ' hours ago';
        } elseif ($interval->i > 0) {
            return $interval->i . ' minutes ago';
        } else {
            return $interval->s . ' seconds ago';
        }
    } catch (Exception $e) {
        // Log or display error message
        return 'Error calculating time ago';
    }
}

if (!empty($userInfoMap)) {
    $userIds = implode(',', array_map('intval', array_keys($userInfoMap)));
    $userSql = "SELECT * FROM users WHERE id IN ($userIds)";
    $userResult = $conn->query($userSql);

    if ($userResult->num_rows > 0) {
        while ($userRow = $userResult->fetch_assoc()) {
            $userInfoMap[$userRow['id']] = $userRow;
        }
    }
}

function getUserInfo($userid) {
    global $userInfoMap;
    return isset($userInfoMap[$userid]) ? $userInfoMap[$userid] : [];
}
// Close connections
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en" data-cast-api-enabled="true">
<head>
    <link id="css-2838365198" class="www-core" rel="stylesheet" href="css/main.css" data-loaded="true">
    <title>Playlists - SigmaVid</title>
    <link rel="search" type="application/opensearchdescription+xml" href="https://www.youtube.com/opensearch?locale=en_US" title="SigmaVid Video Search">
    <link rel="shortcut icon" href="favicon-vfldLzJxy.ico" type="image/x-icon">
    <link rel="icon" href="images/favicon_32-vflWoMFGx.png" sizes="32x32">
    <link rel="alternate" media="handheld" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
    <link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
    <meta name="description" content="Share your videos with friends, family, and the world">
    <meta name="keywords" content="video, sharing, camera phone, video phone, free, upload">
    <meta property="og:image" content="images/youtube_logo_stacked-vfl225ZTx.png">
    <meta property="fb:app_id" content="87741124305">
    <link rel="publisher" href="https://plus.google.com/115229808208707341778">
    <script>if (window.ytcsi) {window.ytcsi.tick("cl", null, '');}</script>
	<link class="www-core" rel="stylesheet" href="css/yt-framework.css" data-loaded="true">

</head>
<body dir="ltr" class="ltr site-left-aligned hitchhiker-enabled guide-enabled guide-expanded" id="body">
    <div id="body-container">
        <form name="logoutForm" method="POST" action="/logout"><input type="hidden" name="action_logout" value="1"></form>
        <?php include 'header.php'; ?>
        <div id="alerts"></div>
        <div id="page-container">
            <div id="page" class="home branded-page-v2-masthead-ad-header clearfix">
                <?php include 'all.php';
 include 'guide.php'; ?>
                <div id="player" class="off-screen">
                    <!-- Player content -->
                </div>

                <div id="content">
					<h1>Coming Soon...</h1>			
                </div>
            </div>
        </div>
    </div>
</body>
</html>
