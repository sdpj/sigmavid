<?php
session_start();
include('db.php'); // Ensure this file contains the database connection details
include('all.php');

$conn_svid = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn_svid->connect_error) {
    die("Connection failed: " . $conn_svid->connect_error);
}

// Determine the sort order (default to subscribers, can be changed via URL or form)
$sort_svid = isset($_GET['sort']) ? $_GET['sort'] : 'subscribers'; // Default sort by subscribers

// Fetch all users with their subscriber counts, sorted by the selected criteria
if ($sort_svid == 'creation_date') {
    $sql_svid = "SELECT u.*, COUNT(s.subscriber_id) AS subscriber_count 
            FROM users u 
            LEFT JOIN subscriptions s ON u.id = s.user_id 
            GROUP BY u.id 
            ORDER BY u.id DESC"; // Sort by id descending for creation date
} else {
    $sql_svid = "SELECT u.*, COUNT(s.subscriber_id) AS subscriber_count 
            FROM users u 
            LEFT JOIN subscriptions s ON u.id = s.user_id 
            GROUP BY u.id 
            ORDER BY subscriber_count DESC"; // Sort by subscriber count
}

$result_svid = $conn_svid->query($sql_svid);

// Check for SQL errors
if (!$result_svid) {
    die("Error executing query: " . $conn_svid->error);
}
?>

<!DOCTYPE html>
<html lang="en" data-cast-api-enabled="true">
<head>
    <link id="css-2838365198" class="www-core" rel="stylesheet" href="css/main.css" data-loaded="true">
    <title>SigmaVid</title>
    <link rel="search" type="application/opensearchdescription+xml" href="https://www.youtube.com/opensearch?locale=en_US" title="SigmaVid Video Search">
    <link rel="shortcut icon" href="favicon-vfldLzJxy.ico" type="image/x-icon">
    <link rel="icon" href="images/favicon_32-vflWoMFGx.png" sizes="32x32">
    <link rel="alternate" media="handheld" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
    <link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.youtube.com/index?&amp;desktop_uri=%2F">
    <meta name="description" content="Share your videos with friends, family, and the world">
    <meta name="keywords" content="video, sharing, camera phone, video phone, free, upload">
    <meta property="og:image" content="images/youtube_logo_stacked-vfl225ZTx.png">
    <meta property="fb:app_id" content="87741124305">
    <link rel="publisher" href="https://plus.google.com/115229808208707341778">
    <script>if (window.ytcsi) {window.ytcsi.tick("cl", null, '');}</script>
    <style>
        .channels-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .channel {
            width: 125px;
            background: #fff;
            border: 1px solid #ddd;
            overflow: hidden;
            text-align: center;
        }

        .channel img {
            width: 85px;
            height: auto;
        }

        .channel-info {
            padding: 15px;
        }

        .channel-info h2 {
            font-size: 100%;
            margin: 10px 0;
            white-space: nowrap; /* Prevent text from wrapping */
            overflow: hidden; /* Hide overflowing text */
            text-overflow: ellipsis; /* Display ellipsis (...) for overflowed text */
        }

        .channel-info p {
            color: #777;
            font-size: 12px;
        }
    </style>

</head>
<body dir="ltr" class="ltr site-left-aligned hitchhiker-enabled guide-enabled guide-expanded" id="body">
    <div id="body-container">

        <form name="logoutForm_svid" method="POST" action="/logout"><input type="hidden" name="action_logout_svid" value="1"></form>
        <?php include 'header.php'; ?>
        
        <div id="alerts_svid"></div>
        <div id="page-container">
            <div id="page" class="home branded-page-v2-masthead-ad-header clearfix">
                <?php include 'guide.php'; ?>
                <div id="content" class="content">
                <form id="sortForm_svid" action="" method="GET">
                    <label for="sort">Sort by:</label>
                    <select name="sort" id="sort">
                        <option value="subscribers" <?php echo ($sort_svid == 'subscribers') ? 'selected' : ''; ?>>Subscribers</option>
                        <option value="creation_date" <?php echo ($sort_svid == 'creation_date') ? 'selected' : ''; ?>>Creation Date</option>
                    </select>
                </form>

    <div class="channels-container">
        <?php
        if ($result_svid->num_rows > 0) {
            while ($row_svid = $result_svid->fetch_assoc()) {
                $profile_picture_svid = !empty($row_svid["profile_picture"]) ? $row_svid["profile_picture"] : "default_pfp.jpg";
                $banner_art_svid = !empty($row_svid["banner_art"]) ? $row_svid["banner_art"] : "default_banner.jpg";
                ?>
                <div class="channel">
                    <a href="channel.php?user_id=<?php echo $row_svid['id']; ?>">
                        <img src="<?php echo htmlspecialchars($profile_picture_svid); ?>" alt="<?php echo htmlspecialchars($row_svid['username']); ?>'s profile picture">
                    </a>
                    <div class="channel-info">
                        <h2><?php echo htmlspecialchars($row_svid["username"]); ?></h2>
                        <p>Subscribers: <?php echo $row_svid["subscriber_count"]; ?></p>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p>No channels found.</p>";
        }
        $conn_svid->close();
        ?>
    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="footer-container">
        <div id="footer">
            <div id="footer-main">
                <div id="footer-l0go"><a href="/" title="SigmaVid home"><img height="30px" width="72px" id="logo1" src="images/SigmaVid-logo.png" alt="SigmaVid home"></a></div>
            </div>
            <div id="footer-links">
                <ul id="footer-links-primary">
                    <li><a href="/about">About</a></li>
                    <li><a href="/blog">Press &amp; Blogs</a></li>
                    <li><a href="/copyright">Copyright</a></li>
                    <li><a href="/creators">Creators &amp; Partners</a></li>
                    <li><a href="/advertise">Advertising</a></li>
                    <li><a href="/dev">Developers</a></li>
                </ul>
                <ul id="footer-links-secondary">
                    <li><a href="/tos">Terms</a></li>
                    <li><a href="/policyandsafety">
                        Policy &amp; Safety
                        </a>
                    </li>
                    <li><span class="copyright" dir="ltr">© 2024 SigmaVid</span></li>
                </ul>
            </div>
        </div>
    </div>
        <script>
        // JavaScript to submit form when select box changes
        document.getElementById('sort').addEventListener('change', function() {
            document.getElementById('sortForm_svid').submit();
        });
    </script>
</body>
</html>
